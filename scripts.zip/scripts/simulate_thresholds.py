"""Monte-Carlo study used to choose the matching thresholds.

Generates genuine and impostor similarity scores from the simulated scanner model,
derives FAR/FRR/EER, picks operating thresholds, validates the 1:N design end to end,
and writes reports/threshold_study.json + (optionally) src/bioinvigil/match_policy.json.

    python scripts/simulate_thresholds.py --write-policy
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from statistics import NormalDist

import numpy as np

from bioinvigil.biometric import DIM, POPULATION_CORRELATION, SimulatedScanner

ROOT = Path(__file__).resolve().parents[1]
N_ID = 2000  # simulated identities
GEN_ROUNDS = 20  # genuine probes per identity
IMP_ROUNDS = 3  # impostor probe rounds (each = N_ID x N_ID comparisons)
ENROL_QMIN = 0.60
MARGIN = 0.05
TARGET_FAR_1TO1 = 1e-4
HALL_N, TARGET_FAR_HALL = 1000, 1e-3
DB_N, TARGET_FAR_DB = 50_000, 1e-2
MAX_ATTEMPTS = 3


def lognorm(rng, median, sd, lo, hi, size):
    return np.clip(rng.lognormal(np.log(median), sd, size), lo, hi)


def unit(x):
    return x / np.linalg.norm(x, axis=-1, keepdims=True)


def noisy(base, sigma, rng):
    return base + sigma[:, None] * rng.standard_normal(base.shape)


def per_comparison_far(far_n: float, n: int) -> float:
    """FAR_N = 1 - (1 - p)^N  =>  p = 1 - (1 - FAR_N)^(1/N)."""
    return 1.0 - (1.0 - far_n) ** (1.0 / n)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--write-policy", action="store_true")
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)

    sc = SimulatedScanner()
    base = np.stack([sc.finger(f"SIM{i:05d}") for i in range(N_ID)])

    # ---- enrolment with consistency check and re-capture --------------------------------
    def capture_set():
        return [unit(noisy(base, lognorm(rng, 0.55, 0.25, 0.3, 1.4, N_ID), rng)) for _ in range(3)]

    def consistency(caps):
        return np.min([(caps[a] * caps[b]).sum(1) for a in range(3) for b in range(a + 1, 3)], axis=0)

    caps = capture_set()
    cons = consistency(caps)
    first_pass_reject = float(np.mean(cons < ENROL_QMIN))
    for _ in range(20):
        bad = cons < ENROL_QMIN
        if not bad.any():
            break
        new = capture_set()
        for k in range(3):
            caps[k][bad] = new[k][bad]
        cons = consistency(caps)
    templates = unit(unit(np.mean(caps, axis=0)))

    # ---- genuine and impostor score sets -------------------------------------------------
    probe_sigma = lambda: lognorm(rng, 0.65, 0.35, 0.3, 2.0, N_ID)  # noqa: E731
    genuine = np.concatenate([(unit(noisy(base, probe_sigma(), rng)) * templates).sum(1) for _ in range(GEN_ROUNDS)])
    off_diag = ~np.eye(N_ID, dtype=bool)
    impostor = np.concatenate(
        [(unit(noisy(base, probe_sigma(), rng)) @ templates.T)[off_diag] for _ in range(IMP_ROUNDS)]
    )
    mu_g, sd_g = float(genuine.mean()), float(genuine.std(ddof=1))
    mu_i, sd_i = float(impostor.mean()), float(impostor.std(ddof=1))
    skew = float(np.mean(((impostor - mu_i) / sd_i) ** 3))
    kurt = float(np.mean(((impostor - mu_i) / sd_i) ** 4) - 3)

    # ---- FAR / FRR curves and EER --------------------------------------------------------
    ts = np.linspace(0.30, 0.95, 651)
    imp_sorted, gen_sorted = np.sort(impostor), np.sort(genuine)
    far = 1 - np.searchsorted(imp_sorted, ts, side="left") / len(imp_sorted)
    frr = np.searchsorted(gen_sorted, ts, side="left") / len(gen_sorted)
    eer_i = int(np.argmin(np.abs(far - frr)))
    eer, eer_t = float((far[eer_i] + frr[eer_i]) / 2), float(ts[eer_i])

    # ---- 1:1 threshold: empirical FAR <= target ------------------------------------------
    k = int(TARGET_FAR_1TO1 * len(imp_sorted))
    t_verify = float(np.ceil(imp_sorted[-k] * 1000) / 1000)
    far_v = float(np.mean(impostor >= t_verify))
    frr_v = float(np.mean(genuine < t_verify))

    # ---- 1:N thresholds: Gaussian tail extrapolation ------------------------------------
    nd = NormalDist()

    def tail_threshold(far_n, n):
        p = per_comparison_far(far_n, n)
        z = nd.inv_cdf(1 - p)
        return p, z, mu_i + z * sd_i

    p_h, z_h, t_h = tail_threshold(TARGET_FAR_HALL, HALL_N)
    p_d, z_d, t_d = tail_threshold(TARGET_FAR_DB, DB_N)
    t_identify, t_dedup = float(np.ceil(t_h * 1000) / 1000), float(np.ceil(t_d * 1000) / 1000)
    frr_i = float(np.mean(genuine < t_identify))

    # check the Gaussian model against the empirical tail where data allows
    tail_check = []
    for p_chk in (1e-3, 1e-4, 1e-5):
        t_pred = mu_i + nd.inv_cdf(1 - p_chk) * sd_i
        tail_check.append(
            {"target_p": p_chk, "threshold": round(t_pred, 4), "empirical_far": float(np.mean(impostor >= t_pred))}
        )

    # ---- end-to-end 1:N validation on a hall roster --------------------------------------
    roster_t = templates[:HALL_N]
    hit = wrong = miss = 0
    fa = trials_out = 0
    for _ in range(GEN_ROUNDS):
        p_in = unit(noisy(base[:HALL_N], lognorm(rng, 0.65, 0.35, 0.3, 2.0, HALL_N), rng))
        s = p_in @ roster_t.T
        order = np.argsort(-s, axis=1)
        top1, top2 = s[np.arange(HALL_N), order[:, 0]], s[np.arange(HALL_N), order[:, 1]]
        ok = (top1 >= t_identify) & (top1 - top2 >= MARGIN)
        correct = order[:, 0] == np.arange(HALL_N)
        hit += int((ok & correct).sum())
        wrong += int((ok & ~correct).sum())
        miss += int((~ok).sum())
        p_out = unit(noisy(base[HALL_N:], lognorm(rng, 0.65, 0.35, 0.3, 2.0, N_ID - HALL_N), rng))
        so = np.sort(p_out @ roster_t.T, axis=1)
        fa += int(((so[:, -1] >= t_identify) & (so[:, -1] - so[:, -2] >= MARGIN)).sum())
        trials_out += len(so)
    n_in = GEN_ROUNDS * HALL_N
    e2e = {
        "roster_size": HALL_N,
        "genuine_trials": n_in,
        "correct_id_rate": hit / n_in,
        "misidentification_rate": wrong / n_in,
        "false_reject_rate": miss / n_in,
        "outsider_trials": trials_out,
        "outsider_false_accepts": fa,
        "outsider_far": fa / trials_out,
    }

    result = {
        "model": {
            "dim": DIM,
            "population_correlation": POPULATION_CORRELATION,
            "identities": N_ID,
            "enrol_sigma_median": 0.55,
            "probe_sigma_median": 0.65,
        },
        "counts": {"genuine": len(genuine), "impostor": len(impostor)},
        "genuine": {"mean": mu_g, "sd": sd_g, "min": float(genuine.min())},
        "impostor": {"mean": mu_i, "sd": sd_i, "skew": skew, "excess_kurtosis": kurt, "max": float(impostor.max())},
        "eer": {"value": eer, "threshold": eer_t},
        "enrolment": {"quality_min": ENROL_QMIN, "first_attempt_rejection": first_pass_reject},
        "verify_1to1": {
            "target_far": TARGET_FAR_1TO1,
            "threshold": t_verify,
            "far": far_v,
            "frr": frr_v,
            "frr_after_3_attempts_independent": frr_v**MAX_ATTEMPTS,
        },
        "identify_1toN": {
            "hall_n": HALL_N,
            "target_far_n": TARGET_FAR_HALL,
            "p_per_comparison": p_h,
            "z": z_h,
            "threshold_raw": t_h,
            "threshold": t_identify,
            "frr": frr_i,
            "margin": MARGIN,
        },
        "dedup": {
            "db_n": DB_N,
            "target_far_n": TARGET_FAR_DB,
            "p_per_comparison": p_d,
            "z": z_d,
            "threshold_raw": t_d,
            "threshold": t_dedup,
        },
        "gaussian_tail_check": tail_check,
        "end_to_end_identify": e2e,
    }
    out = ROOT / "reports" / "threshold_study.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result, indent=2))

    if args.write_policy:
        policy = {
            "verify_threshold": t_verify,
            "identify_threshold": t_identify,
            "identify_margin": MARGIN,
            "dedup_threshold": t_dedup,
            "enrol_quality_min": ENROL_QMIN,
            "max_attempts": MAX_ATTEMPTS,
        }
        (ROOT / "src" / "bioinvigil" / "match_policy.json").write_text(json.dumps(policy, indent=2) + "\n")

    # ---- figures -------------------------------------------------------------------------
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figdir = ROOT / "docs" / "figures"
    figdir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})

    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    bins = np.linspace(0, 1, 101)
    ax.hist(impostor[::20], bins=bins, density=True, alpha=0.75, color="#b4532a", label="Impostor")
    ax.hist(genuine, bins=bins, density=True, alpha=0.75, color="#1f6f8b", label="Genuine")
    ymax = ax.get_ylim()[1]
    marks = ((t_verify, "1:1 verify", "--"), (t_identify, "1:N identify", "-."), (t_dedup, "dedup", ":"))
    for i, (t, lab, ls) in enumerate(marks):
        ax.axvline(t, color="k", ls=ls, lw=1)
        ax.text(
            t - 0.008 if i == 0 else t + 0.008,
            ymax * (0.97 - 0.17 * i),
            f"{lab} {t:.3f}",
            fontsize=7.5,
            va="top",
            ha="right" if i == 0 else "left",
        )
    ax.set_xlabel("Cosine similarity score")
    ax.set_ylabel("Density")
    ax.legend(loc="upper left", frameon=False)
    fig.tight_layout()
    fig.savefig(figdir / "fig_score_distributions.png", dpi=200)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    ax.semilogy(ts, np.maximum(far, 1e-7), color="#b4532a", label="FAR (impostor accepted)")
    ax.semilogy(ts, np.maximum(frr, 1e-7), color="#1f6f8b", label="FRR (genuine rejected)")
    ax.scatter([eer_t], [eer], color="k", zorder=3)
    ax.annotate(
        f"EER = {eer * 100:.2f}% @ {eer_t:.3f}",
        (eer_t, eer),
        (eer_t - 0.33, eer * 25),
        fontsize=8,
        arrowprops={"arrowstyle": "-", "lw": 0.7},
    )
    for t, lab, ls in ((t_verify, "1:1", "--"), (t_identify, "1:N", "-."), (t_dedup, "dedup", ":")):
        ax.axvline(t, color="k", ls=ls, lw=1)
        ax.text(t + 0.006, 0.6, f"{lab} {t:.3f}", fontsize=7.5, rotation=90, va="top")
    ax.set_ylim(1e-6, 1.2)
    ax.set_xlabel("Decision threshold")
    ax.set_ylabel("Error rate (log scale)")
    ax.legend(frameon=False, loc="lower left")
    fig.tight_layout()
    fig.savefig(figdir / "fig_far_frr.png", dpi=200)
    plt.close(fig)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
