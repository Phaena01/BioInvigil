"""Provision a demo exam session on a running hub and write terminal files to ./demo.

python scripts/seed_demo.py --hub http://127.0.0.1:8000 --admin admin
"""

import argparse
import getpass
import os
from pathlib import Path

import httpx

from bioinvigil.demo import seed

ap = argparse.ArgumentParser()
ap.add_argument("--hub", default="http://127.0.0.1:8000")
ap.add_argument("--admin", default="admin")
ap.add_argument("--out", type=Path, default=Path("demo"))
ap.add_argument("--students", type=int, default=40)
args = ap.parse_args()

pw = os.environ.get("BIOINVIGIL_ADMIN_PASSWORD") or getpass.getpass("Admin password: ")
with httpx.Client(base_url=args.hub, timeout=30) as hub:
    info = seed(hub, args.admin, pw, args.out, students=args.students)

print(f"Provisioned {len(info['matrics'])} students, device {info['device_id']}, bundle {info['bundle_id']}")
print(f"Sample matrics: {', '.join(info['matrics'][:3])} ...")
print("Staff credentials (shown once):")
for user, c in info["creds"].items():
    print(f"  {user:10s} {c['role']:18s} {c['password']}")
print(f"Keystore passphrase: {info['passphrase']}")
print(f"Files in {args.out}/: keys.enc bundle.json hub_pub.txt")
