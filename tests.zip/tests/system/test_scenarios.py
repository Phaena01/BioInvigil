"""BDD-style acceptance scenarios (Given / When / Then) exercising hub + terminal + sync together."""

import pytest

from tests.integration.test_sync import FlakyClient

pytestmark = pytest.mark.system


def chief_pw(env):
    return env.info["creds"]["chief1"]["password"]


@pytest.mark.req("FR-07", "FR-14", "FR-17", "NFR-04")
def test_scenario_normal_exam_morning_fully_offline(env):
    """
    Given a hall terminal provisioned with a signed bundle and no network at all
    When all 12 registered students present their ID number and finger
    Then every student is admitted offline, and after the exam the hub reports 100% attendance
    """
    t, store, keys = env.terminal()
    net = FlakyClient(env.client)  # network down for the entire exam
    agent = env.sync_agent(store, keys, t.bundle_id, client=net)
    for m in env.info["matrics"]:
        assert t.verify(m, env.probe(m), "invig1").outcome == "ADMIT"
        agent.push()  # opportunistic sync attempts fail silently
    assert t.status()["admitted"] == 12 and net.calls == 12
    net.online = True
    assert agent.push()["status"] == "synced"
    rep = env.client.get(f"/sessions/{env.info['session_id']}/report", headers=env.login("auditor1")).json()
    assert rep["attendance_rate"] == 1.0 and rep["absent"] == [] and rep["integrity"] and not rep["alerts"]


@pytest.mark.req("FR-09", "FR-12", "FR-16", "FR-17")
def test_scenario_impersonation_attempt_is_stopped_and_escalated(env):
    """
    Given an impostor holding another student's ID card
    When the impostor fails fingerprint verification three times
    Then the identity is locked, a high-severity alert reaches the hub,
     and only a second-person chief approval can admit the real student (recorded as an override)
    """
    m = env.info["matrics"]
    t, store, keys = env.terminal()
    outs = [t.verify(m[0], env.probe(m[1]), "invig1").outcome for _ in range(3)]
    assert outs[-1] == "REVIEW_REQUIRED" and m[0] not in store.admitted()
    assert t.verify(m[0], env.probe(m[0]), "invig1").outcome == "REVIEW_REQUIRED"  # still locked
    t.override(m[0], "OTHER", "identity confirmed by chief", "chief1", chief_pw(env), "invig1")
    env.sync_agent(store, keys, t.bundle_id).push()
    types = {a["type"] for a in env.svc.list_alerts(env.info["session_id"])}
    assert {"POSSIBLE_IMPERSONATION", "MANUAL_OVERRIDE"} <= types
    assert env.svc.session_report(env.info["session_id"])["by_mode"] == {"OVERRIDE": 1}


@pytest.mark.req("FR-08")
def test_scenario_student_without_id_card(env):
    """
    Given a student who lost their ID card
    When the invigilator runs a 1:N identification on the student's finger
    Then the student is identified within the hall roster and admitted (mode recorded as 1:N)
    """
    t, store, _ = env.terminal()
    m = env.info["matrics"][9]
    d = t.identify(env.probe(m), "invig1")
    assert (d.outcome, d.matric_no, d.seat_no) == ("ADMIT", m, "A010")


@pytest.mark.req("FR-10")
def test_scenario_student_at_wrong_hall(env):
    """
    Given a student registered for a different hall of the same exam
    When they present at this terminal
    Then they are redirected to their registered hall and no admission is recorded
    """
    t, store, _ = env.terminal()
    t.directory["U20CS7777"] = "AGRIC-1"
    d = t.verify("U20CS7777", env.probe("U20CS7777"), "invig1")
    assert d.outcome == "WRONG_HALL" and "AGRIC-1" in d.message and not store.admitted()


@pytest.mark.req("NFR-05", "FR-11")
def test_scenario_power_cut_mid_exam(env, tmp_path):
    """
    Given 5 students admitted and the terminal then loses power
    When the terminal restarts from its database file
    Then the 5 admissions are intact, the hash chain is valid, and nobody can be admitted twice
    """
    db = tmp_path / "powercut.db"
    t, store, keys = env.terminal(db=db)
    for m in env.info["matrics"][:5]:
        t.verify(m, env.probe(m), "invig1")
    del t, store
    t2, store2, _ = env.terminal(db=db, keys=keys)
    assert len(store2.admitted()) == 5 and store2.verify()[0]
    assert t2.verify(env.info["matrics"][0], env.probe(env.info["matrics"][0]), "invig1").outcome == "ALREADY_ADMITTED"
    assert t2.verify(env.info["matrics"][5], env.probe(env.info["matrics"][5]), "invig1").outcome == "ADMIT"
    assert store2.verify()[0]


@pytest.mark.req("FR-13", "FR-15", "FR-16")
def test_scenario_compromised_terminal_cannot_hide_a_rejection(env):
    """
    Given a corrupt invigilator who edits the terminal database to erase a failed verification
    When the terminal later syncs
    Then the hub refuses the batch because the hash chain no longer verifies, stores nothing and raises an alert
    """
    m = env.info["matrics"]
    t, store, keys = env.terminal()
    t.verify(m[0], env.probe(m[0]), "invig1")
    t.verify(m[1], env.probe(m[2]), "invig1")  # failed verification (impostor)
    t.verify(m[3], env.probe(m[3]), "invig1")
    store.conn.execute("DELETE FROM events WHERE type='REJECT'")
    res = env.sync_agent(store, keys, t.bundle_id).push()
    assert res["status"] == "rejected" and env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"] == 0
    assert "CHAIN_GAP" in {a["type"] for a in env.svc.list_alerts(env.info["session_id"])}


@pytest.mark.req("FR-05", "FR-14")
def test_scenario_stolen_terminal_is_revoked(env):
    """
    Given a terminal reported stolen
    When the administrator revokes it and the thief tries to upload events
    Then the hub rejects the upload and no new bundle can be issued to the device
    """
    t, store, keys = env.terminal()
    t.verify(env.info["matrics"][0], env.probe(env.info["matrics"][0]), "invig1")
    admin = env.login("admin")
    env.client.post(f"/devices/{keys.device_id}/revoke", headers=admin)
    assert env.sync_agent(store, keys, t.bundle_id).push()["http"] == 401
    r = env.client.post(
        f"/sessions/{env.info['session_id']}/bundles",
        headers=admin,
        json={"hall_id": env.info["hall_id"], "device_id": keys.device_id},
    )
    assert r.status_code == 403


@pytest.mark.req("FR-03", "FR-01")
def test_scenario_student_registers_twice_to_enable_impersonation(env):
    """
    Given a student already enrolled under matric A
    When a registrar tries to enrol the same finger under a second matric B
    Then enrolment is blocked and the existing identity is reported for adjudication
    """
    victim = env.info["matrics"][0]
    body = {
        "matric_no": "U20CS3001",
        "full_name": "Second Identity",
        "department": "Computer Engineering",
        "level": 500,
        "consent": True,
        "captures": [env.probe(victim) for _ in range(3)],
    }
    r = env.client.post("/students", headers=env.login("registrar1"), json=body)
    assert r.status_code == 409 and r.json()["matches"] == victim


@pytest.mark.req("FR-19", "NFR-12")
def test_scenario_invigilator_uses_terminal_ui(env):
    """
    Given a running terminal API with the UI enabled
    When an invigilator signs in, verifies a student with a simulated finger and requests a sync
    Then the UI is served, the decision is returned, and the status counters update
    """
    from fastapi.testclient import TestClient

    from bioinvigil.edge.api import create_edge_app

    t, store, keys = env.terminal()
    ui = TestClient(create_edge_app(t, env.sync_agent(store, keys, t.bundle_id), simulator=True))
    page = ui.get("/")
    assert page.status_code == 200 and "Hall Terminal" in page.text and 'id="verifyBtn"' in page.text
    assert "default-src 'self'" in page.headers["content-security-policy"]
    assert ui.get("/static/app.js").status_code == 200
    tok = ui.post("/api/login", json={"username": "invig1", "password": env.info["creds"]["invig1"]["password"]}).json()
    h = {"Authorization": f"Bearer {tok['access_token']}"}
    m = env.info["matrics"][0]
    probe = ui.post("/api/sim/capture", headers=h, json={"finger_of": m, "quality": "good"}).json()["probe"]
    d = ui.post("/api/verify", headers=h, json={"matric_no": m, "probe": probe}).json()
    assert d["outcome"] == "ADMIT" and d["name"] == "Student 001"
    assert ui.get("/api/status", headers=h).json()["admitted"] == 1
    assert ui.post("/api/sync", headers=h).json()["status"] == "synced"
    assert ui.get("/health").json()["status"] == "ok"
    assert "SCANNER_FAULT" in ui.get("/api/override-reasons", headers=h).json()
