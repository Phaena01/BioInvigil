"""Traceability gate: every requirement is covered, every marker and threat reference is valid."""

import importlib.util
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
spec_path = ROOT / "docs" / "build" / "spec.py"
_spec = importlib.util.spec_from_file_location("spec", spec_path)
spec = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(spec)

TEST_SOURCES = {p: p.read_text() for p in (ROOT / "tests").rglob("test_*.py") if p.name != "test_traceability.py"}
MARKER = re.compile(r"pytest\.mark\.req\(([^)]*)\)")
FUNC = re.compile(r"^def (test_\w+)", re.M)


def used_ids() -> set[str]:
    return {i for src in TEST_SOURCES.values() for m in MARKER.findall(src) for i in re.findall(r'"([A-Z]+-\d+)"', m)}


@pytest.mark.req("NFR-14")
def test_every_marked_requirement_exists():
    known = {r["id"] for r in spec.REQUIREMENTS}
    assert used_ids() <= known, used_ids() - known


@pytest.mark.req("NFR-14")
def test_every_testable_requirement_has_at_least_one_test():
    missing = [r["id"] for r in spec.REQUIREMENTS if "Test" in r["method"] and r["id"] not in used_ids()]
    assert not missing, missing


@pytest.mark.req("NFR-14")
def test_threat_model_evidence_references_real_tests():
    names = {f for src in TEST_SOURCES.values() for f in FUNC.findall(src)}
    bad = [(t[0], n) for t in spec.THREATS for n in t[5] if n not in names]
    assert not bad, bad


@pytest.mark.req("NFR-14")
def test_requirement_ids_are_unique_and_complete():
    ids = [r["id"] for r in spec.REQUIREMENTS]
    assert len(ids) == len(set(ids))
    assert {f"FR-{i:02d}" for i in range(1, 20)} | {f"NFR-{i:02d}" for i in range(1, 16)} == set(ids)
