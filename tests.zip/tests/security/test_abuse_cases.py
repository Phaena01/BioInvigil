"""Dynamic security tests: each maps to a STRIDE threat in the threat model (docs/Threat_Model)."""

import base64
import json
import sys
import time

import jwt
import pytest
from fastapi.testclient import TestClient

from bioinvigil.biometric import DIM
from bioinvigil.config import Settings
from bioinvigil.edge.api import create_edge_app
from bioinvigil.errors import AuthError

pytestmark = pytest.mark.security


def b64u(d: dict) -> str:
    return base64.urlsafe_b64encode(json.dumps(d).encode()).rstrip(b"=").decode()


# ------------------------------------------------------------------- Spoofing
@pytest.mark.req("NFR-09")
def test_jwt_alg_none_is_rejected(env):
    now = int(time.time())
    header = b64u({"alg": "none", "typ": "JWT"})
    body = b64u({"sub": "admin", "role": "admin", "iat": now, "exp": now + 600})
    forged = f"{header}.{body}."
    r = env.client.post(
        "/halls", headers={"Authorization": f"Bearer {forged}"}, json={"id": "X1", "name": "Hall X", "capacity": 5}
    )
    assert r.status_code == 401


@pytest.mark.req("NFR-09")
def test_jwt_signed_with_wrong_secret_or_expired_or_tampered_role(env):
    now = int(time.time())
    claims = {"sub": "auditor1", "role": "admin", "iat": now, "exp": now + 600}
    bad_secret = jwt.encode(claims, b"x" * 32, algorithm="HS256")
    expired = jwt.encode({**claims, "role": "auditor", "exp": now - 10}, env.settings.jwt_secret, algorithm="HS256")
    escalated = jwt.encode(claims, env.settings.jwt_secret, algorithm="HS256")  # valid signature, forged role
    for tok in (bad_secret, expired, escalated):
        r = env.client.post(
            "/halls", headers={"Authorization": f"Bearer {tok}"}, json={"id": "X1", "name": "Hall X", "capacity": 5}
        )
        assert r.status_code == 401, tok


@pytest.mark.req("NFR-09")
def test_token_missing_required_claims_or_unknown_user_rejected(env):
    now = int(time.time())
    no_exp = jwt.encode({"sub": "admin", "role": "admin", "iat": now}, env.settings.jwt_secret, algorithm="HS256")
    ghost = jwt.encode(
        {"sub": "ghost", "role": "admin", "iat": now, "exp": now + 60}, env.settings.jwt_secret, algorithm="HS256"
    )
    for tok in (no_exp, ghost):
        assert env.client.get("/students/U20CS1001", headers={"Authorization": f"Bearer {tok}"}).status_code == 401


@pytest.mark.req("FR-18")
def test_missing_or_malformed_authorization_header(env):
    for h in ({}, {"Authorization": "Basic abc"}, {"Authorization": "Bearer"}, {"Authorization": "Bearer a.b.c"}):
        assert env.client.get("/sessions/x/report", headers=h).status_code == 401


@pytest.mark.req("FR-18")
def test_deactivated_user_token_stops_working(env):
    h = env.login("auditor1")
    assert env.client.get(f"/sessions/{env.info['session_id']}/alerts", headers=h).status_code == 200
    env.svc.conn.execute("UPDATE users SET active=0 WHERE username='auditor1'")
    assert env.client.get(f"/sessions/{env.info['session_id']}/alerts", headers=h).status_code == 401
    with pytest.raises(AuthError):
        env.svc.authenticate("auditor1", env.info["creds"]["auditor1"]["password"])


# ---------------------------------------------------------- Elevation / RBAC
RBAC = [
    # method, path, body-factory-name, {role: expected-status-class}
    (
        "POST",
        "/halls",
        {"id": "H9", "name": "Hall Nine", "capacity": 10},
        {"admin": 201, "registrar": 403, "auditor": 403, "invigilator": 403},
    ),
    (
        "POST",
        "/devices",
        {"name": "Terminal-Z", "sign_pub": "A" * 44, "kex_pub": "A" * 44},
        {"admin": 201, "registrar": 403, "auditor": 403, "chief_invigilator": 403},
    ),
    ("GET", "/sessions/{sid}/report", None, {"admin": 200, "auditor": 200, "registrar": 403, "invigilator": 403}),
    (
        "GET",
        "/sessions/{sid}/attendance",
        None,
        {"admin": 200, "auditor": 200, "registrar": 403, "chief_invigilator": 403},
    ),
    ("GET", "/sessions/{sid}/integrity", None, {"admin": 200, "auditor": 200, "registrar": 403}),
    ("GET", "/students/U20CS1001", None, {"admin": 200, "registrar": 200, "auditor": 403, "invigilator": 403}),
    (
        "POST",
        "/users",
        {"username": "newuser", "password": "Very-Long-Passw0rd!", "role": "auditor"},
        {"admin": 201, "registrar": 403, "auditor": 403},
    ),
]


@pytest.mark.req("FR-18")
@pytest.mark.parametrize("method,path,body,expect", RBAC)
def test_rbac_matrix(env, method, path, body, expect):
    users = {
        "admin": "admin",
        "registrar": "registrar1",
        "auditor": "auditor1",
        "invigilator": "invig1",
        "chief_invigilator": "chief1",
    }
    for role, status in expect.items():
        r = env.client.request(
            method, path.format(sid=env.info["session_id"]), headers=env.login(users[role]), json=body
        )
        assert r.status_code == status, f"{role} {method} {path}: {r.status_code} {r.text}"


@pytest.mark.req("FR-18")
def test_unauthenticated_access_denied_everywhere(env):
    sid = env.info["session_id"]
    for method, path in (
        ("POST", "/students"),
        ("POST", "/halls"),
        ("POST", "/devices"),
        ("POST", "/users"),
        ("GET", f"/sessions/{sid}/report"),
        ("GET", f"/sessions/{sid}/alerts"),
        ("POST", f"/sessions/{sid}/bundles"),
        ("GET", "/students/U20CS1001"),
    ):
        assert env.client.request(method, path, json={}).status_code == 401, path


@pytest.mark.req("FR-18")
def test_terminal_api_requires_login(env):
    t, store, keys = env.terminal()
    ui = TestClient(create_edge_app(t))
    for method, path in (
        ("GET", "/api/status"),
        ("POST", "/api/verify"),
        ("POST", "/api/identify"),
        ("POST", "/api/override"),
        ("POST", "/api/sync"),
        ("POST", "/api/sim/capture"),
    ):
        assert ui.request(method, path, json={}).status_code == 401, path


# ----------------------------------------------------------------- Tampering
@pytest.mark.req("NFR-08")
def test_replayed_batch_is_idempotent(env):
    t, store, keys = env.terminal()
    t.verify(env.info["matrics"][0], env.probe(env.info["matrics"][0]), "invig1")
    agent = env.sync_agent(store, keys, t.bundle_id)
    batch = agent._batch(store.after(0))
    first = env.client.post("/sync/ingest", json=batch).json()
    replay = env.client.post("/sync/ingest", json=batch).json()
    assert first["accepted"] == 2 and replay["accepted"] == 0 and replay["duplicates"] == 2
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"] == 2


@pytest.mark.req("NFR-08")
def test_ingest_rejects_malformed_events(env):
    t, store, keys = env.terminal()
    agent = env.sync_agent(store, keys, t.bundle_id)
    ev = store.after(0)[0]
    for broken in ({**ev, "seq": "1"}, {**ev, "payload": "x"}, {**ev, "seq": True}, {**ev, "ts": None}, "junk"):
        batch = agent._batch([broken])
        assert env.client.post("/sync/ingest", json=batch).status_code == 422
    assert env.client.post("/sync/ingest", json=agent._batch([])).status_code == 422
    assert env.client.post("/sync/ingest", json={"device_id": "x"}).status_code == 422
    assert env.client.post("/sync/ingest", json=agent._batch([{**ev, "device_id": "DEV-OTHER"}])).status_code == 422


# ---------------------------------------------------------- Injection / input
INJECTIONS = [
    "U20CS1001' OR '1'='1",
    "U20CS1001'; DROP TABLE students;--",
    "../../etc/passwd",
    "U20CS1001%00",
    "<script>alert(1)</script>",
]


@pytest.mark.req("NFR-10")
@pytest.mark.parametrize("payload", INJECTIONS)
def test_injection_strings_are_rejected_and_database_intact(env, payload):
    h = env.login("registrar1")
    assert env.client.get(f"/students/{payload}", headers=h).status_code in (404, 422)
    r = env.client.post(
        "/students",
        headers=h,
        json={
            "matric_no": payload,
            "full_name": "X Y",
            "department": "CE",
            "level": 100,
            "consent": True,
            "captures": [[0.1] * DIM] * 3,
        },
    )
    assert r.status_code == 422
    login = env.client.post("/auth/login", json={"username": payload, "password": payload})
    assert login.status_code == 401
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM students").fetchone()["n"] == 12
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM users").fetchone()["n"] == 5


@pytest.mark.req("NFR-10")
def test_parameterised_queries_used_for_free_text_fields(env):
    h = env.login("registrar1")
    name = "Robert'); DROP TABLE students;--"
    body = {
        "matric_no": "U20CS4001",
        "full_name": name,
        "department": "Computer Engineering",
        "level": 500,
        "consent": True,
        "captures": [env.probe("U20CS4001") for _ in range(3)],
    }
    assert env.client.post("/students", headers=h, json=body).status_code == 201
    assert env.client.get("/students/U20CS4001", headers=h).json()["full_name"] == name
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM students").fetchone()["n"] == 13


@pytest.mark.req("NFR-09")
def test_unknown_fields_and_wrong_vector_sizes_rejected(env):
    h = env.login("registrar1")
    base = {"matric_no": "U20CS4002", "full_name": "A B", "department": "CE", "level": 100, "consent": True}
    caps = [[0.1] * DIM] * 3
    assert env.client.post("/students", headers=h, json={**base, "captures": caps, "role": "admin"}).status_code == 422
    assert (
        env.client.post("/students", headers=h, json={**base, "captures": [[0.1] * (DIM + 1)] * 3}).status_code == 422
    )
    nan_body = json.dumps({**base, "captures": [[float("nan")] * DIM] * 3})
    r = env.client.post("/students", headers={**h, "Content-Type": "application/json"}, content=nan_body)
    assert r.status_code == 422


@pytest.mark.req("NFR-10")
def test_validation_errors_never_echo_submitted_secrets(env):
    secret = "S3cret-" + "x" * 200
    r = env.client.post("/auth/login", json={"username": "admin", "password": secret})
    assert r.status_code == 422 and secret not in r.text and "S3cret" not in r.text


# ------------------------------------------------------- Information disclosure
@pytest.mark.req("NFR-07", "NFR-10")
def test_biometric_templates_never_appear_in_any_api_response(env):
    sid, a, r = env.info["session_id"], env.login("admin"), env.login("registrar1")
    texts = [
        env.client.get(f"/students/{env.info['matrics'][0]}", headers=r).text,
        env.client.get(f"/sessions/{sid}/report", headers=a).text,
        env.client.get(f"/sessions/{sid}/attendance", headers=a).text,
        env.client.get(f"/sessions/{sid}/alerts", headers=a).text,
    ]
    assert not any("template" in t.lower() or "captures" in t.lower() for t in texts)


@pytest.mark.req("NFR-07")
def test_templates_encrypted_in_hub_database_and_wrong_master_key_fails(env):
    from bioinvigil.crypto import CryptoError, aead_decrypt

    row = env.svc.conn.execute("SELECT matric_no, template_enc FROM students LIMIT 1").fetchone()
    with pytest.raises(CryptoError):
        aead_decrypt(b"\x00" * 32, row["template_enc"], row["matric_no"].encode())
    with pytest.raises(CryptoError):  # ciphertext is bound to its owner: cannot be moved to another record
        aead_decrypt(env.settings.master_key, row["template_enc"], b"U20CS9999")


@pytest.mark.req("NFR-07", "NFR-10")
def test_probes_are_not_stored_in_event_log(env):
    t, store, _ = env.terminal()
    m = env.info["matrics"][0]
    probe = env.probe(m)
    t.verify(m, probe, "invig1")
    dump = json.dumps(store.all())
    assert str(probe[0]) not in dump and str(round(probe[0], 3)) not in dump
    assert set(store.all()[-1]["payload"]) == {"mode", "score", "actor"}


@pytest.mark.req("NFR-07")
def test_terminal_disk_holds_no_plaintext_templates_or_names(env, tmp_path):
    t, store, keys = env.terminal(db=tmp_path / "disk.db")
    m = env.info["matrics"][0]
    t.verify(m, env.probe(m), "invig1")
    store.conn.execute("PRAGMA wal_checkpoint(FULL)")
    raw = b"".join(p.read_bytes() for p in tmp_path.glob("disk.db*")) + (tmp_path / "demo" / "keys.enc").read_bytes()
    assert b"Student 001" not in raw and b"Student 002" not in raw
    assert keys.sign.private_bytes() not in raw and keys.kex.private_bytes() not in raw


@pytest.mark.req("NFR-10")
def test_security_headers_present(env):
    r = env.client.get("/health")
    assert r.headers["cache-control"] == "no-store" and r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert env.client.get("/openapi.json").status_code == 404 and env.client.get("/docs").status_code == 404


# ---------------------------------------------------------------- DoS / abuse
@pytest.mark.req("NFR-09")
def test_hub_brute_force_is_throttled_by_lockout(env):
    codes = [
        env.client.post("/auth/login", json={"username": "invig1", "password": f"guess{i}"}).status_code
        for i in range(8)
    ]
    assert set(codes) == {401}
    row = env.svc.conn.execute("SELECT locked_until FROM users WHERE username='invig1'").fetchone()
    assert row["locked_until"] > env.clock()


@pytest.mark.req("NFR-09")
def test_oversized_batch_is_rejected(env):
    t, store, keys = env.terminal()
    for _ in range(3):
        store.append("NO_MATCH", None, {})
    agent = env.sync_agent(store, keys, t.bundle_id)
    from bioinvigil.central import service

    original = service.MAX_BATCH
    service.MAX_BATCH = 2
    try:
        assert env.client.post("/sync/ingest", json=agent._batch(store.after(0))).status_code == 422
    finally:
        service.MAX_BATCH = original


# -------------------------------------------------------------- Fail securely
@pytest.mark.req("NFR-11")
def test_production_refuses_to_start_without_secrets(monkeypatch, tmp_path):
    for k in ("BIOINVIGIL_JWT_SECRET", "BIOINVIGIL_MASTER_KEY", "BIOINVIGIL_HUB_SIGNING_KEY"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("BIOINVIGIL_ENV", "production")
    with pytest.raises(RuntimeError, match="production requires"):
        Settings.from_env()


@pytest.mark.req("NFR-11")
def test_development_keys_are_persisted_with_restrictive_permissions(monkeypatch, tmp_path):
    import stat

    for k in ("BIOINVIGIL_JWT_SECRET", "BIOINVIGIL_MASTER_KEY", "BIOINVIGIL_HUB_SIGNING_KEY"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("BIOINVIGIL_ENV", "development")
    monkeypatch.setenv("BIOINVIGIL_DB", str(tmp_path / "hub.db"))
    a = Settings.from_env()
    b = Settings.from_env()
    assert a.jwt_secret == b.jwt_secret and a.hub_key.public_b64() == b.hub_key.public_b64()
    if sys.platform != "win32":  # no POSIX mode bits on Windows; access follows the folder's NTFS ACL
        assert stat.S_IMODE((tmp_path / "hub.db.devkeys.json").stat().st_mode) == 0o600


@pytest.mark.req("NFR-11")
def test_simulator_endpoint_absent_unless_explicitly_enabled(env):
    t, _, _ = env.terminal()
    ui = TestClient(create_edge_app(t, simulator=False))
    tok = ui.post("/api/login", json={"username": "invig1", "password": env.info["creds"]["invig1"]["password"]}).json()
    r = ui.post(
        "/api/sim/capture",
        headers={"Authorization": f"Bearer {tok['access_token']}"},
        json={"finger_of": env.info["matrics"][0]},
    )
    assert r.status_code == 404


@pytest.mark.req("NFR-11", "FR-12")
def test_override_via_api_denied_without_valid_chief_approval(env):
    t, store, _ = env.terminal()
    ui = TestClient(create_edge_app(t))
    tok = ui.post("/api/login", json={"username": "invig1", "password": env.info["creds"]["invig1"]["password"]}).json()
    h = {"Authorization": f"Bearer {tok['access_token']}"}
    body = {
        "matric_no": env.info["matrics"][0],
        "reason_code": "OTHER",
        "note": "",
        "approver_username": "invig1",
        "approver_password": env.info["creds"]["invig1"]["password"],
    }
    assert ui.post("/api/override", headers=h, json=body).status_code == 403
    assert not store.admitted()
