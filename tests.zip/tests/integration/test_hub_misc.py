import sys
from pathlib import Path

import jwt
import pytest
from fastapi.testclient import TestClient

from bioinvigil import audit
from bioinvigil.central.service import CentralService
from bioinvigil.config import Settings
from bioinvigil.crypto import b64e
from bioinvigil.edge.api import create_edge_app
from bioinvigil.errors import AuthError, Conflict, InvalidInput, NotFound

pytestmark = pytest.mark.integration


@pytest.mark.req("FR-18")
def test_user_management_validation(env):
    with pytest.raises(InvalidInput):
        env.svc.create_user("x1", "Long-Enough-Passw0rd", "superuser")
    with pytest.raises(Conflict):
        env.svc.create_user("admin", "Another-Long-Passw0rd", "admin")


@pytest.mark.req("FR-04", "FR-06")
def test_provisioning_preconditions(env):
    s = env.svc
    with pytest.raises(Conflict):
        s.assign_invigilator(env.info["session_id"], env.info["hall_id"], "invig1", "admin")  # duplicate
    with pytest.raises(NotFound):
        s.issue_bundle(session_id="NOPE", hall_id="H2", device_id="DEV-X", valid_hours=1, actor="admin")
    with pytest.raises(InvalidInput):
        s.issue_bundle(
            session_id=env.info["session_id"],
            hall_id=env.info["hall_id"],
            device_id=env.info["device_id"],
            valid_hours=0,
            actor="admin",
        )
    # hall without a chief invigilator cannot be provisioned
    s.conn.execute("DELETE FROM assignments WHERE username='chief1'")
    with pytest.raises(Conflict, match="chief"):
        s.issue_bundle(
            session_id=env.info["session_id"],
            hall_id=env.info["hall_id"],
            device_id=env.info["device_id"],
            valid_hours=1,
            actor="admin",
        )


@pytest.mark.req("FR-15")
def test_hub_rejects_signed_batch_with_unknown_event_type(env):
    t, store, keys = env.terminal()
    agent = env.sync_agent(store, keys, t.bundle_id)
    good = store.after(0)[0]
    evil = {**good, "type": "GRANT_ALL", "seq": 1}
    evil["hash"] = audit.compute_hash(evil)  # attacker with a valid device key crafts a consistent chain
    assert env.client.post("/sync/ingest", json=agent._batch([evil])).status_code == 422
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"] == 0


@pytest.mark.req("FR-18")
def test_terminal_rejects_token_for_user_not_in_bundle(env):
    t, _, _ = env.terminal()
    forged = jwt.encode(
        {"sub": "ghost", "role": "chief_invigilator", "exp": 4_000_000_000}, b"x" * 32, algorithm="HS256"
    )
    with pytest.raises(AuthError):
        t.user_from_token(forged)
    own = jwt.encode({"sub": "ghost", "role": "invigilator", "exp": 4_000_000_000}, t._jwt_secret, algorithm="HS256")
    with pytest.raises(AuthError, match="unknown user"):
        t.user_from_token(own)


@pytest.mark.req("FR-19")
def test_terminal_api_identify_and_sync_not_configured(env):
    t, _, _ = env.terminal()
    ui = TestClient(create_edge_app(t))
    tok = ui.post("/api/login", json={"username": "invig1", "password": env.info["creds"]["invig1"]["password"]}).json()
    h = {"Authorization": f"Bearer {tok['access_token']}"}
    m = env.info["matrics"][4]
    d = ui.post("/api/identify", headers=h, json={"probe": env.probe(m)}).json()
    assert d["outcome"] == "ADMIT" and d["matric_no"] == m
    assert ui.post("/api/sync", headers=h).json() == {"status": "not_configured"}
    r = ui.post("/api/verify", headers=h, json={"matric_no": m, "probe": [1.0]})
    assert r.status_code == 422 and "probe" in r.text


@pytest.mark.req("NFR-11")
def test_settings_from_environment(monkeypatch):
    from bioinvigil.crypto import SigningKey

    monkeypatch.setenv("BIOINVIGIL_ENV", "production")
    monkeypatch.setenv("BIOINVIGIL_JWT_SECRET", b64e(b"j" * 32))
    monkeypatch.setenv("BIOINVIGIL_MASTER_KEY", b64e(b"m" * 32))
    monkeypatch.setenv("BIOINVIGIL_HUB_SIGNING_KEY", b64e(SigningKey.generate().private_bytes()))
    s = Settings.from_env()
    assert s.env == "production" and s.master_key == b"m" * 32


def test_central_cli_create_admin_and_serve(monkeypatch, tmp_path):
    from bioinvigil.central import __main__ as cli

    for k in ("BIOINVIGIL_JWT_SECRET", "BIOINVIGIL_MASTER_KEY", "BIOINVIGIL_HUB_SIGNING_KEY"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("BIOINVIGIL_ENV", "development")
    monkeypatch.setenv("BIOINVIGIL_DB", str(tmp_path / "cli.db"))
    monkeypatch.setenv("BIOINVIGIL_ADMIN_PASSWORD", "Cli-Admin-Passw0rd!")
    monkeypatch.setattr(sys, "argv", ["bioinvigil.central", "create-admin", "root"])
    cli.main()
    svc = CentralService(Settings.from_env())
    assert svc.authenticate("root", "Cli-Admin-Passw0rd!")["role"] == "admin"
    svc.close()
    called = {}
    monkeypatch.setattr(cli.uvicorn, "run", lambda app, host, port: called.update(host=host, port=port))
    monkeypatch.setattr(sys, "argv", ["bioinvigil.central", "serve"])
    cli.main()
    assert called == {"host": "127.0.0.1", "port": 8000}  # loopback by default


def test_edge_cli_builds_working_app(env, monkeypatch):
    from bioinvigil.edge import __main__ as cli

    p = env.info["paths"]
    from tests.conftest import PASSPHRASE

    app = cli.build_app(
        Path(p["bundle"]),
        Path(p["keys"]),
        Path(p["hub_pub"]),
        env.tmp / "cli_term.db",
        "http://127.0.0.1:9",
        PASSPHRASE,
        simulator=True,
    )
    ui = TestClient(app)
    assert ui.get("/health").json()["bundle"] == env.info["bundle_id"]
    called = {}
    monkeypatch.setattr(cli.uvicorn, "run", lambda app, host, port: called.update(host=host, port=port))
    monkeypatch.setenv("BIOINVIGIL_KEY_PASSPHRASE", PASSPHRASE)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "bioinvigil.edge",
            "--bundle",
            p["bundle"],
            "--keys",
            p["keys"],
            "--hub-pub",
            p["hub_pub"],
            "--db",
            str(env.tmp / "cli2.db"),
        ],
    )
    cli.main()
    assert called == {"host": "127.0.0.1", "port": 8001}
