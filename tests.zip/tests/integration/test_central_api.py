import json

import pytest

from tests.conftest import ADMIN_PW

pytestmark = pytest.mark.integration


def enrol_body(env, matric, name="Test Person", quality="good", consent=True, n=3, **extra):
    return {
        "matric_no": matric,
        "full_name": name,
        "department": "Computer Engineering",
        "level": 500,
        "consent": consent,
        "captures": [env.probe(matric, quality) for _ in range(n)],
        **extra,
    }


# ------------------------------------------------------------- authentication
@pytest.mark.req("FR-18")
def test_login_success_and_failure(env):
    ok = env.client.post("/auth/login", json={"username": "admin", "password": ADMIN_PW})
    assert ok.status_code == 200 and ok.json()["role"] == "admin"
    bad = env.client.post("/auth/login", json={"username": "admin", "password": "nope"})
    unknown = env.client.post("/auth/login", json={"username": "ghost", "password": "nope"})
    assert bad.status_code == unknown.status_code == 401
    assert bad.json()["detail"] == unknown.json()["detail"]  # no username enumeration


@pytest.mark.req("FR-18", "NFR-09")
def test_account_lockout_after_repeated_failures(env):
    for _ in range(5):
        env.client.post("/auth/login", json={"username": "auditor1", "password": "wrong"})
    r = env.client.post(
        "/auth/login", json={"username": "auditor1", "password": env.info["creds"]["auditor1"]["password"]}
    )
    assert r.status_code == 401 and "locked" in r.json()["detail"]
    env.clock.advance(301)
    r = env.client.post(
        "/auth/login", json={"username": "auditor1", "password": env.info["creds"]["auditor1"]["password"]}
    )
    assert r.status_code == 200


@pytest.mark.req("FR-18", "NFR-09")
def test_weak_password_rejected_on_user_creation(env):
    r = env.client.post(
        "/users", headers=env.login("admin"), json={"username": "weak1", "password": "short", "role": "auditor"}
    )
    assert r.status_code == 422


# ------------------------------------------------------------------ enrolment
@pytest.mark.req("FR-01")
def test_enrol_student_stores_encrypted_template_only(env):
    r = env.client.post("/students", headers=env.login("registrar1"), json=enrol_body(env, "U20CS2001"))
    assert r.status_code == 201 and r.json()["quality"] > 0.6
    row = env.svc.conn.execute("SELECT template_enc FROM students WHERE matric_no='U20CS2001'").fetchone()
    assert len(row["template_enc"]) == 12 + 128 * 4 + 16  # nonce + float32 vector + GCM tag
    assert "template" not in json.dumps(env.client.get("/students/U20CS2001", headers=env.login("registrar1")).json())


@pytest.mark.req("FR-01", "NFR-10")
def test_enrolment_requires_explicit_consent(env):
    r = env.client.post("/students", headers=env.login("registrar1"), json=enrol_body(env, "U20CS2002", consent=False))
    assert r.status_code == 422 and "consent" in r.json()["detail"]


@pytest.mark.req("FR-02")
def test_poor_quality_capture_is_rejected_for_recapture(env):
    r = env.client.post("/students", headers=env.login("registrar1"), json=enrol_body(env, "U20CS2003", quality="poor"))
    assert r.status_code == 422 and "quality" in r.json()["detail"]
    assert env.client.get("/students/U20CS2003", headers=env.login("registrar1")).status_code == 404


@pytest.mark.req("FR-03")
def test_duplicate_biometric_under_new_identity_is_blocked(env):
    victim = env.info["matrics"][0]
    body = enrol_body(env, "U20CS2004")
    body["captures"] = [env.probe(victim) for _ in range(3)]  # same finger, different identity
    r = env.client.post("/students", headers=env.login("registrar1"), json=body)
    assert r.status_code == 409 and r.json()["matches"] == victim


@pytest.mark.req("FR-01")
def test_duplicate_matric_and_invalid_inputs(env):
    h = env.login("registrar1")
    assert env.client.post("/students", headers=h, json=enrol_body(env, env.info["matrics"][0])).status_code == 409
    assert env.client.post("/students", headers=h, json=enrol_body(env, "u20cs2005")).status_code == 422
    assert env.client.post("/students", headers=h, json=enrol_body(env, "U20CS2006", n=2)).status_code == 422
    assert env.client.post("/students", headers=h, json=enrol_body(env, "U20CS2007", n=6)).status_code == 422


# -------------------------------------------------------- sessions and rosters
@pytest.mark.req("FR-04")
def test_registration_constraints(env):
    h, sid, hall = env.login("admin"), env.info["session_id"], env.info["hall_id"]
    m = env.info["matrics"]
    dup_student = env.client.post(
        f"/sessions/{sid}/registrations",
        headers=h,
        json={"entries": [{"matric_no": m[0], "hall_id": hall, "seat_no": "Z1"}]},
    )
    dup_seat = env.client.post(
        f"/sessions/{sid}/registrations",
        headers=h,
        json={"entries": [{"matric_no": "U20CS9999", "hall_id": hall, "seat_no": "A001"}]},
    )
    unknown_hall = env.client.post(
        f"/sessions/{sid}/registrations",
        headers=h,
        json={"entries": [{"matric_no": "U20CS9999", "hall_id": "NOWHERE", "seat_no": "Q1"}]},
    )
    assert dup_student.status_code == dup_seat.status_code == unknown_hall.status_code == 409
    assert (
        env.client.post(
            "/sessions/NOPE/registrations",
            headers=h,
            json={"entries": [{"matric_no": m[0], "hall_id": hall, "seat_no": "Z"}]},
        ).status_code
        == 404
    )


@pytest.mark.req("FR-04")
def test_hall_session_and_assignment_validation(env):
    h = env.login("admin")
    assert (
        env.client.post(
            "/halls", headers=h, json={"id": "AGRIC-1", "name": "Faculty of Agriculture Hall", "capacity": 600}
        ).status_code
        == 201
    )
    assert (
        env.client.post("/halls", headers=h, json={"id": "AGRIC-1", "name": "Dup", "capacity": 600}).status_code == 409
    )
    assert env.client.post("/halls", headers=h, json={"id": "BAD", "name": "Zero", "capacity": 0}).status_code == 422
    t = env.clock()
    assert (
        env.client.post(
            "/sessions",
            headers=h,
            json={"id": "S-BAD", "course_code": "COEN1", "title": "Time travel", "starts_at": t, "ends_at": t - 5},
        ).status_code
        == 409
    )
    assert (
        env.client.post(
            f"/sessions/{env.info['session_id']}/assignments",
            headers=h,
            json={"hall_id": "AGRIC-1", "username": "auditor1"},
        ).status_code
        == 422
    )


# -------------------------------------------------------------------- devices
@pytest.mark.req("FR-05")
def test_device_registration_and_revocation(env):
    h = env.login("admin")
    _, _, keys, _ = env.second_device("Terminal-X")
    assert keys.device_id.startswith("DEV-")
    assert env.client.post(f"/devices/{keys.device_id}/revoke", headers=h).status_code == 200
    r = env.client.post(
        f"/sessions/{env.info['session_id']}/bundles",
        headers=h,
        json={"hall_id": env.info["hall_id"], "device_id": keys.device_id},
    )
    assert r.status_code == 403  # cannot provision a revoked device
    assert env.client.post("/devices/DEV-NONE/revoke", headers=h).status_code == 404


# --------------------------------------------------------------------- bundles
@pytest.mark.req("FR-06")
def test_bundle_requires_chief_invigilator_and_roster(env):
    h = env.login("admin")
    env.client.post("/halls", headers=h, json={"id": "EMPTY", "name": "Empty hall", "capacity": 10})
    _, _, keys, _ = env.second_device("T3")
    r = env.client.post(
        f"/sessions/{env.info['session_id']}/bundles", headers=h, json={"hall_id": "EMPTY", "device_id": keys.device_id}
    )
    assert r.status_code == 409  # nobody registered for that hall
    r = env.client.post(
        f"/sessions/{env.info['session_id']}/bundles",
        headers=h,
        json={"hall_id": env.info["hall_id"], "device_id": keys.device_id, "valid_hours": 999},
    )
    assert r.status_code == 422


@pytest.mark.req("FR-06", "NFR-07")
def test_bundle_is_opaque_on_the_wire(env):
    text = Path_text(env.info["paths"]["bundle"])
    for m in env.info["matrics"][:3]:
        assert m not in text
    assert "Student 001" not in text and "scrypt$" not in text and "template" not in text.lower().replace("sealed", "")


def Path_text(p):
    from pathlib import Path

    return Path(p).read_text()


# ------------------------------------------------------------------- reporting
@pytest.mark.req("FR-17")
def test_report_on_untouched_session(env):
    h = env.login("auditor1")
    rep = env.client.get(f"/sessions/{env.info['session_id']}/report", headers=h).json()
    assert rep["expected"] == 12 and rep["admitted"] == 0 and len(rep["absent"]) == 12 and rep["integrity"]
    assert env.client.get("/sessions/NOPE/report", headers=h).status_code == 404
