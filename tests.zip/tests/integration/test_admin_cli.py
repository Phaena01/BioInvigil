"""The documented staff workflow: hub administration client and terminal key provisioning, end to end."""

import json

import pytest

from bioinvigil import admin
from bioinvigil.edge import provision
from bioinvigil.edge.keystore import load_keystore

from ..conftest import ADMIN_PW, PASSPHRASE

pytestmark = pytest.mark.integration


def run(capsys, client, *argv):
    capsys.readouterr()
    rc = admin.main(list(argv), client=client)
    cap = capsys.readouterr()
    return rc, (json.loads(cap.out) if cap.out.strip() else None), cap.err


@pytest.mark.req("FR-01", "FR-04", "FR-05", "FR-06")
def test_staff_workflow_from_empty_session_to_working_terminal(env, capsys, monkeypatch, tmp_path):
    c = env.client
    monkeypatch.setenv("BIOINVIGIL_PASSWORD", ADMIN_PW)
    monkeypatch.setenv("BIOINVIGIL_NEW_PASSWORD", "New-Staff-Passw0rd!")
    for who, role in (("chief9", "chief_invigilator"), ("invig9", "invigilator")):
        assert run(capsys, c, "--user", "admin", "user-add", who, role)[0] == 0
    assert run(capsys, c, "--user", "admin", "hall-add", "ANNEX", "Annex Hall", "50")[0] == 0
    rc, out, _ = run(
        capsys, c, "--user", "admin", "session-add", "NEWEXAM", "COEN999", "Mock exam",
        "--start", "2026-11-02T09:00:00+01:00", "--end", "2026-11-02T12:00:00+01:00",
    )  # fmt: skip
    assert rc == 0 and out == {"id": "NEWEXAM"}

    # registrar enrols from a CSV (captures come from the simulator)
    students = tmp_path / "students.csv"
    students.write_text(
        "matric_no,full_name,department,level,consent\n"
        "U20CS5001,Ada Obi,Computer Engineering,500,yes\n"
        "u20cs5002,Bayo Ade,Computer Engineering,500,yes\n"
    )
    monkeypatch.setenv("BIOINVIGIL_PASSWORD", env.info["creds"]["registrar1"]["password"])
    rc, out, _ = run(capsys, c, "--user", "registrar1", "enrol-csv", str(students), "--seed", "3")
    assert rc == 0 and out == {"enrolled": ["U20CS5001", "U20CS5002"]}

    monkeypatch.setenv("BIOINVIGIL_PASSWORD", ADMIN_PW)
    roster = tmp_path / "roster.csv"
    roster.write_text("matric_no,hall_id,seat_no\nU20CS5001,ANNEX,A1\nU20CS5002,ANNEX,A2\n")
    assert run(capsys, c, "--user", "admin", "roster-import", "NEWEXAM", str(roster))[1] == {"added": 2}
    for who in ("chief9", "invig9"):
        assert run(capsys, c, "--user", "admin", "assign", "NEWEXAM", "ANNEX", who)[0] == 0

    # on the terminal: create keys, hand the public part to the admin, store the returned device id
    monkeypatch.setenv("BIOINVIGIL_KEY_PASSPHRASE", PASSPHRASE)
    keys_file, pub_file = tmp_path / "keys.enc", tmp_path / "device_keys.json"
    assert provision.main(["--keys", str(keys_file), "init", "--public-out", str(pub_file)]) == 0
    rc, out, _ = run(capsys, c, "--user", "admin", "device-register", "Annex-T1", str(pub_file))
    assert rc == 0
    assert provision.main(["--keys", str(keys_file), "set-device-id", out["device_id"]]) == 0
    bundle_file, hubpub_file = tmp_path / "bundle.json", tmp_path / "hub_pub.txt"
    rc, out, _ = run(
        capsys, c, "--user", "admin", "bundle-issue", "NEWEXAM", "ANNEX", out["device_id"],
        "--out", str(bundle_file), "--hub-pub-out", str(hubpub_file),
    )  # fmt: skip
    assert rc == 0 and out["bundle_id"].startswith("BDL-")

    # the terminal accepts the bundle and admits an enrolled student
    keys = load_keystore(keys_file, PASSPHRASE)
    term, store, _ = env.terminal(bundle=json.loads(bundle_file.read_text()), keys=keys)
    assert hubpub_file.read_text() == env.info_hub_pub
    probe = [float(x) for x in admin.SimulatedScanner(seed=9).capture("U20CS5001")]
    assert term.verify("U20CS5001", probe, "invig9").outcome == "ADMIT"


@pytest.mark.req("FR-01", "NFR-10")
def test_enrolment_csv_without_recorded_consent_is_refused(env, capsys, monkeypatch, tmp_path):
    monkeypatch.setenv("BIOINVIGIL_PASSWORD", env.info["creds"]["registrar1"]["password"])
    rows = "matric_no,full_name,department,level,consent\nU20CS6001,No Consent,Computer Engineering,500,no\n"
    f = tmp_path / "s.csv"
    f.write_text(rows)
    rc, _, err = run(capsys, env.client, "--user", "registrar1", "enrol-csv", str(f))
    assert rc == 1 and "422" in err
    f.write_text(rows.replace(",no\n", "\n").replace(",level,consent", ",level"))  # no consent column at all
    rc, _, err = run(capsys, env.client, "--user", "registrar1", "enrol-csv", str(f))
    assert rc == 1 and "consent" in err


@pytest.mark.req("FR-17")
def test_reporting_commands_print_hub_json(env, capsys, monkeypatch):
    monkeypatch.setenv("BIOINVIGIL_PASSWORD", env.info["creds"]["auditor1"]["password"])
    sid = env.info["session_id"]
    rep = run(capsys, env.client, "--user", "auditor1", "report", sid)[1]
    assert rep["expected"] == 12 and rep["admitted"] == 0
    assert run(capsys, env.client, "--user", "auditor1", "attendance", sid)[1] == []
    assert run(capsys, env.client, "--user", "auditor1", "alerts", sid)[1] == []
    assert run(capsys, env.client, "--user", "auditor1", "integrity", sid)[1]["ok"] is True


@pytest.mark.req("FR-18")
def test_admin_client_reports_errors_without_traceback(env, capsys, monkeypatch, tmp_path):
    monkeypatch.setenv("BIOINVIGIL_PASSWORD", "wrong-password-123")
    rc, out, err = run(capsys, env.client, "--user", "admin", "hall-add", "H1", "Hall", "10")
    assert (rc, out) == (1, None) and "401" in err
    monkeypatch.setenv("BIOINVIGIL_PASSWORD", ADMIN_PW)
    end = "2026-11-02T12:00:00+01:00"
    session = ("--user", "admin", "session-add", "S1", "COEN1", "T")
    rc, _, err = run(capsys, env.client, *session, "--start", "2026-11-02T09:00", "--end", end)
    assert rc == 1 and "UTC offset" in err
    rc, _, err = run(capsys, env.client, *session, "--start", "tomorrow", "--end", end)
    assert rc == 1 and "ISO 8601" in err
    bad = tmp_path / "bad.csv"
    bad.write_text("matric_no,hall_id\nU20CS5001,ANNEX\n")
    rc, _, err = run(capsys, env.client, "--user", "admin", "roster-import", "X", str(bad))
    assert rc == 1 and "seat_no" in err
    empty = tmp_path / "empty.csv"
    empty.write_text("matric_no,hall_id,seat_no\n")
    assert run(capsys, env.client, "--user", "admin", "roster-import", "X", str(empty))[0] == 1
    assert run(capsys, env.client, "--user", "admin", "roster-import", "X", str(tmp_path / "missing.csv"))[0] == 1
    rc, _, err = run(capsys, env.client, "--user", "admin", "device-revoke", "DEV-NOPE")
    assert rc == 1 and "404" in err


@pytest.mark.req("NFR-07", "NFR-11")
def test_provisioning_never_overwrites_or_opens_a_keystore_with_the_wrong_passphrase(tmp_path, monkeypatch, capsys):
    keys = tmp_path / "keys.enc"
    monkeypatch.setenv("BIOINVIGIL_KEY_PASSPHRASE", PASSPHRASE)
    assert provision.main(["--keys", str(keys), "init", "--public-out", str(tmp_path / "p.json")]) == 0
    before = keys.read_bytes()
    assert provision.main(["--keys", str(keys), "init", "--public-out", str(tmp_path / "p.json")]) == 1
    assert keys.read_bytes() == before and "refusing to overwrite" in capsys.readouterr().err
    monkeypatch.setenv("BIOINVIGIL_KEY_PASSPHRASE", "another-passphrase-123")
    assert provision.main(["--keys", str(keys), "set-device-id", "DEV-1"]) == 1
    monkeypatch.setenv("BIOINVIGIL_KEY_PASSPHRASE", "short")
    assert provision.main(["--keys", str(tmp_path / "k2.enc"), "init", "--public-out", str(tmp_path / "q.json")]) == 1
