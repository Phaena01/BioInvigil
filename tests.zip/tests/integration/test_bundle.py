import copy
import json
from pathlib import Path

import pytest

from bioinvigil.crypto import SigningKey, canonical_json
from bioinvigil.edge.keystore import create_keystore, save_device_id
from bioinvigil.edge.store import EventStore
from bioinvigil.edge.terminal import Terminal
from bioinvigil.errors import BundleError

pytestmark = [pytest.mark.integration, pytest.mark.req("FR-06", "NFR-08", "NFR-11")]


def load(env, bundle=None, hub_pub=None, keys=None, clock=None):
    from bioinvigil.edge.keystore import load_keystore
    from tests.conftest import PASSPHRASE

    keys = keys or load_keystore(env.info["paths"]["keys"], PASSPHRASE)
    bundle = bundle if bundle is not None else json.loads(Path(env.info["paths"]["bundle"]).read_text())
    store = EventStore(":memory:", keys.device_id, bundle.get("session_id", "S"))
    env.stores.append(store)  # closed by the env fixture
    t = Terminal(store, clock=clock or env.clock)
    t.load_bundle(bundle, keys, hub_pub or env.info_hub_pub)
    return t


def bundle(env):
    return json.loads(Path(env.info["paths"]["bundle"]).read_text())


def test_valid_bundle_activates_terminal(env):
    t = load(env)
    assert len(t.roster) == 12 and t.hall_id == "MAIN-BOWL" and t.policy.max_attempts == 3
    assert set(t.users) == {"invig1", "chief1"}


def test_bundle_signed_by_wrong_hub_is_rejected(env):
    with pytest.raises(BundleError, match="signature"):
        load(env, hub_pub=SigningKey.generate().public_b64())


@pytest.mark.parametrize(
    "field,value",
    [("hall_id", "OTHER"), ("valid_until", 9e12), ("device_id", "DEV-EVIL"), ("session_id", "OTHER-EXAM")],
)
def test_any_metadata_tampering_breaks_signature(env, field, value):
    b = bundle(env)
    b[field] = value
    with pytest.raises(BundleError):
        load(env, bundle=b)


def test_sealed_payload_tampering_is_rejected(env):
    b = bundle(env)
    blob = bytearray(__import__("base64").b64decode(b["sealed"]["blob"]))
    blob[40] ^= 1
    b["sealed"]["blob"] = __import__("base64").b64encode(bytes(blob)).decode()
    with pytest.raises(BundleError):
        load(env, bundle=b)


def test_bundle_cannot_be_used_on_another_device(env):
    _, _, other_keys, _ = env.second_device("Terminal-02")
    with pytest.raises(BundleError, match="different device"):
        load(env, keys=other_keys)


def test_stolen_bundle_is_useless_without_the_device_private_key(env, tmp_path):
    """Attacker registers their own device but replays the legitimate bundle."""
    from bioinvigil.edge.keystore import DeviceKeys

    attacker = create_keystore(tmp_path / "evil.enc", "attacker-passphrase-1")
    attacker = DeviceKeys(attacker.sign, attacker.kex, env.info["device_id"])  # even spoofing the device id
    with pytest.raises(BundleError, match="undecryptable|malformed"):
        load(env, keys=attacker)


def test_expired_and_not_yet_valid_bundles_rejected(env):
    late = type(env.clock)(env.clock() + 25 * 3600)
    with pytest.raises(BundleError, match="validity"):
        load(env, clock=late)
    early = type(env.clock)(env.clock() - 3600)
    with pytest.raises(BundleError, match="validity"):
        load(env, clock=early)


def test_malformed_bundle_is_rejected(env):
    for broken in ({}, {"sig": "x"}, {**bundle(env), "sealed": {}}):
        with pytest.raises(BundleError):
            load(env, bundle=broken)


def test_bundle_for_other_session_db_is_rejected(env):
    from bioinvigil.edge.keystore import load_keystore
    from tests.conftest import PASSPHRASE

    keys = load_keystore(env.info["paths"]["keys"], PASSPHRASE)
    store = EventStore(":memory:", keys.device_id, "SOME-OTHER-SESSION")
    env.stores.append(store)
    t = Terminal(store)
    with pytest.raises(BundleError, match="does not match"):
        t.load_bundle(bundle(env), keys, env.info_hub_pub)


def test_hub_records_issued_bundles_and_admin_actions(env):
    rows = env.svc.conn.execute("SELECT sha256 FROM bundles").fetchall()
    assert len(rows) == 1
    assert len(env.svc.conn.execute("SELECT 1 FROM admin_log WHERE action='issue_bundle'").fetchall()) == 1
    _ = copy.deepcopy(canonical_json({}))
    _ = save_device_id
