import json
from pathlib import Path

import numpy as np
import pytest

from bioinvigil import biometric
from bioinvigil.biometric import MatchPolicy
from bioinvigil.edge.store import EventStore
from bioinvigil.edge.terminal import Terminal
from bioinvigil.errors import AuthError, BundleError, Conflict, Forbidden, InvalidInput, NotFound

pytestmark = pytest.mark.integration


@pytest.fixture()
def term(env):
    t, store, keys = env.terminal()
    return t, store, env


def chief(env):
    return "chief1", env.info["creds"]["chief1"]["password"]


# ---------------------------------------------------------------- 1:1 verify
@pytest.mark.req("FR-07")
def test_genuine_student_is_admitted_with_name_and_seat(term):
    t, store, env = term
    m = env.info["matrics"][0]
    d = t.verify(m, env.probe(m), "invig1")
    assert (
        d.outcome == "ADMIT" and d.name == "Student 001" and d.seat_no == "A001" and d.score > t.policy.verify_threshold
    )
    assert store.admitted() == {m: "ADMIT"} and store.verify()[0]


@pytest.mark.req("FR-07", "FR-09")
def test_impostor_is_rejected_then_referred_after_max_attempts(term):
    t, store, env = term
    victim, impostor = env.info["matrics"][0], env.info["matrics"][1]
    outs = [t.verify(victim, env.probe(impostor), "invig1") for _ in range(3)]
    assert [o.outcome for o in outs] == ["REJECT_MISMATCH", "REJECT_MISMATCH", "REVIEW_REQUIRED"]
    assert [o.attempts_left for o in outs] == [2, 1, 0]
    assert victim not in store.admitted()


@pytest.mark.req("FR-09")
def test_locked_student_cannot_be_admitted_even_with_correct_finger(term):
    t, _, env = term
    victim, impostor = env.info["matrics"][0], env.info["matrics"][1]
    for _ in range(3):
        t.verify(victim, env.probe(impostor), "invig1")
    d = t.verify(victim, env.probe(victim), "invig1")
    assert d.outcome == "REVIEW_REQUIRED"


@pytest.mark.req("FR-10")
def test_wrong_hall_and_not_on_roster(env):
    t, store, _ = env.terminal()
    t.directory["U20CS7777"] = "AGRIC-1"  # registered elsewhere in the same exam
    assert t.verify("U20CS7777", env.probe("U20CS7777"), "invig1").outcome == "WRONG_HALL"
    d = t.verify("U20CS0000", env.probe("U20CS0000"), "invig1")
    assert d.outcome == "NOT_ON_ROSTER"
    reasons = [e["payload"]["reason"] for e in store.all() if e["type"] == "REJECT"]
    assert reasons == ["WRONG_HALL", "NOT_ON_ROSTER"]


@pytest.mark.req("FR-11")
def test_second_presentation_of_admitted_identity_is_flagged(term):
    t, store, env = term
    m, other = env.info["matrics"][0], env.info["matrics"][1]
    assert t.verify(m, env.probe(m), "invig1").outcome == "ADMIT"
    same = t.verify(m, env.probe(m), "invig1")
    diff = t.verify(m, env.probe(other), "invig1")
    assert same.outcome == diff.outcome == "ALREADY_ADMITTED"
    dups = [e["payload"]["biometric_match"] for e in store.all() if e["type"] == "DUPLICATE"]
    assert dups == [True, False]


@pytest.mark.req("FR-07")
@pytest.mark.parametrize("bad", ["", "U20CS\n1001", "U20 CS1001", "U20CS1001'; DROP TABLE events;--", "A" * 30])
def test_malformed_matric_is_rejected_without_logging(term, bad):
    t, store, env = term
    before = store.last()[0]
    with pytest.raises(InvalidInput):
        t.verify(bad, env.probe("U20CS1001"), "invig1")
    assert store.last()[0] == before


@pytest.mark.req("FR-07")
def test_barcode_scanner_input_is_normalised(term):
    t, _, env = term
    m = env.info["matrics"][0]
    assert t.verify(f" {m.lower()}\r\n", env.probe(m), "invig1").outcome == "ADMIT"


@pytest.mark.req("FR-07")
def test_bad_probe_is_rejected(term):
    t, _, env = term
    with pytest.raises(InvalidInput):
        t.verify(env.info["matrics"][0], [0.1] * 5, "invig1")
    with pytest.raises(InvalidInput):
        t.verify(env.info["matrics"][0], [float("nan")] * biometric.DIM, "invig1")


# ---------------------------------------------------------------- 1:N identify
@pytest.mark.req("FR-08")
def test_lost_id_card_student_identified_by_fingerprint_alone(term):
    t, store, env = term
    m = env.info["matrics"][5]
    d = t.identify(env.probe(m), "invig1")
    assert d.outcome == "ADMIT" and d.matric_no == m
    assert [e["payload"]["mode"] for e in store.all() if e["type"] == "ADMIT"] == ["1:N"]


@pytest.mark.req("FR-08")
def test_outsider_is_not_identified(term):
    t, store, env = term
    d = t.identify(env.probe("U20CS5555"), "invig1")  # not in this hall
    assert d.outcome == "NO_MATCH" and store.counts().get("NO_MATCH") == 1


@pytest.mark.req("FR-08")
def test_ambiguous_identification_is_refused():
    """Two near-identical templates: margin rule must stop a coin-flip admission."""
    from bioinvigil.edge.store import EventStore as ES

    store = ES(":memory:", "D", "S")
    t = Terminal(store)
    rng = np.random.default_rng(0)
    base = biometric.normalize(rng.standard_normal(biometric.DIM))
    twin = biometric.normalize(base + 0.02 * rng.standard_normal(biometric.DIM))
    t.policy, t.valid_until = MatchPolicy.load(), 10**12
    t.roster = {"A": {"name": "A", "seat_no": "1"}, "B": {"name": "B", "seat_no": "2"}}
    t._ids, t._matrix = ["A", "B"], np.stack([base, twin]).astype(np.float32)
    d = t.identify(list(map(float, base)), "x")
    assert d.outcome == "AMBIGUOUS" and not store.admitted()
    store.close()


@pytest.mark.req("FR-08", "FR-11")
def test_identify_of_already_admitted_student_is_flagged(term):
    t, _, env = term
    m = env.info["matrics"][2]
    t.verify(m, env.probe(m), "invig1")
    assert t.identify(env.probe(m), "invig1").outcome == "ALREADY_ADMITTED"


# -------------------------------------------------------------------- override
@pytest.mark.req("FR-12")
def test_override_requires_different_chief_invigilator(term):
    t, store, env = term
    m = env.info["matrics"][3]
    cu, cp = chief(env)
    d = t.override(m, "INJURED_FINGER", "bandaged thumb", cu, cp, actor="invig1")
    assert d.outcome == "OVERRIDE_ADMIT" and store.admitted()[m] == "OVERRIDE"
    ev = [e for e in store.all() if e["type"] == "OVERRIDE"][0]
    assert ev["payload"] == {
        "reason_code": "INJURED_FINGER",
        "note": "bandaged thumb",
        "approver": "chief1",
        "actor": "invig1",
    }


@pytest.mark.req("FR-12")
@pytest.mark.parametrize(
    "approver,pw_ok,actor",
    [
        ("chief1", False, "invig1"),  # wrong password
        ("invig1", True, "chief1"),  # approver is not a chief
        ("chief1", True, "chief1"),  # self-approval (two-person rule)
        ("ghost", True, "invig1"),  # unknown approver
    ],
)
def test_override_denials_are_refused_and_logged(term, approver, pw_ok, actor):
    t, store, env = term
    m = env.info["matrics"][3]
    pw = (env.info["creds"].get(approver) or {"password": "x"})["password"] if pw_ok else "wrong-password"
    with pytest.raises(Forbidden):
        t.override(m, "OTHER", "", approver, pw, actor)
    assert m not in store.admitted()
    assert [e["payload"]["reason"] for e in store.all() if e["type"] == "REJECT"] == ["OVERRIDE_DENIED"]


@pytest.mark.req("FR-12")
def test_override_input_validation_and_conflicts(term):
    t, _, env = term
    cu, cp = chief(env)
    m = env.info["matrics"][3]
    with pytest.raises(InvalidInput):
        t.override(m, "BECAUSE_I_SAID_SO", "", cu, cp, "invig1")
    with pytest.raises(InvalidInput):
        t.override(m, "OTHER", "x" * 201, cu, cp, "invig1")
    with pytest.raises(NotFound):
        t.override("U20CS0000", "OTHER", "", cu, cp, "invig1")
    t.override(m, "OTHER", "", cu, cp, "invig1")
    with pytest.raises(Conflict):
        t.override(m, "OTHER", "", cu, cp, "invig1")


# ------------------------------------------------------------------- auth/open
@pytest.mark.req("FR-18", "NFR-09")
def test_terminal_login_tokens_and_lockout(term):
    t, _, env = term
    token = t.login("invig1", env.info["creds"]["invig1"]["password"])
    assert t.user_from_token(token) == {"username": "invig1", "role": "invigilator"}
    for _ in range(5):
        with pytest.raises(AuthError):
            t.login("invig1", "wrong")
    with pytest.raises(AuthError, match="locked"):
        t.login("invig1", env.info["creds"]["invig1"]["password"])
    env.clock.advance(301)
    assert t.login("invig1", env.info["creds"]["invig1"]["password"])
    with pytest.raises(AuthError):
        t.user_from_token(token + "x")


@pytest.mark.req("FR-18")
def test_lockout_survives_terminal_restart(env, tmp_path):
    db = tmp_path / "persist.db"
    t, store, keys = env.terminal(db=db)
    for _ in range(5):
        with pytest.raises(AuthError):
            t.login("invig1", "wrong")
    t2, _, _ = env.terminal(db=db, keys=keys)  # rebooting does not reset the lockout
    with pytest.raises(AuthError, match="locked"):
        t2.login("invig1", env.info["creds"]["invig1"]["password"])


@pytest.mark.req("NFR-11")
def test_terminal_fails_closed_when_bundle_expires(term):
    t, _, env = term
    m = env.info["matrics"][0]
    env.clock.advance(24 * 3600 + 1)
    with pytest.raises(BundleError, match="expired"):
        t.verify(m, env.probe(m), "invig1")
    with pytest.raises(BundleError):
        t.identify(env.probe(m), "invig1")


@pytest.mark.req("NFR-11")
def test_unloaded_terminal_refuses_all_operations(tmp_path):
    store = EventStore(str(tmp_path / "x.db"), "D", "S")
    t = Terminal(store)
    with pytest.raises(BundleError, match="no bundle"):
        t.verify("U20CS1001", [0.0] * biometric.DIM, "x")
    store.close()


@pytest.mark.req("FR-19")
def test_status_summary(term):
    t, _, env = term
    m = env.info["matrics"]
    t.verify(m[0], env.probe(m[0]), "invig1")
    t.verify(m[1], env.probe(m[2]), "invig1")
    s = t.status()
    assert (s["expected"], s["admitted"], s["rejects"], s["unsynced"]) == (12, 1, 1, 3)  # SESSION_OPEN counted


@pytest.mark.req("NFR-05")
def test_crash_recovery_keeps_decisions_and_blocks_double_admission(env, tmp_path):
    db = tmp_path / "crash.db"
    t, store, keys = env.terminal(db=db)
    m = env.info["matrics"][0]
    t.verify(m, env.probe(m), "invig1")
    del t, store  # simulate power loss: process gone, only the file remains
    t2, store2, _ = env.terminal(db=db, keys=keys)
    assert store2.admitted() == {m: "ADMIT"} and store2.verify()[0]
    assert t2.verify(m, env.probe(m), "invig1").outcome == "ALREADY_ADMITTED"
    assert Path(db).exists() and json.loads(json.dumps(store2.counts()))["ADMIT"] == 1
