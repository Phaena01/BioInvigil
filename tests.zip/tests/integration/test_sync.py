import time

import httpx
import pytest
from fastapi.testclient import TestClient

from bioinvigil.crypto import canonical_json
from bioinvigil.edge.api import create_edge_app

pytestmark = pytest.mark.integration


class FlakyClient:
    """Wraps the hub TestClient and simulates a dead network until `online` is set."""

    def __init__(self, inner):
        self.inner, self.online, self.calls = inner, False, 0

    def post(self, url, **kw):
        self.calls += 1
        if not self.online:
            raise httpx.ConnectError("network unreachable")
        return self.inner.post(url, **kw)


def admit_some(env, term, n=3):
    for m in env.info["matrics"][:n]:
        term.verify(m, env.probe(m), "invig1")


@pytest.mark.req("FR-14", "FR-15")
def test_sync_delivers_events_in_order_and_is_idempotent(env):
    t, store, keys = env.terminal()
    admit_some(env, t)
    agent = env.sync_agent(store, keys, t.bundle_id)
    r1 = agent.push()
    assert r1 == {"status": "synced", "sent": 4, "pending": 0}  # SESSION_OPEN + 3 ADMIT
    assert agent.push()["sent"] == 0
    rows = env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
    assert rows == 4 and env.svc.verify_integrity(env.info["session_id"])["ok"]


@pytest.mark.req("FR-14", "NFR-04")
def test_offline_work_then_sync_when_network_returns(env):
    t, store, keys = env.terminal()
    flaky = FlakyClient(env.client)
    agent = env.sync_agent(store, keys, t.bundle_id, client=flaky)
    admit_some(env, t, 5)
    down = agent.push()
    assert down["status"] == "offline" and down["pending"] == 6 and store.acked_seq == 0
    admit_some(env, t, 0)
    flaky.online = True
    assert agent.push() == {"status": "synced", "sent": 6, "pending": 0}
    assert env.svc.session_report(env.info["session_id"])["admitted"] == 5


@pytest.mark.req("FR-14")
def test_large_backlog_is_sent_in_batches(env):
    t, store, keys = env.terminal()
    for _ in range(25):
        store.append("NO_MATCH", None, {"best_score": 0.1})
    agent = env.sync_agent(store, keys, t.bundle_id)
    agent.batch_size = 10
    assert agent.push()["sent"] == 26 and store.acked_seq == 26


@pytest.mark.req("FR-14", "FR-15")
def test_lost_acknowledgement_does_not_duplicate_or_stall(env):
    t, store, keys = env.terminal()
    admit_some(env, t)
    agent = env.sync_agent(store, keys, t.bundle_id)
    agent.push()
    store.set_acked(0)  # terminal crashed before saving the ack: it will resend everything
    res = agent.push()
    assert res["status"] == "synced"
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"] == 4


@pytest.mark.req("FR-15")
def test_hub_restored_from_older_backup_is_resynced(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 2)
    agent = env.sync_agent(store, keys, t.bundle_id)
    agent.push()
    store.set_acked(3)  # terminal believes seq 3 is stored, hub only has 3 -> add more local events
    admit_some(env, t, 0)
    t.verify(env.info["matrics"][4], env.probe(env.info["matrics"][4]), "invig1")
    env.svc.conn.execute("DELETE FROM events WHERE seq=3")  # hub lost its newest event (restore)
    assert agent.push()["status"] == "synced"
    assert env.svc.conn.execute("SELECT MAX(seq) m FROM events").fetchone()["m"] == 4
    # the anomaly is recorded for the auditor even though the terminal recovered by itself
    assert "CHAIN_GAP" in [a["type"] for a in env.svc.list_alerts(env.info["session_id"])]


@pytest.mark.req("FR-15", "FR-13", "FR-16")
def test_tampered_unsynced_event_is_rejected_by_hub(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 4)
    store.conn.execute("UPDATE events SET matric_no='U20CS9999' WHERE seq=3")  # edit before sync
    agent = env.sync_agent(store, keys, t.bundle_id)
    res = agent.push()
    assert res["status"] == "rejected" and "hash" in res["detail"]
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"] == 0  # all-or-nothing
    alerts = env.svc.list_alerts(env.info["session_id"])
    assert [(a["type"], a["severity"]) for a in alerts] == [("TAMPER_SUSPECTED", "critical")]
    agent.push()  # the terminal keeps retrying; the auditor must not be flooded
    assert len(env.svc.list_alerts(env.info["session_id"])) == 1


@pytest.mark.req("FR-15", "FR-13", "FR-16")
def test_deleted_unsynced_event_is_rejected_by_hub(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 4)
    store.conn.execute("DELETE FROM events WHERE seq=3")
    res = env.sync_agent(store, keys, t.bundle_id).push()
    assert res["status"] == "rejected" and "gap" in res["detail"]
    alerts = env.svc.list_alerts(env.info["session_id"])
    assert [(a["type"], a["severity"]) for a in alerts] == [("CHAIN_GAP", "high")]


@pytest.mark.req("FR-15", "FR-16")
def test_rewritten_history_after_sync_raises_tamper_alert(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 3)
    agent = env.sync_agent(store, keys, t.bundle_id)
    agent.push()
    # attacker rewrites already-synced history on the terminal and re-hashes the chain
    store.conn.execute("DELETE FROM events")
    store.set_acked(0)
    for m in ("U20CS1011", "U20CS1012"):
        store.append("ADMIT", m, {"mode": "1:1", "score": 0.99})
    res = agent.push()
    assert res["status"] == "rejected"
    types = [a["type"] for a in env.svc.list_alerts(env.info["session_id"])]
    assert "TAMPER_SUSPECTED" in types


@pytest.mark.req("FR-14", "NFR-08")
def test_batch_signed_with_wrong_key_or_modified_is_refused(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 1)
    _, _, other_keys, _ = env.second_device("Terminal-02")
    agent = env.sync_agent(store, keys, t.bundle_id)
    batch = agent._batch(store.after(0))
    forged = {**batch, "sig": other_keys.sign.sign_b64(canonical_json({k: v for k, v in batch.items() if k != "sig"}))}
    assert env.client.post("/sync/ingest", json=forged).status_code == 401
    modified = {**batch, "events": [{**batch["events"][0], "matric_no": "U20CS1005"}] + batch["events"][1:]}
    assert env.client.post("/sync/ingest", json=modified).status_code == 401
    assert env.client.post("/sync/ingest", json={**batch, "sig": "AAAA"}).status_code == 401


@pytest.mark.req("FR-05", "FR-14")
def test_revoked_device_cannot_sync(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 2)
    env.client.post(f"/devices/{keys.device_id}/revoke", headers=env.login("admin"))
    res = env.sync_agent(store, keys, t.bundle_id).push()
    assert res["status"] == "rejected" and res["http"] == 401


@pytest.mark.req("FR-14")
def test_bundle_id_must_belong_to_the_device(env):
    t, store, keys = env.terminal()
    _, _, _, other_bundle = env.second_device("Terminal-02")
    admit_some(env, t, 1)
    res = env.sync_agent(store, keys, other_bundle["bundle_id"]).push()
    assert res["status"] == "rejected" and res["http"] == 403


@pytest.mark.req("FR-16")
def test_alerts_for_override_referral_duplicate_and_cross_terminal(env):
    m = env.info["matrics"]
    t1, s1, k1 = env.terminal()
    t2, s2, k2, b2 = env.second_device("Terminal-02")
    t1.verify(m[0], env.probe(m[0]), "invig1")
    t2.verify(m[0], env.probe(m[0]), "invig1")  # same student at a second terminal
    for _ in range(3):
        t1.verify(m[1], env.probe(m[2]), "invig1")  # impostor
    t1.verify(m[0], env.probe(m[3]), "invig1")  # someone else claims admitted identity
    t1.override(m[4], "SCANNER_FAULT", "", "chief1", env.info["creds"]["chief1"]["password"], "invig1")
    env.sync_agent(s1, k1, t1.bundle_id).push()
    env.sync_agent(s2, k2, b2["bundle_id"]).push()
    types = {a["type"]: a["severity"] for a in env.svc.list_alerts(env.info["session_id"])}
    assert types["CROSS_TERMINAL_DUPLICATE"] == "critical"
    assert types["POSSIBLE_IMPERSONATION"] == "high"
    assert types["DUPLICATE_ENTRY_MISMATCH"] == "high"
    assert types["MANUAL_OVERRIDE"] == "medium"


@pytest.mark.req("FR-16")
def test_events_outside_bundle_window_raise_low_alert(env):
    t, store, keys = env.terminal()
    env.clock.advance(-7200)  # terminal clock wrong by two hours
    t2 = t
    t2.clock = store.clock = env.clock
    store.append("NO_MATCH", None, {"best_score": 0.1})
    env.clock.advance(7200)
    env.sync_agent(store, keys, t.bundle_id).push()
    assert "EVENT_OUTSIDE_WINDOW" in [a["type"] for a in env.svc.list_alerts(env.info["session_id"])]


@pytest.mark.req("FR-17")
def test_report_attendance_and_integrity(env):
    m = env.info["matrics"]
    t, store, keys = env.terminal()
    for x in m[:6]:
        t.verify(x, env.probe(x), "invig1")
    t.identify(env.probe(m[6]), "invig1")
    t.override(m[7], "POOR_PRINT", "", "chief1", env.info["creds"]["chief1"]["password"], "invig1")
    env.sync_agent(store, keys, t.bundle_id).push()
    h = env.login("auditor1")
    sid = env.info["session_id"]
    rep = env.client.get(f"/sessions/{sid}/report", headers=h).json()
    assert rep["admitted"] == 8 and rep["by_mode"] == {"1:1": 6, "1:N": 1, "OVERRIDE": 1}
    assert rep["absent"] == m[8:] and rep["halls"]["MAIN-BOWL"] == {"expected": 12, "admitted": 8}
    assert rep["attendance_rate"] == round(8 / 12, 4) and rep["integrity"] is True
    att = env.client.get(f"/sessions/{sid}/attendance", headers=h).json()
    assert len(att) == 8 and att[0]["name"] == "Student 001"
    assert env.client.get(f"/sessions/{sid}/integrity", headers=h).json()["ok"]


@pytest.mark.req("FR-15", "FR-13")
def test_hub_integrity_check_detects_post_hoc_database_tampering(env):
    t, store, keys = env.terminal()
    admit_some(env, t, 3)
    env.sync_agent(store, keys, t.bundle_id).push()
    env.svc.conn.execute("UPDATE events SET matric_no='U20CS1012' WHERE seq=2")  # insider edits hub DB
    res = env.client.get(f"/sessions/{env.info['session_id']}/integrity", headers=env.login("admin")).json()
    assert res["ok"] is False and res["chains"][0]["first_bad_index"] == 1


class BrokenOnceClient(FlakyClient):
    """Raises a non-network exception on the first call, then behaves normally."""

    def post(self, url, **kw):
        self.calls += 1
        if self.calls == 1:
            raise RuntimeError("unexpected failure inside the HTTP stack")
        return self.inner.post(url, **kw)


@pytest.mark.req("FR-14", "NFR-04")
def test_background_sync_uploads_on_its_own_and_survives_failures(env):
    t, store, keys = env.terminal()
    agent = env.sync_agent(store, keys, t.bundle_id, client=BrokenOnceClient(env.client))
    with TestClient(create_edge_app(t, agent, sync_interval=0.05)) as ui:
        tok = ui.post("/api/login", json={"username": "invig1", "password": env.info["creds"]["invig1"]["password"]})
        h = {"Authorization": f"Bearer {tok.json()['access_token']}"}
        m = env.info["matrics"][0]
        assert (
            ui.post("/api/verify", headers=h, json={"matric_no": m, "probe": env.probe(m)}).json()["outcome"] == "ADMIT"
        )
        deadline = time.time() + 5
        while store.acked_seq < store.last()[0] and time.time() < deadline:
            time.sleep(0.05)
        status = ui.get("/api/status", headers=h).json()
    assert store.acked_seq == store.last()[0] and status["unsynced"] == 0
    assert status["last_sync"]["status"] == "synced"
    assert env.svc.conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"] == store.last()[0]
