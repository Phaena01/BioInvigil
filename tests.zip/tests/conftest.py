"""Shared fixtures + a small plugin that records per-test results with requirement IDs.

`@pytest.mark.req("FR-07", "NFR-01")` ties a test to requirements; the plugin writes
reports/test_results.json which the documentation tooling uses to build the RTM.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from bioinvigil.biometric import SimulatedScanner
from bioinvigil.central.api import create_app
from bioinvigil.central.service import CentralService
from bioinvigil.config import Settings
from bioinvigil.demo import seed
from bioinvigil.edge.keystore import DeviceKeys, create_keystore, load_keystore, save_device_id
from bioinvigil.edge.store import EventStore
from bioinvigil.edge.sync import SyncAgent
from bioinvigil.edge.terminal import Terminal

ROOT = Path(__file__).resolve().parents[1]
ADMIN_PW = "Admin-Test-Passw0rd!"
PASSPHRASE = "terminal-passphrase-123"

# ------------------------------------------------------------ results recorder
_RESULTS: list[dict[str, Any]] = []


def pytest_runtest_logreport(report):
    if report.when == "call" or (report.when == "setup" and report.outcome != "passed"):
        _RESULTS.append(
            {
                "nodeid": report.nodeid,
                "outcome": report.outcome,
                "duration": round(report.duration, 4),
                "reqs": getattr(report, "_reqs", []),
            }
        )


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    rep._reqs = sorted({a for m in item.iter_markers("req") for a in m.args})


def pytest_sessionfinish(session, exitstatus):
    out = ROOT / "reports" / "test_results.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps({"exit_status": int(exitstatus), "results": _RESULTS}, indent=1))


# ---------------------------------------------------------------------- clock
class Clock:
    def __init__(self, start: float | None = None):
        self.t = start or time.time()

    def __call__(self) -> float:
        return self.t

    def advance(self, seconds: float) -> None:
        self.t += seconds


# ------------------------------------------------------------------- environment
@dataclass
class Env:
    tmp: Path
    clock: Clock
    settings: Settings
    svc: CentralService
    client: TestClient
    info: dict[str, Any]
    scanner: SimulatedScanner
    _n: int = 0
    devices: list[Any] = field(default_factory=list)
    stores: list[EventStore] = field(default_factory=list)

    # -- helpers
    def login(self, user: str, password: str | None = None) -> dict[str, str]:
        pw = password or (ADMIN_PW if user == "admin" else self.info["creds"][user]["password"])
        r = self.client.post("/auth/login", json={"username": user, "password": pw})
        assert r.status_code == 200, r.text
        return {"Authorization": f"Bearer {r.json()['access_token']}"}

    def probe(self, owner: str, quality: str | float = "good") -> list[float]:
        return [float(x) for x in self.scanner.capture(owner, quality)]

    def terminal(
        self,
        *,
        bundle: dict | None = None,
        keys: DeviceKeys | None = None,
        db: Path | None = None,
        clock: Clock | None = None,
    ) -> tuple[Terminal, EventStore, DeviceKeys]:
        keys = keys or load_keystore(self.info["paths"]["keys"], PASSPHRASE)
        bundle = bundle or json.loads(Path(self.info["paths"]["bundle"]).read_text())
        self._n += 1
        store = EventStore(
            str(db or self.tmp / f"term{self._n}.db"), keys.device_id, bundle["session_id"], clock=clock or self.clock
        )
        self.stores.append(store)
        term = Terminal(store, clock=clock or self.clock)
        term.load_bundle(bundle, keys, self.info_hub_pub)
        return term, store, keys

    @property
    def info_hub_pub(self) -> str:
        return Path(self.info["paths"]["hub_pub"]).read_text().strip()

    def second_device(self, name: str = "Terminal-02") -> tuple[Terminal, EventStore, DeviceKeys, dict]:
        admin = self.login("admin")
        path = self.tmp / f"keys_{name}.enc"
        keys = create_keystore(path, PASSPHRASE)
        r = self.client.post(
            "/devices",
            headers=admin,
            json={"name": name, "sign_pub": keys.sign.public_b64(), "kex_pub": keys.kex.public_b64()},
        )
        keys = save_device_id(path, PASSPHRASE, r.json()["device_id"])
        b = self.client.post(
            f"/sessions/{self.info['session_id']}/bundles",
            headers=admin,
            json={"hall_id": self.info["hall_id"], "device_id": keys.device_id, "valid_hours": 24},
        ).json()
        term, store, keys = self.terminal(bundle=b, keys=keys)
        return term, store, keys, b

    def sync_agent(self, store: EventStore, keys: DeviceKeys, bundle_id: str, client: Any = None) -> SyncAgent:
        return SyncAgent(store, keys, bundle_id, client or self.client)

    def login_terminal(self, term: Terminal, user: str = "invig1") -> str:
        return user if term.login(user, self.info["creds"][user]["password"]) else user


@pytest.fixture()
def env(tmp_path):
    clock = Clock()
    settings = Settings.ephemeral()
    svc = CentralService(settings, clock=clock)
    svc.create_user("admin", ADMIN_PW, "admin")
    client = TestClient(create_app(settings, service=svc))
    info = seed(client, "admin", ADMIN_PW, tmp_path / "demo", students=12, clock=clock, passphrase=PASSPHRASE)
    e = Env(tmp_path, clock, settings, svc, client, info, SimulatedScanner(seed=42))
    yield e
    for s in e.stores:
        s.close()
    svc.close()
