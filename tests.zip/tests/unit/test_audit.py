import copy

import pytest

from bioinvigil.audit import GENESIS, compute_hash, make_event, verify_chain

pytestmark = [pytest.mark.unit, pytest.mark.req("FR-13", "NFR-08")]


def build(n=5):
    evs, prev = [], GENESIS
    for i in range(1, n + 1):
        ev = make_event(
            prev_hash=prev,
            seq=i,
            device_id="D1",
            session_id="S1",
            etype="ADMIT",
            matric_no=f"U20CS{1000 + i}",
            payload={"score": 0.9},
            ts=1000.0 + i,
        )
        evs.append(ev)
        prev = ev["hash"]
    return evs


def test_valid_chain_verifies():
    assert verify_chain(build()) == (True, None, "ok")


def test_modified_event_is_detected():
    evs = build()
    evs[2]["matric_no"] = "U20CS9999"
    ok, idx, reason = verify_chain(evs)
    assert not ok and idx == 2 and "altered" in reason


def test_payload_modification_is_detected():
    evs = build()
    evs[1]["payload"]["score"] = 0.99
    assert verify_chain(evs)[:2] == (False, 1)


def test_deleted_event_is_detected():
    evs = build()
    del evs[2]
    ok, idx, reason = verify_chain(evs)
    assert not ok and "gap" in reason


def test_reordered_events_are_detected():
    evs = build()
    evs[1], evs[2] = evs[2], evs[1]
    assert not verify_chain(evs)[0]


def test_recomputed_hash_after_edit_still_breaks_successor():
    evs = build()
    evs[1]["matric_no"] = "FORGED"
    evs[1]["hash"] = compute_hash(evs[1])  # attacker re-hashes the edited event
    ok, idx, _ = verify_chain(evs)
    assert not ok and idx == 2  # but the next event no longer links


def test_continuation_from_known_state():
    evs = build(6)
    assert verify_chain(evs[3:], prev_hash=evs[2]["hash"], start_seq=4)[0]
    assert not verify_chain(evs[3:], prev_hash=GENESIS, start_seq=4)[0]


def test_unknown_event_type_and_missing_fields():
    with pytest.raises(ValueError):
        make_event(
            prev_hash=GENESIS, seq=1, device_id="d", session_id="s", etype="BOGUS", matric_no=None, payload={}, ts=1
        )
    broken = copy.deepcopy(build(1))
    del broken[0]["payload"]
    assert verify_chain(broken)[0] is False
