import json
from pathlib import Path

import numpy as np
import pytest

from bioinvigil import biometric as bio
from bioinvigil.biometric import MatchPolicy, SimulatedScanner

pytestmark = pytest.mark.unit
ROOT = Path(__file__).resolve().parents[2]


def test_validate_vector_rejects_bad_shape_and_values():
    with pytest.raises(ValueError):
        bio.validate_vector([0.1] * 10)
    with pytest.raises(ValueError):
        bio.validate_vector([float("nan")] * bio.DIM)
    with pytest.raises(ValueError):
        bio.validate_vector([float("inf")] * bio.DIM)
    assert bio.validate_vector([0.5] * bio.DIM).shape == (bio.DIM,)


def test_normalize_rejects_zero_vector():
    with pytest.raises(ValueError):
        bio.normalize(np.zeros(bio.DIM))


@pytest.mark.req("FR-01")
def test_template_is_unit_norm_and_roundtrips_encoding():
    sc = SimulatedScanner(seed=1)
    t = bio.make_template([sc.capture("U20CS1001") for _ in range(3)])
    assert abs(np.linalg.norm(t) - 1) < 1e-5
    assert np.allclose(bio.decode_template(bio.encode_template(t)), t)
    with pytest.raises(ValueError):
        bio.decode_template(b"short")


@pytest.mark.req("FR-02")
def test_capture_consistency_separates_good_from_poor():
    sc = SimulatedScanner(seed=2)
    good = bio.capture_consistency([sc.capture("U20CS1001", "good") for _ in range(3)])
    poor = bio.capture_consistency([sc.capture("U20CS1001", "poor") for _ in range(3)])
    assert good > MatchPolicy.load().enrol_quality_min > poor


def test_scanner_identity_is_deterministic_across_instances():
    assert np.allclose(SimulatedScanner(seed=1).finger("A"), SimulatedScanner(seed=9).finger("A"))
    assert not np.allclose(SimulatedScanner().finger("A"), SimulatedScanner().finger("B"))


@pytest.mark.req("FR-07", "NFR-06")
def test_genuine_scores_exceed_impostor_scores_statistically():
    sc = SimulatedScanner(seed=3)
    tmpl = {m: bio.make_template([sc.capture(m) for _ in range(3)]) for m in ("A", "B", "C", "D")}
    gen = [bio.cosine(sc.capture(m), t) for m, t in tmpl.items() for _ in range(25)]
    imp = [bio.cosine(sc.capture(m2), tmpl[m]) for m in tmpl for m2 in tmpl if m2 != m for _ in range(8)]
    pol = MatchPolicy.load()
    assert min(gen) > pol.verify_threshold and max(imp) < pol.verify_threshold


@pytest.mark.req("FR-08")
def test_score_all_matches_pairwise_cosine():
    rng = np.random.default_rng(0)
    m = rng.standard_normal((5, bio.DIM)).astype(np.float32)
    m /= np.linalg.norm(m, axis=1, keepdims=True)
    p = rng.standard_normal(bio.DIM).astype(np.float32)
    assert np.allclose(bio.score_all(p, m), [bio.cosine(p, r) for r in m], atol=1e-5)


@pytest.mark.req("NFR-06")
def test_policy_thresholds_are_ordered_and_loaded():
    p = MatchPolicy.load()
    assert 0.3 < p.verify_threshold < p.identify_threshold <= p.dedup_threshold < 1
    assert p.max_attempts >= 2 and 0 < p.identify_margin < 0.2
    assert set(p.as_dict()) == set(MatchPolicy.__dataclass_fields__)


@pytest.mark.req("NFR-06")
def test_threshold_study_meets_accuracy_targets():
    study = json.loads((ROOT / "reports" / "threshold_study.json").read_text())
    assert study["verify_1to1"]["far"] <= 1e-4 * 1.05
    assert study["end_to_end_identify"]["outsider_far"] <= 1e-3
    assert study["end_to_end_identify"]["misidentification_rate"] == 0
    assert study["counts"]["impostor"] > 10_000_000
    assert study["verify_1to1"]["threshold"] == MatchPolicy.load().verify_threshold
