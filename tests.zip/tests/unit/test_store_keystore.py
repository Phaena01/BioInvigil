import sqlite3
import stat
import sys

import pytest

from bioinvigil.crypto import CryptoError
from bioinvigil.edge.keystore import create_keystore, load_keystore, save_device_id
from bioinvigil.edge.store import EventStore
from bioinvigil.errors import Conflict

pytestmark = pytest.mark.unit


@pytest.fixture()
def store(tmp_path):
    s = EventStore(str(tmp_path / "t.db"), "DEV-1", "S1")
    yield s
    s.close()


@pytest.mark.req("FR-13")
def test_append_builds_valid_chain_and_persists(tmp_path):
    s = EventStore(str(tmp_path / "t.db"), "DEV-1", "S1")
    for i in range(5):
        s.append("ADMIT", f"U20CS100{i}", {"score": 0.9})
    assert s.verify()[0] and s.last()[0] == 5
    s2 = EventStore(str(tmp_path / "t.db"), "DEV-1", "S1")  # reopen = crash recovery
    assert s2.last() == s.last() and s2.verify()[0]
    s.close()
    s2.close()


@pytest.mark.req("FR-13")
def test_direct_sql_tampering_is_detected(store):
    for i in range(4):
        store.append("ADMIT", f"U20CS100{i}", {"score": 0.9})
    store.conn.execute("UPDATE events SET matric_no='FORGED' WHERE seq=2")
    ok, idx, _ = store.verify()
    assert not ok and idx == 1


@pytest.mark.req("FR-13")
def test_database_is_bound_to_device_and_session(tmp_path):
    EventStore(str(tmp_path / "t.db"), "DEV-1", "S1").close()
    with pytest.raises(Conflict):
        EventStore(str(tmp_path / "t.db"), "DEV-2", "S1")
    with pytest.raises(Conflict):
        EventStore(str(tmp_path / "t.db"), "DEV-1", "S2")


@pytest.mark.req("FR-09", "FR-11")
def test_derived_state(store):
    store.append("ADMIT", "A", {})
    store.append("OVERRIDE", "B", {})
    store.append("REJECT", "C", {"reason": "MISMATCH"})
    store.append("REJECT", "C", {"reason": "NOT_ON_ROSTER"})
    store.append("REVIEW", "C", {})
    assert store.admitted() == {"A": "ADMIT", "B": "OVERRIDE"}
    assert store.mismatch_count("C") == 1 and store.is_locked("C") and not store.is_locked("A")
    assert store.counts()["REJECT"] == 2


@pytest.mark.req("FR-14")
def test_after_and_ack_cursor(store):
    for _ in range(6):
        store.append("NO_MATCH", None, {})
    assert [e["seq"] for e in store.after(2, 3)] == [3, 4, 5]
    store.set_acked(4)
    assert store.acked_seq == 4 and len(store.after(store.acked_seq)) == 2


@pytest.mark.req("FR-13")
def test_failed_append_rolls_back(store):
    store.append("ADMIT", "A", {})
    with pytest.raises(ValueError):
        store.append("NOT_A_TYPE", "A", {})
    assert store.last()[0] == 1
    with pytest.raises(sqlite3.Error):
        store.conn.execute("INSERT INTO events(seq) VALUES (1)")


@pytest.mark.req("NFR-07")
def test_keystore_encrypts_and_restricts_permissions(tmp_path):
    p = tmp_path / "k.enc"
    keys = create_keystore(p, "long-passphrase-123")
    if sys.platform != "win32":  # Windows has no POSIX mode bits; the file is still encrypted (checked below)
        assert stat.S_IMODE(p.stat().st_mode) == 0o600
    assert keys.sign.private_bytes() not in p.read_bytes()  # not stored in clear
    loaded = save_device_id(p, "long-passphrase-123", "DEV-9")
    assert loaded.device_id == "DEV-9"
    assert load_keystore(p, "long-passphrase-123").sign.public_b64() == keys.sign.public_b64()
    with pytest.raises(CryptoError):
        load_keystore(p, "bad-passphrase-123")
    with pytest.raises(ValueError):
        create_keystore(tmp_path / "x.enc", "short")
