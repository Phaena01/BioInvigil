import pytest

from bioinvigil import crypto
from bioinvigil.crypto import (
    CryptoError,
    KexKey,
    SigningKey,
    aead_decrypt,
    aead_encrypt,
    canonical_json,
    hash_password,
    open_sealed,
    seal_for,
    unwrap_with_passphrase,
    verify_password,
    verify_signature,
    wrap_with_passphrase,
)

pytestmark = pytest.mark.unit


@pytest.mark.req("NFR-09")
def test_password_hash_roundtrip_and_salting():
    h1, h2 = hash_password("correct horse battery"), hash_password("correct horse battery")
    assert h1 != h2  # unique salts
    assert verify_password("correct horse battery", h1)
    assert not verify_password("wrong", h1)


@pytest.mark.req("NFR-09")
def test_password_hash_uses_strong_scrypt_parameters():
    _, n, r, p, *_ = hash_password("x").split("$")
    assert int(n) >= 2**14 and int(r) >= 8 and int(p) >= 1


@pytest.mark.req("NFR-09")
@pytest.mark.parametrize("bad", ["", "plain", "scrypt$x$y$z$a$b", "md5$1$2$3$AAAA$AAAA"])
def test_verify_password_rejects_malformed_hashes(bad):
    assert verify_password("x", bad) is False


@pytest.mark.req("NFR-07")
def test_aead_roundtrip_and_tamper_detection():
    key = b"k" * 32
    blob = aead_encrypt(key, b"template-bytes", b"aad")
    assert aead_decrypt(key, blob, b"aad") == b"template-bytes"
    flipped = blob[:-1] + bytes([blob[-1] ^ 1])
    with pytest.raises(CryptoError):
        aead_decrypt(key, flipped, b"aad")
    with pytest.raises(CryptoError):
        aead_decrypt(key, blob, b"other-aad")  # ciphertext bound to context
    with pytest.raises(CryptoError):
        aead_decrypt(b"x" * 32, blob, b"aad")


@pytest.mark.req("NFR-07")
def test_aead_nonce_is_unique_per_message():
    key = b"k" * 32
    assert aead_encrypt(key, b"same", b"") != aead_encrypt(key, b"same", b"")


@pytest.mark.req("NFR-07")
def test_aead_rejects_bad_key_length():
    with pytest.raises(CryptoError):
        aead_encrypt(b"short", b"x")


@pytest.mark.req("NFR-08")
def test_signature_verify_and_tamper():
    key = SigningKey.generate()
    sig = key.sign_b64(b"message")
    assert verify_signature(key.public_b64(), sig, b"message")
    assert not verify_signature(key.public_b64(), sig, b"message!")
    assert not verify_signature(SigningKey.generate().public_b64(), sig, b"message")
    assert not verify_signature("not-base64!!", sig, b"message")


@pytest.mark.req("NFR-07")
def test_sealed_box_only_opens_with_recipient_key():
    alice, mallory = KexKey.generate(), KexKey.generate()
    sealed = seal_for(alice.public_b64(), b"roster", b"ctx")
    assert open_sealed(alice, sealed, b"ctx") == b"roster"
    with pytest.raises(CryptoError):
        open_sealed(mallory, sealed, b"ctx")
    with pytest.raises(CryptoError):
        open_sealed(alice, sealed, b"different-ctx")
    with pytest.raises(CryptoError):
        open_sealed(alice, {"epk": sealed["epk"]}, b"ctx")


@pytest.mark.req("NFR-07")
def test_passphrase_wrapping():
    blob = wrap_with_passphrase("a-long-passphrase", b"secret-keys")
    assert unwrap_with_passphrase("a-long-passphrase", blob) == b"secret-keys"
    with pytest.raises(CryptoError):
        unwrap_with_passphrase("wrong-passphrase!", blob)
    with pytest.raises(CryptoError):
        unwrap_with_passphrase("a-long-passphrase", b"short")


@pytest.mark.req("NFR-08")
def test_canonical_json_is_deterministic():
    assert canonical_json({"b": 1, "a": [2, {"y": 1, "x": 2}]}) == canonical_json({"a": [2, {"x": 2, "y": 1}], "b": 1})


def test_b64_rejects_garbage():
    with pytest.raises(CryptoError):
        crypto.b64d("***")
