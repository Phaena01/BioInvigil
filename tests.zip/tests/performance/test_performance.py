"""Latency / throughput checks at realistic hall scale (2,000-student roster). Results -> reports/performance.json."""

import json
import statistics
import time
from pathlib import Path

import numpy as np
import pytest

from bioinvigil import biometric
from bioinvigil.central.service import CentralService
from bioinvigil.config import Settings
from bioinvigil.crypto import aead_encrypt
from bioinvigil.edge.keystore import create_keystore, save_device_id
from bioinvigil.edge.store import EventStore
from bioinvigil.edge.sync import SyncAgent
from bioinvigil.edge.terminal import Terminal

pytestmark = pytest.mark.performance
ROOT = Path(__file__).resolve().parents[2]
N = 2000
RESULTS: dict = {}


def pct(xs, p):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(round(p / 100 * (len(xs) - 1))))]


def summarize(ms):
    return {
        "n": len(ms),
        "mean_ms": round(statistics.mean(ms), 3),
        "p50_ms": round(pct(ms, 50), 3),
        "p95_ms": round(pct(ms, 95), 3),
        "p99_ms": round(pct(ms, 99), 3),
        "max_ms": round(max(ms), 3),
    }


@pytest.fixture(scope="module")
def big(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("perf")
    settings = Settings.ephemeral()
    svc = CentralService(settings)
    sc = biometric.SimulatedScanner(seed=5)
    matrics = [f"U20CS{i:05d}" for i in range(N)]
    now = time.time()
    with svc._tx() as c:  # bulk load bypasses enrolment (dedup is O(N) per student) - measured separately
        c.executemany(
            "INSERT INTO students VALUES (?,?,?,?,?,?,?,?)",
            [
                (
                    m,
                    f"Student {i}",
                    "Computer Engineering",
                    500,
                    aead_encrypt(
                        settings.master_key, biometric.encode_template(biometric.normalize(sc.finger(m))), m.encode()
                    ),
                    now,
                    "bulk",
                    now,
                )
                for i, m in enumerate(matrics)
            ],
        )
    svc.create_hall("BOWL", "Main Bowl", 2500, "bulk")
    svc.create_session("PERF", "COEN838", "Perf", now, now + 3600, "bulk")
    svc.add_registrations(
        "PERF", [{"matric_no": m, "hall_id": "BOWL", "seat_no": f"S{i}"} for i, m in enumerate(matrics)], "bulk"
    )
    svc.create_user("chief", "Chief-Passw0rd-123", "chief_invigilator")
    svc.assign_invigilator("PERF", "BOWL", "chief", "bulk")
    keys = create_keystore(tmp / "k.enc", "perf-passphrase-123")
    dev = svc.register_device("Perf-Terminal", keys.sign.public_b64(), keys.kex.public_b64(), "bulk")
    keys = save_device_id(tmp / "k.enc", "perf-passphrase-123", dev)
    t0 = time.perf_counter()
    bundle = svc.issue_bundle(session_id="PERF", hall_id="BOWL", device_id=dev, valid_hours=24, actor="bulk")
    issue_ms = (time.perf_counter() - t0) * 1000
    store = EventStore(str(tmp / "term.db"), dev, "PERF")  # real file, WAL, synchronous=FULL
    term = Terminal(store)
    t0 = time.perf_counter()
    term.load_bundle(bundle, keys, settings.hub_key.public_b64())
    load_ms = (time.perf_counter() - t0) * 1000
    RESULTS["provisioning"] = {
        "roster": N,
        "bundle_issue_ms": round(issue_ms, 1),
        "bundle_load_ms": round(load_ms, 1),
        "bundle_bytes": len(json.dumps(bundle)),
    }
    yield {"svc": svc, "term": term, "store": store, "keys": keys, "bundle": bundle, "sc": sc, "matrics": matrics}
    store.close()
    svc.close()


@pytest.mark.req("NFR-01", "NFR-03")
def test_verify_latency_on_2000_student_roster(big):
    t, sc, ms = big["term"], big["sc"], big["matrics"]
    lat = []
    for i in range(400):
        m = ms[i]
        probe = [float(x) for x in sc.capture(m, "good")]
        t0 = time.perf_counter()
        d = t.verify(m, probe, "x")
        lat.append((time.perf_counter() - t0) * 1000)
        assert d.outcome == "ADMIT"
    RESULTS["verify_1to1"] = summarize(lat)
    assert pct(lat, 95) <= 200  # NFR-01


@pytest.mark.req("NFR-02", "NFR-03")
def test_identify_latency_on_2000_student_roster(big):
    t, sc, ms = big["term"], big["sc"], big["matrics"]
    lat, correct = [], 0
    for i in range(500, 700):
        probe = [float(x) for x in sc.capture(ms[i], "good")]
        t0 = time.perf_counter()
        d = t.identify(probe, "x")
        lat.append((time.perf_counter() - t0) * 1000)
        correct += d.outcome == "ADMIT" and d.matric_no == ms[i]
    RESULTS["identify_1toN"] = {**summarize(lat), "roster": N, "correct": correct}
    assert pct(lat, 95) <= 200 and correct >= 180  # NFR-02 (some genuine rejects at the strict 1:N threshold)


@pytest.mark.req("NFR-03")
def test_sustained_decision_throughput(big):
    t, sc, ms = big["term"], big["sc"], big["matrics"]
    probes = [[float(x) for x in sc.capture(ms[i], "good")] for i in range(800, 1200)]
    t0 = time.perf_counter()
    for i, p in enumerate(probes):
        t.verify(ms[800 + i], p, "x")
    dt = time.perf_counter() - t0
    RESULTS["sustained"] = {
        "decisions": len(probes),
        "seconds": round(dt, 3),
        "decisions_per_s": round(len(probes) / dt, 1),
    }
    assert len(probes) / dt >= 20


@pytest.mark.req("NFR-03", "NFR-15")
def test_hub_ingest_throughput(big):
    from fastapi.testclient import TestClient

    from bioinvigil.central.api import create_app

    svc, store, keys, bundle = big["svc"], big["store"], big["keys"], big["bundle"]
    client = TestClient(create_app(svc.s, service=svc))
    total = store.last()[0]
    agent = SyncAgent(store, keys, bundle["bundle_id"], client, batch_size=500)
    t0 = time.perf_counter()
    res = agent.push()
    dt = time.perf_counter() - t0
    assert res["status"] == "synced" and res["sent"] == total
    RESULTS["hub_ingest"] = {
        "events": total,
        "seconds": round(dt, 3),
        "events_per_s": round(total / dt, 1),
        "batch_size": 500,
    }
    assert total / dt >= 500
    assert svc.verify_integrity("PERF")["ok"]


@pytest.mark.req("NFR-15")
def test_enrolment_dedup_scaling(tmp_path):
    """Enrolment cost grows linearly with enrolled population (dedup scan) - measure and bound."""
    settings = Settings.ephemeral()
    svc = CentralService(settings)
    sc = biometric.SimulatedScanner(seed=9)
    now = time.time()
    rows = [
        (
            f"B{i:06d}",
            "N",
            "D",
            100,
            aead_encrypt(
                settings.master_key,
                biometric.encode_template(biometric.normalize(sc.finger(f"B{i:06d}"))),
                f"B{i:06d}".encode(),
            ),
            now,
            "b",
            now,
        )
        for i in range(5000)
    ]
    with svc._tx() as c:
        c.executemany("INSERT INTO students VALUES (?,?,?,?,?,?,?,?)", rows)
    caps = [[float(x) for x in sc.capture("NEWSTUDENT1", "good")] for _ in range(3)]
    t0 = time.perf_counter()
    svc.enrol_student(
        matric_no="NEWSTUDENT1",
        full_name="New Student",
        department="CE",
        level=100,
        captures=caps,
        consent=True,
        actor="r",
    )
    ms = (time.perf_counter() - t0) * 1000
    RESULTS["enrolment_with_5000_enrolled"] = {"enrolled": 5000, "ms": round(ms, 1)}
    svc.close()
    assert ms < 3000


def test_zz_write_results():
    out = ROOT / "reports" / "performance.json"
    out.write_text(
        json.dumps({"python": __import__("platform").python_version(), "numpy": np.__version__, **RESULTS}, indent=2)
    )
    assert "verify_1to1" in RESULTS
