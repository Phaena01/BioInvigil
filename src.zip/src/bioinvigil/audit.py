"""Tamper-evident, append-only event log (SHA-256 hash chain).

Each event commits to its predecessor:  hash_n = SHA256(hash_{n-1} || canonical(event_n)).
Editing, deleting or re-ordering any stored event breaks every later hash.
"""

from __future__ import annotations

import uuid
from typing import Any

from .crypto import canonical_json, sha256_hex

GENESIS = "0" * 64

EVENT_TYPES = {
    "ADMIT",  # biometric match accepted
    "REJECT",  # biometric mismatch / not on roster / wrong hall
    "NO_MATCH",  # 1:N search returned no confident candidate
    "REVIEW",  # attempts exhausted, referred to chief invigilator
    "DUPLICATE",  # identity already admitted in this hall
    "OVERRIDE",  # manual admission approved by chief invigilator
    "SESSION_OPEN",  # bundle loaded on terminal
}

_HASHED_FIELDS = (
    "event_id",
    "device_id",
    "session_id",
    "seq",
    "ts",
    "type",
    "matric_no",
    "payload",
    "prev_hash",
)


def compute_hash(event: dict[str, Any]) -> str:
    body = {k: event[k] for k in _HASHED_FIELDS}
    return sha256_hex(canonical_json(body))


def make_event(
    *,
    prev_hash: str,
    seq: int,
    device_id: str,
    session_id: str,
    etype: str,
    matric_no: str | None,
    payload: dict[str, Any],
    ts: float,
    event_id: str | None = None,
) -> dict[str, Any]:
    if etype not in EVENT_TYPES:
        raise ValueError(f"unknown event type {etype!r}")
    ev = {
        "event_id": event_id or str(uuid.uuid4()),
        "device_id": device_id,
        "session_id": session_id,
        "seq": seq,
        "ts": round(ts, 3),
        "type": etype,
        "matric_no": matric_no,
        "payload": payload,
        "prev_hash": prev_hash,
    }
    ev["hash"] = compute_hash(ev)
    return ev


def verify_chain(
    events: list[dict[str, Any]], *, prev_hash: str = GENESIS, start_seq: int = 1
) -> tuple[bool, int | None, str]:
    """Verify a contiguous run of events.

    Returns (ok, index_of_first_bad_event, reason).
    """
    expected_prev, expected_seq = prev_hash, start_seq
    for i, ev in enumerate(events):
        try:
            if ev["seq"] != expected_seq:
                return False, i, f"sequence gap: expected {expected_seq}, got {ev['seq']}"
            if ev["prev_hash"] != expected_prev:
                return False, i, "prev_hash does not match preceding event"
            if compute_hash(ev) != ev["hash"]:
                return False, i, "hash mismatch (event content altered)"
        except KeyError as exc:
            return False, i, f"missing field {exc}"
        expected_prev, expected_seq = ev["hash"], expected_seq + 1
    return True, None, "ok"
