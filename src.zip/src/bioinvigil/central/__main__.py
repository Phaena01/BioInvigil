"""python -m bioinvigil.central [serve|create-admin]"""

from __future__ import annotations

import argparse
import getpass
import os

import uvicorn

from ..config import Settings
from ..errors import Conflict
from .api import create_app
from .service import CentralService


def main() -> None:
    ap = argparse.ArgumentParser(prog="bioinvigil.central")
    sub = ap.add_subparsers(dest="cmd", required=True)
    serve = sub.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    adm = sub.add_parser("create-admin")
    adm.add_argument("username")
    args = ap.parse_args()

    settings = Settings.from_env()
    if args.cmd == "create-admin":
        pw = os.environ.get("BIOINVIGIL_ADMIN_PASSWORD") or getpass.getpass("Admin password: ")
        svc = CentralService(settings)
        try:
            svc.create_user(args.username, pw, "admin")
        except Conflict:
            print(f"admin {args.username!r} already exists; nothing to do")
            return
        finally:
            svc.close()
        print(f"admin {args.username!r} created")
    else:
        uvicorn.run(create_app(settings), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
