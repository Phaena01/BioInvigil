"""Hub database schema (SQLite; the same DDL ports to PostgreSQL with minor type changes)."""

from __future__ import annotations

import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  pw_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','registrar','auditor','invigilator','chief_invigilator')),
  active INTEGER NOT NULL DEFAULT 1,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS students(
  matric_no TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  department TEXT NOT NULL,
  level INTEGER NOT NULL,
  template_enc BLOB NOT NULL,
  consent_at REAL NOT NULL,
  enrolled_by TEXT NOT NULL,
  enrolled_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS halls(
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  capacity INTEGER NOT NULL CHECK(capacity > 0)
);
CREATE TABLE IF NOT EXISTS exam_sessions(
  id TEXT PRIMARY KEY,
  course_code TEXT NOT NULL,
  title TEXT NOT NULL,
  starts_at REAL NOT NULL,
  ends_at REAL NOT NULL CHECK(ends_at > starts_at)
);
CREATE TABLE IF NOT EXISTS registrations(
  session_id TEXT NOT NULL REFERENCES exam_sessions(id),
  matric_no TEXT NOT NULL REFERENCES students(matric_no),
  hall_id TEXT NOT NULL REFERENCES halls(id),
  seat_no TEXT NOT NULL,
  PRIMARY KEY(session_id, matric_no),
  UNIQUE(session_id, hall_id, seat_no)
);
CREATE TABLE IF NOT EXISTS assignments(
  session_id TEXT NOT NULL REFERENCES exam_sessions(id),
  hall_id TEXT NOT NULL REFERENCES halls(id),
  username TEXT NOT NULL REFERENCES users(username),
  PRIMARY KEY(session_id, hall_id, username)
);
CREATE TABLE IF NOT EXISTS devices(
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sign_pub TEXT NOT NULL,
  kex_pub TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','revoked')),
  registered_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS bundles(
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES exam_sessions(id),
  hall_id TEXT NOT NULL REFERENCES halls(id),
  device_id TEXT NOT NULL REFERENCES devices(id),
  issued_at REAL NOT NULL,
  valid_until REAL NOT NULL,
  sha256 TEXT NOT NULL,
  issued_by TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events(
  event_id TEXT PRIMARY KEY,
  device_id TEXT NOT NULL REFERENCES devices(id),
  session_id TEXT NOT NULL REFERENCES exam_sessions(id),
  seq INTEGER NOT NULL,
  ts REAL NOT NULL,
  type TEXT NOT NULL,
  matric_no TEXT,
  payload TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  hash TEXT NOT NULL,
  received_at REAL NOT NULL,
  UNIQUE(device_id, session_id, seq)
);
CREATE INDEX IF NOT EXISTS ix_events_session_matric ON events(session_id, matric_no);
CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  type TEXT NOT NULL,
  severity TEXT NOT NULL CHECK(severity IN ('low','medium','high','critical')),
  matric_no TEXT,
  device_id TEXT,
  detail TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS admin_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT NOT NULL
);
"""


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    if path != ":memory:":
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
    conn.executescript(SCHEMA)
    return conn
