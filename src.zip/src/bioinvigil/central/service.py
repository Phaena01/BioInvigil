"""Hub business logic: users, enrolment, rosters, bundle issuance, event ingest, reporting."""

from __future__ import annotations

import json
import re
import sqlite3
import threading
import time
import uuid
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from typing import Any

import jwt
import numpy as np

from .. import audit, biometric
from ..audit import GENESIS
from ..config import Settings
from ..crypto import (
    CryptoError,
    aead_decrypt,
    aead_encrypt,
    b64e,
    canonical_json,
    hash_password,
    seal_for,
    sha256_hex,
    verify_password,
    verify_signature,
)
from ..errors import (
    AuthError,
    Conflict,
    Forbidden,
    IntegrityViolation,
    InvalidInput,
    NotFound,
)
from . import db

ROLES = {"admin", "registrar", "auditor", "invigilator", "chief_invigilator"}
MATRIC_RE = re.compile(r"^[A-Z0-9/-]{6,20}$")
_DUMMY_HASH = hash_password("dummy-password-for-timing")
MAX_BATCH = 500
CLOCK_SLACK_S = 900


_EVENT_FIELDS: dict[str, tuple[type, ...]] = {
    "event_id": (str,),
    "device_id": (str,),
    "session_id": (str,),
    "seq": (int,),
    "ts": (int, float),
    "type": (str,),
    "matric_no": (str, type(None)),
    "payload": (dict,),
    "prev_hash": (str,),
    "hash": (str,),
}


def _check_event_shape(ev: Any) -> None:
    if not isinstance(ev, dict):
        raise InvalidInput("event must be an object")
    for name, types in _EVENT_FIELDS.items():
        if name not in ev or not isinstance(ev[name], types) or isinstance(ev[name], bool):
            raise InvalidInput(f"event field {name!r} missing or wrong type")


class CentralService:
    def __init__(
        self,
        settings: Settings,
        policy: biometric.MatchPolicy | None = None,
        clock: Callable[[], float] = time.time,
    ):
        self.s = settings
        self.policy = policy or biometric.MatchPolicy.load()
        self.clock = clock
        self.conn = db.connect(settings.db_path)
        self._lock = threading.RLock()

    def close(self) -> None:
        self.conn.close()

    # ------------------------------------------------------------ plumbing
    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield self.conn
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise
            self.conn.execute("COMMIT")

    def _q(self, sql: str, args: tuple = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self.conn.execute(sql, args).fetchall()

    def _one(self, sql: str, args: tuple = ()) -> sqlite3.Row | None:
        rows = self._q(sql, args)
        return rows[0] if rows else None

    def _log(self, conn: sqlite3.Connection, actor: str, action: str, target: str) -> None:
        conn.execute(
            "INSERT INTO admin_log(ts, actor, action, target) VALUES (?,?,?,?)",
            (self.clock(), actor, action, target),
        )

    # ---------------------------------------------------------------- users
    def create_user(self, username: str, password: str, role: str, actor: str = "system") -> None:
        if role not in ROLES:
            raise InvalidInput(f"unknown role {role!r}")
        if len(password) < self.s.min_password_len:
            raise InvalidInput(f"password must be at least {self.s.min_password_len} characters")
        try:
            with self._tx() as c:
                c.execute(
                    "INSERT INTO users(username, pw_hash, role) VALUES (?,?,?)",
                    (username, hash_password(password), role),
                )
                self._log(c, actor, "create_user", f"{username}:{role}")
        except sqlite3.IntegrityError as exc:
            raise Conflict("username already exists") from exc

    def authenticate(self, username: str, password: str) -> dict[str, Any]:
        now = self.clock()
        row = self._one("SELECT * FROM users WHERE username=?", (username,))
        if row is None:
            verify_password(password, _DUMMY_HASH)  # equalise timing
            raise AuthError("invalid credentials")
        if row["locked_until"] > now:
            raise AuthError("account temporarily locked")
        if not row["active"] or not verify_password(password, row["pw_hash"]):
            with self._tx() as c:
                fails = row["failed_attempts"] + 1
                locked = now + self.s.lockout_seconds if fails >= self.s.lockout_threshold else 0
                c.execute(
                    "UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?",
                    (0 if locked else fails, locked, row["id"]),
                )
            raise AuthError("invalid credentials")
        with self._tx() as c:
            c.execute("UPDATE users SET failed_attempts=0, locked_until=0 WHERE id=?", (row["id"],))
        return {"username": row["username"], "role": row["role"]}

    def issue_token(self, user: dict[str, Any]) -> str:
        now = int(self.clock())
        claims = {
            "sub": user["username"],
            "role": user["role"],
            "iat": now,
            "exp": now + self.s.token_ttl_s,
            "jti": str(uuid.uuid4()),
        }
        return jwt.encode(claims, self.s.jwt_secret, algorithm="HS256")

    def user_from_token(self, token: str) -> dict[str, Any]:
        try:
            claims = jwt.decode(
                token,
                self.s.jwt_secret,
                algorithms=["HS256"],
                options={"require": ["exp", "sub", "role", "iat"]},
            )
        except jwt.PyJWTError as exc:
            raise AuthError("invalid or expired token") from exc
        row = self._one("SELECT username, role, active FROM users WHERE username=?", (claims["sub"],))
        if row is None or not row["active"] or row["role"] != claims["role"]:
            raise AuthError("token no longer valid")
        return {"username": row["username"], "role": row["role"]}

    # ------------------------------------------------------------- students
    def _template_matrix(self) -> tuple[list[str], np.ndarray]:
        rows = self._q("SELECT matric_no, template_enc FROM students ORDER BY matric_no")
        if not rows:
            return [], np.empty((0, biometric.DIM), dtype=np.float32)
        ids = [r["matric_no"] for r in rows]
        mat = np.stack(
            [
                biometric.decode_template(aead_decrypt(self.s.master_key, r["template_enc"], r["matric_no"].encode()))
                for r in rows
            ]
        )
        return ids, mat

    def enrol_student(
        self,
        *,
        matric_no: str,
        full_name: str,
        department: str,
        level: int,
        captures: list[list[float]],
        consent: bool,
        actor: str,
    ) -> dict[str, Any]:
        if not MATRIC_RE.match(matric_no):
            raise InvalidInput("invalid matric number")
        if not consent:
            raise InvalidInput("explicit data-subject consent is required to enrol biometrics")
        try:
            caps = [biometric.validate_vector(c) for c in captures]
        except ValueError as exc:
            raise InvalidInput(str(exc)) from exc
        if not 3 <= len(caps) <= 5:
            raise InvalidInput("3 to 5 captures are required")
        quality = biometric.capture_consistency(caps)
        if quality < self.policy.enrol_quality_min:
            raise InvalidInput(
                f"capture quality too low ({quality:.2f} < {self.policy.enrol_quality_min}); recapture",
                extra={"quality": round(quality, 4)},
            )
        template = biometric.make_template(caps)

        with self._lock:
            if self._one("SELECT 1 FROM students WHERE matric_no=?", (matric_no,)):
                raise Conflict("student already enrolled")
            ids, mat = self._template_matrix()
            if len(ids):
                scores = biometric.score_all(template, mat)
                best = int(np.argmax(scores))
                if scores[best] >= self.policy.dedup_threshold:
                    raise Conflict(
                        "possible duplicate identity: biometric matches an existing enrolment",
                        extra={"matches": ids[best], "score": round(float(scores[best]), 4)},
                    )
            now = self.clock()
            with self._tx() as c:
                c.execute(
                    "INSERT INTO students VALUES (?,?,?,?,?,?,?,?)",
                    (
                        matric_no,
                        full_name,
                        department,
                        level,
                        aead_encrypt(self.s.master_key, biometric.encode_template(template), matric_no.encode()),
                        now,
                        actor,
                        now,
                    ),
                )
                self._log(c, actor, "enrol_student", matric_no)
        return {"matric_no": matric_no, "quality": round(quality, 4)}

    def get_student(self, matric_no: str) -> dict[str, Any]:
        row = self._one(
            "SELECT matric_no, full_name, department, level, enrolled_at FROM students WHERE matric_no=?",
            (matric_no,),
        )
        if row is None:
            raise NotFound("student not found")
        return dict(row)

    # --------------------------------------------------- halls / sessions
    def create_hall(self, hall_id: str, name: str, capacity: int, actor: str) -> None:
        try:
            with self._tx() as c:
                c.execute("INSERT INTO halls VALUES (?,?,?)", (hall_id, name, capacity))
                self._log(c, actor, "create_hall", hall_id)
        except sqlite3.IntegrityError as exc:
            raise Conflict("hall exists or invalid capacity") from exc

    def create_session(
        self, session_id: str, course_code: str, title: str, starts_at: float, ends_at: float, actor: str
    ) -> None:
        try:
            with self._tx() as c:
                c.execute(
                    "INSERT INTO exam_sessions VALUES (?,?,?,?,?)",
                    (session_id, course_code, title, starts_at, ends_at),
                )
                self._log(c, actor, "create_session", session_id)
        except sqlite3.IntegrityError as exc:
            raise Conflict("session exists or has invalid times") from exc

    def add_registrations(self, session_id: str, entries: list[dict[str, str]], actor: str) -> int:
        if not self._one("SELECT 1 FROM exam_sessions WHERE id=?", (session_id,)):
            raise NotFound("session not found")
        try:
            with self._tx() as c:
                for e in entries:
                    c.execute(
                        "INSERT INTO registrations VALUES (?,?,?,?)",
                        (session_id, e["matric_no"], e["hall_id"], e["seat_no"]),
                    )
                self._log(c, actor, "add_registrations", f"{session_id}:{len(entries)}")
        except sqlite3.IntegrityError as exc:
            raise Conflict("registration rejected: unknown student/hall, duplicate student or duplicate seat") from exc
        return len(entries)

    def assign_invigilator(self, session_id: str, hall_id: str, username: str, actor: str) -> None:
        user = self._one("SELECT role FROM users WHERE username=?", (username,))
        if user is None or user["role"] not in ("invigilator", "chief_invigilator"):
            raise InvalidInput("user must exist with an invigilator role")
        try:
            with self._tx() as c:
                c.execute("INSERT INTO assignments VALUES (?,?,?)", (session_id, hall_id, username))
                self._log(c, actor, "assign_invigilator", f"{session_id}:{hall_id}:{username}")
        except sqlite3.IntegrityError as exc:
            raise Conflict("assignment invalid or duplicate") from exc

    # -------------------------------------------------------------- devices
    def register_device(self, name: str, sign_pub: str, kex_pub: str, actor: str) -> str:
        device_id = f"DEV-{uuid.uuid4().hex[:8].upper()}"
        with self._tx() as c:
            c.execute(
                "INSERT INTO devices VALUES (?,?,?,?, 'active', ?)",
                (device_id, name, sign_pub, kex_pub, self.clock()),
            )
            self._log(c, actor, "register_device", device_id)
        return device_id

    def revoke_device(self, device_id: str, actor: str) -> None:
        with self._tx() as c:
            cur = c.execute("UPDATE devices SET status='revoked' WHERE id=?", (device_id,))
            if cur.rowcount == 0:
                raise NotFound("device not found")
            self._log(c, actor, "revoke_device", device_id)

    # -------------------------------------------------------------- bundles
    def issue_bundle(
        self, *, session_id: str, hall_id: str, device_id: str, valid_hours: int, actor: str
    ) -> dict[str, Any]:
        sess = self._one("SELECT * FROM exam_sessions WHERE id=?", (session_id,))
        dev = self._one("SELECT * FROM devices WHERE id=?", (device_id,))
        if sess is None or dev is None or not self._one("SELECT 1 FROM halls WHERE id=?", (hall_id,)):
            raise NotFound("session, hall or device not found")
        if dev["status"] != "active":
            raise Forbidden("device is revoked")
        if not 1 <= valid_hours <= 72:
            raise InvalidInput("valid_hours must be 1..72")
        roster_rows = self._q(
            """SELECT r.matric_no, r.hall_id, r.seat_no, s.full_name, s.template_enc
               FROM registrations r JOIN students s USING(matric_no) WHERE r.session_id=?""",
            (session_id,),
        )
        mine = [r for r in roster_rows if r["hall_id"] == hall_id]
        if not mine:
            raise Conflict("no registrations for this hall")
        users = self._q(
            """SELECT u.username, u.role, u.pw_hash FROM assignments a JOIN users u USING(username)
               WHERE a.session_id=? AND a.hall_id=? AND u.active=1""",
            (session_id, hall_id),
        )
        if not any(u["role"] == "chief_invigilator" for u in users):
            raise Conflict("hall needs an assigned chief invigilator (override approvals)")

        now = self.clock()
        bundle_id = f"BDL-{uuid.uuid4().hex[:10].upper()}"
        valid_until = now + valid_hours * 3600
        payload = {
            "session": {
                "id": session_id,
                "course_code": sess["course_code"],
                "title": sess["title"],
                "starts_at": sess["starts_at"],
                "ends_at": sess["ends_at"],
            },
            "hall_id": hall_id,
            "policy": self.policy.as_dict(),
            "roster": [
                {
                    "matric_no": r["matric_no"],
                    "name": r["full_name"],
                    "seat_no": r["seat_no"],
                    "template": b64e(aead_decrypt(self.s.master_key, r["template_enc"], r["matric_no"].encode())),
                }
                for r in mine
            ],
            "directory": [{"matric_no": r["matric_no"], "hall_id": r["hall_id"]} for r in roster_rows],
            "users": [{"username": u["username"], "role": u["role"], "pw_hash": u["pw_hash"]} for u in users],
        }
        meta = {
            "version": 1,
            "bundle_id": bundle_id,
            "device_id": device_id,
            "session_id": session_id,
            "hall_id": hall_id,
            "issued_at": now,
            "valid_from": now,
            "valid_until": valid_until,
        }
        sealed = seal_for(dev["kex_pub"], canonical_json(payload), canonical_json(meta))
        envelope = {**meta, "sealed": sealed}
        envelope["sig"] = self.s.hub_key.sign_b64(canonical_json(envelope))
        with self._tx() as c:
            c.execute(
                "INSERT INTO bundles VALUES (?,?,?,?,?,?,?,?)",
                (
                    bundle_id,
                    session_id,
                    hall_id,
                    device_id,
                    now,
                    valid_until,
                    sha256_hex(canonical_json(envelope)),
                    actor,
                ),
            )
            self._log(c, actor, "issue_bundle", f"{bundle_id}:{device_id}")
        return envelope

    # --------------------------------------------------------------- ingest
    def _alert(
        self,
        c: sqlite3.Connection,
        session_id: str,
        atype: str,
        severity: str,
        detail: str,
        matric_no: str | None = None,
        device_id: str | None = None,
    ) -> None:
        c.execute(
            "INSERT INTO alerts(session_id,type,severity,matric_no,device_id,detail,created_at) VALUES (?,?,?,?,?,?,?)",
            (session_id, atype, severity, matric_no, device_id, detail, self.clock()),
        )

    def _alert_once(
        self, c: sqlite3.Connection, session_id: str, atype: str, severity: str, detail: str, device_id: str
    ) -> None:
        """Raise an alert unless an identical one is already recorded (a terminal retries its sync repeatedly)."""
        dup = c.execute(
            "SELECT 1 FROM alerts WHERE session_id=? AND type=? AND device_id=? AND detail=?",
            (session_id, atype, device_id, detail),
        ).fetchone()
        if dup is None:
            self._alert(c, session_id, atype, severity, detail, device_id=device_id)

    def ingest(self, batch: dict[str, Any]) -> dict[str, Any]:
        try:
            device_id, session_id = batch["device_id"], batch["session_id"]
            bundle_id, events, sig = batch["bundle_id"], batch["events"], batch["sig"]
        except KeyError as exc:
            raise InvalidInput(f"missing field {exc}") from exc
        dev = self._one("SELECT * FROM devices WHERE id=?", (device_id,))
        if dev is None or dev["status"] != "active":
            raise AuthError("unknown or revoked device")
        body = {k: v for k, v in batch.items() if k != "sig"}
        if not verify_signature(dev["sign_pub"], sig, canonical_json(body)):
            raise AuthError("bad batch signature")
        bundle = self._one("SELECT * FROM bundles WHERE id=?", (bundle_id,))
        if bundle is None or bundle["device_id"] != device_id or bundle["session_id"] != session_id:
            raise Forbidden("bundle does not belong to this device/session")
        if not isinstance(events, list) or not 1 <= len(events) <= MAX_BATCH:
            raise InvalidInput(f"batch must contain 1..{MAX_BATCH} events")
        for ev in events:
            _check_event_shape(ev)
            if ev["device_id"] != device_id or ev["session_id"] != session_id:
                raise InvalidInput("event does not match batch device/session")

        tamper_seq: int | None = None
        chain_error: str | None = None
        with self._tx() as c:
            last = c.execute(
                "SELECT seq, hash FROM events WHERE device_id=? AND session_id=? ORDER BY seq DESC LIMIT 1",
                (device_id, session_id),
            ).fetchone()
            last_seq, last_hash = (last["seq"], last["hash"]) if last else (0, GENESIS)

            fresh: list[dict[str, Any]] = []
            duplicates = 0
            for ev in events:
                if ev["seq"] <= last_seq:
                    stored = c.execute(
                        "SELECT hash FROM events WHERE device_id=? AND session_id=? AND seq=?",
                        (device_id, session_id, ev["seq"]),
                    ).fetchone()
                    if stored is None or stored["hash"] != ev["hash"]:
                        self._alert_once(
                            c,
                            session_id,
                            "TAMPER_SUSPECTED",
                            "critical",
                            f"seq {ev['seq']} conflicts with stored event",
                            device_id,
                        )
                        tamper_seq = ev["seq"]
                        break
                    duplicates += 1
                else:
                    fresh.append(ev)
            if tamper_seq is None and fresh:
                ok, _, reason = audit.verify_chain(fresh, prev_hash=last_hash, start_seq=last_seq + 1)
                if not ok:
                    chain_error = reason
                    gap = reason.startswith("sequence gap")
                    self._alert_once(
                        c,
                        session_id,
                        "CHAIN_GAP" if gap else "TAMPER_SUSPECTED",
                        "high" if gap else "critical",
                        f"batch refused: {reason}",
                        device_id,
                    )
                else:
                    for ev in fresh:
                        if ev["type"] not in audit.EVENT_TYPES:
                            raise InvalidInput(f"unknown event type {ev['type']!r}")
                        c.execute(
                            "INSERT INTO events VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                            (
                                ev["event_id"],
                                device_id,
                                session_id,
                                ev["seq"],
                                ev["ts"],
                                ev["type"],
                                ev["matric_no"],
                                json.dumps(ev["payload"], sort_keys=True),
                                ev["prev_hash"],
                                ev["hash"],
                                self.clock(),
                            ),
                        )
                        self._derive_alerts(c, ev, bundle)
                    last_seq, last_hash = fresh[-1]["seq"], fresh[-1]["hash"]
        if chain_error is not None:  # alert has been committed; now refuse the batch
            raise IntegrityViolation(
                f"hash chain rejected: {chain_error}",
                extra={"last_seq": last_seq, "last_hash": last_hash},
            )
        if tamper_seq is not None:  # alert has been committed; now refuse the batch
            raise IntegrityViolation(
                "event conflicts with previously stored history",
                extra={"last_seq": last_seq, "tamper": True},
            )
        return {"accepted": len(fresh), "duplicates": duplicates, "last_seq": last_seq, "last_hash": last_hash}

    def _derive_alerts(self, c: sqlite3.Connection, ev: dict[str, Any], bundle: sqlite3.Row) -> None:
        sid, dev, m, t, p = ev["session_id"], ev["device_id"], ev["matric_no"], ev["type"], ev["payload"]
        if not (bundle["issued_at"] - CLOCK_SLACK_S <= ev["ts"] <= bundle["valid_until"] + CLOCK_SLACK_S):
            self._alert(c, sid, "EVENT_OUTSIDE_WINDOW", "low", f"ts={ev['ts']} outside bundle validity", m, dev)
        if t == "OVERRIDE":
            self._alert(
                c,
                sid,
                "MANUAL_OVERRIDE",
                "medium",
                f"reason={p.get('reason_code')} approver={p.get('approver')}",
                m,
                dev,
            )
        elif t == "REVIEW":
            self._alert(
                c,
                sid,
                "POSSIBLE_IMPERSONATION",
                "high",
                f"{p.get('attempts')} failed verifications; referred to chief invigilator",
                m,
                dev,
            )
        elif t == "DUPLICATE":
            if p.get("biometric_match"):
                self._alert(c, sid, "DUPLICATE_ENTRY", "low", "enrolled student re-presented after admission", m, dev)
            else:
                self._alert(
                    c,
                    sid,
                    "DUPLICATE_ENTRY_MISMATCH",
                    "high",
                    "identity already admitted; presenter does not match template",
                    m,
                    dev,
                )
        if t in ("ADMIT", "OVERRIDE") and m:
            other = c.execute(
                "SELECT device_id FROM events WHERE session_id=? AND matric_no=? AND type IN ('ADMIT','OVERRIDE')"
                " AND device_id<>? LIMIT 1",
                (sid, m, dev),
            ).fetchone()
            if other:
                self._alert(
                    c,
                    sid,
                    "CROSS_TERMINAL_DUPLICATE",
                    "critical",
                    f"admitted on {dev} and {other['device_id']}",
                    m,
                    dev,
                )

    # -------------------------------------------------------------- reports
    def verify_integrity(self, session_id: str) -> dict[str, Any]:
        out, ok_all = [], True
        for d in self._q("SELECT DISTINCT device_id FROM events WHERE session_id=?", (session_id,)):
            rows = self._q(
                "SELECT * FROM events WHERE session_id=? AND device_id=? ORDER BY seq",
                (session_id, d["device_id"]),
            )
            evs = [{**dict(r), "payload": json.loads(r["payload"])} for r in rows]
            ok, idx, reason = audit.verify_chain(evs)
            ok_all &= ok
            out.append(
                {"device_id": d["device_id"], "events": len(evs), "ok": ok, "first_bad_index": idx, "reason": reason}
            )
        return {"session_id": session_id, "ok": ok_all, "chains": out}

    def session_report(self, session_id: str) -> dict[str, Any]:
        sess = self._one("SELECT * FROM exam_sessions WHERE id=?", (session_id,))
        if sess is None:
            raise NotFound("session not found")
        expected = self._q("SELECT matric_no, hall_id FROM registrations WHERE session_id=?", (session_id,))
        admitted = self._q(
            "SELECT matric_no, type, payload FROM events WHERE session_id=? AND type IN ('ADMIT','OVERRIDE')",
            (session_id,),
        )
        adm_set = {r["matric_no"] for r in admitted}
        by_mode: dict[str, int] = {}
        for r in admitted:
            mode = "OVERRIDE" if r["type"] == "OVERRIDE" else json.loads(r["payload"]).get("mode", "1:1")
            by_mode[mode] = by_mode.get(mode, 0) + 1
        counts = {
            r["type"]: r["n"]
            for r in self._q("SELECT type, COUNT(*) n FROM events WHERE session_id=? GROUP BY type", (session_id,))
        }
        halls: dict[str, dict[str, int]] = {}
        for r in expected:
            h = halls.setdefault(r["hall_id"], {"expected": 0, "admitted": 0})
            h["expected"] += 1
            h["admitted"] += r["matric_no"] in adm_set
        alerts = self._q(
            "SELECT type, severity, COUNT(*) n FROM alerts WHERE session_id=? GROUP BY type, severity", (session_id,)
        )
        devices = self._q(
            "SELECT device_id, MAX(seq) last_seq, MAX(ts) last_ts, COUNT(*) n "
            "FROM events WHERE session_id=? GROUP BY device_id",
            (session_id,),
        )
        return {
            "session": dict(sess),
            "expected": len(expected),
            "admitted": len(adm_set),
            "attendance_rate": round(len(adm_set) / len(expected), 4) if expected else None,
            "by_mode": by_mode,
            "event_counts": counts,
            "halls": halls,
            "absent": sorted(r["matric_no"] for r in expected if r["matric_no"] not in adm_set),
            "alerts": [dict(a) for a in alerts],
            "devices": [dict(d) for d in devices],
            "integrity": self.verify_integrity(session_id)["ok"],
        }

    def attendance(self, session_id: str) -> list[dict[str, Any]]:
        rows = self._q(
            """SELECT e.matric_no, s.full_name, e.type, e.ts, e.device_id, e.payload
               FROM events e JOIN students s USING(matric_no)
               WHERE e.session_id=? AND e.type IN ('ADMIT','OVERRIDE') ORDER BY e.ts""",
            (session_id,),
        )
        return [
            {
                "matric_no": r["matric_no"],
                "name": r["full_name"],
                "type": r["type"],
                "ts": r["ts"],
                "device_id": r["device_id"],
                "detail": json.loads(r["payload"]),
            }
            for r in rows
        ]

    def list_alerts(self, session_id: str) -> list[dict[str, Any]]:
        return [dict(r) for r in self._q("SELECT * FROM alerts WHERE session_id=? ORDER BY id", (session_id,))]


__all__ = ["CentralService", "CryptoError"]
