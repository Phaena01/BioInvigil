"""Hub REST API (FastAPI). Authentication: JWT bearer for staff, signed batches for terminals."""

from collections.abc import Callable
from typing import Annotated, Any

from fastapi import Depends, FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, StringConstraints

from .. import __version__
from ..biometric import DIM
from ..config import Settings
from ..errors import AuthError, BioInvigilError, Forbidden
from .service import CentralService

Matric = Annotated[str, StringConstraints(pattern=r"^[A-Z0-9/-]{6,20}$")]
Ident = Annotated[str, StringConstraints(pattern=r"^[A-Za-z0-9_.-]{2,40}$")]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class LoginIn(Strict):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)


class UserIn(Strict):
    username: Ident
    password: str = Field(min_length=1, max_length=128)
    role: str


class EnrolIn(Strict):
    matric_no: Matric
    full_name: str = Field(min_length=2, max_length=120)
    department: str = Field(min_length=2, max_length=80)
    level: int = Field(ge=100, le=900)
    consent: bool
    captures: list[Annotated[list[float], Field(min_length=DIM, max_length=DIM)]] = Field(min_length=3, max_length=5)


class HallIn(Strict):
    id: Ident
    name: str = Field(min_length=2, max_length=80)
    capacity: int = Field(gt=0, le=20000)


class SessionIn(Strict):
    id: Ident
    course_code: str = Field(min_length=3, max_length=12)
    title: str = Field(min_length=2, max_length=120)
    starts_at: float
    ends_at: float


class RegEntry(Strict):
    matric_no: Matric
    hall_id: Ident
    seat_no: str = Field(min_length=1, max_length=12)


class RegistrationsIn(Strict):
    entries: list[RegEntry] = Field(min_length=1, max_length=5000)


class AssignIn(Strict):
    hall_id: Ident
    username: Ident


class DeviceIn(Strict):
    name: str = Field(min_length=2, max_length=60)
    sign_pub: str = Field(min_length=40, max_length=64)
    kex_pub: str = Field(min_length=40, max_length=64)


class BundleIn(Strict):
    hall_id: Ident
    device_id: str = Field(min_length=3, max_length=32)
    valid_hours: int = Field(default=24, ge=1, le=72)


def create_app(
    settings: Settings | None = None, service: CentralService | None = None, clock: Callable[[], float] | None = None
) -> FastAPI:
    settings = settings or Settings.from_env()
    svc = service or (CentralService(settings, clock=clock) if clock else CentralService(settings))
    app = FastAPI(title="BioInvigil Hub", version=__version__, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.svc = svc

    @app.exception_handler(BioInvigilError)
    async def _domain_error(_: Request, exc: BioInvigilError) -> JSONResponse:
        return JSONResponse(status_code=exc.status, content={"code": exc.code, "detail": exc.message, **exc.extra})

    @app.exception_handler(RequestValidationError)
    async def _validation_error(_: Request, exc: RequestValidationError) -> JSONResponse:
        # report field + message only: never echo submitted values (could contain secrets)
        detail = [{"loc": [str(x) for x in e["loc"]], "msg": e["msg"]} for e in exc.errors()]
        return JSONResponse(status_code=422, content={"code": "INVALID_INPUT", "detail": detail})

    @app.middleware("http")
    async def _security_headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        return resp

    def current_user(authorization: Annotated[str | None, Header()] = None) -> dict[str, Any]:
        if not authorization or not authorization.startswith("Bearer "):
            raise AuthError("missing bearer token")
        return svc.user_from_token(authorization[7:])

    def roles(*allowed: str):
        def dep(user: Annotated[dict[str, Any], Depends(current_user)]) -> dict[str, Any]:
            if user["role"] not in allowed:
                raise Forbidden(f"role {user['role']!r} may not perform this action")
            return user

        return dep

    admin = roles("admin")
    registrar = roles("admin", "registrar")
    reader = roles("admin", "auditor")

    # ----- public
    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "version": __version__}

    @app.get("/hub/public-key")
    def public_key() -> dict[str, str]:
        return {"sign_pub": settings.hub_key.public_b64()}

    @app.post("/auth/login")
    def login(body: LoginIn) -> dict[str, Any]:
        user = svc.authenticate(body.username, body.password)
        token_type = "bearer"  # noqa: S105  # nosec B105
        return {"access_token": svc.issue_token(user), "token_type": token_type, "role": user["role"]}

    # ----- administration
    @app.post("/users", status_code=201)
    def create_user(body: UserIn, user: Annotated[dict, Depends(admin)]) -> dict[str, str]:
        svc.create_user(body.username, body.password, body.role, actor=user["username"])
        return {"username": body.username, "role": body.role}

    @app.post("/halls", status_code=201)
    def create_hall(body: HallIn, user: Annotated[dict, Depends(admin)]) -> dict[str, str]:
        svc.create_hall(body.id, body.name, body.capacity, user["username"])
        return {"id": body.id}

    @app.post("/sessions", status_code=201)
    def create_session(body: SessionIn, user: Annotated[dict, Depends(admin)]) -> dict[str, str]:
        svc.create_session(body.id, body.course_code, body.title, body.starts_at, body.ends_at, user["username"])
        return {"id": body.id}

    @app.post("/sessions/{session_id}/registrations", status_code=201)
    def add_registrations(
        session_id: Ident, body: RegistrationsIn, user: Annotated[dict, Depends(admin)]
    ) -> dict[str, int]:
        n = svc.add_registrations(session_id, [e.model_dump() for e in body.entries], user["username"])
        return {"added": n}

    @app.post("/sessions/{session_id}/assignments", status_code=201)
    def assign(session_id: Ident, body: AssignIn, user: Annotated[dict, Depends(admin)]) -> dict[str, str]:
        svc.assign_invigilator(session_id, body.hall_id, body.username, user["username"])
        return {"status": "assigned"}

    @app.post("/devices", status_code=201)
    def register_device(body: DeviceIn, user: Annotated[dict, Depends(admin)]) -> dict[str, str]:
        return {"device_id": svc.register_device(body.name, body.sign_pub, body.kex_pub, user["username"])}

    @app.post("/devices/{device_id}/revoke")
    def revoke_device(device_id: Ident, user: Annotated[dict, Depends(admin)]) -> dict[str, str]:
        svc.revoke_device(device_id, user["username"])
        return {"status": "revoked"}

    @app.post("/sessions/{session_id}/bundles", status_code=201)
    def issue_bundle(session_id: Ident, body: BundleIn, user: Annotated[dict, Depends(admin)]) -> dict[str, Any]:
        return svc.issue_bundle(
            session_id=session_id,
            hall_id=body.hall_id,
            device_id=body.device_id,
            valid_hours=body.valid_hours,
            actor=user["username"],
        )

    # ----- enrolment
    @app.post("/students", status_code=201)
    def enrol(body: EnrolIn, user: Annotated[dict, Depends(registrar)]) -> dict[str, Any]:
        return svc.enrol_student(
            matric_no=body.matric_no,
            full_name=body.full_name,
            department=body.department,
            level=body.level,
            captures=body.captures,
            consent=body.consent,
            actor=user["username"],
        )

    @app.get("/students/{matric_no:path}")
    def get_student(matric_no: Matric, user: Annotated[dict, Depends(registrar)]) -> dict[str, Any]:
        return svc.get_student(matric_no)

    # ----- terminal sync (device-signed, no bearer token)
    @app.post("/sync/ingest")
    def ingest(batch: dict[str, Any]) -> dict[str, Any]:
        return svc.ingest(batch)

    # ----- reporting
    @app.get("/sessions/{session_id}/report")
    def report(session_id: Ident, user: Annotated[dict, Depends(reader)]) -> dict[str, Any]:
        return svc.session_report(session_id)

    @app.get("/sessions/{session_id}/attendance")
    def attendance(session_id: Ident, user: Annotated[dict, Depends(reader)]) -> list[dict[str, Any]]:
        return svc.attendance(session_id)

    @app.get("/sessions/{session_id}/alerts")
    def alerts(session_id: Ident, user: Annotated[dict, Depends(reader)]) -> list[dict[str, Any]]:
        return svc.list_alerts(session_id)

    @app.get("/sessions/{session_id}/integrity")
    def integrity(session_id: Ident, user: Annotated[dict, Depends(reader)]) -> dict[str, Any]:
        return svc.verify_integrity(session_id)

    return app


def app_factory() -> FastAPI:  # `uvicorn bioinvigil.central.api:app_factory --factory`
    return create_app()
