"""Cryptographic primitives used by hub and terminals.

Only vetted primitives from `cryptography` and the standard library are used:
  - AES-256-GCM for confidentiality + integrity of templates and bundles
  - Ed25519 for signatures (bundles hub->edge, event batches edge->hub)
  - X25519 + HKDF-SHA256 for sealing a bundle to a terminal's public key
  - scrypt for password hashing and passphrase-derived key wrapping
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from typing import Any

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

_RAW = serialization.Encoding.Raw
_RAW_PUB = serialization.PublicFormat.Raw
_RAW_PRIV = serialization.PrivateFormat.Raw
_NO_ENC = serialization.NoEncryption()

SEAL_INFO = b"bioinvigil/seal/v1"
SCRYPT_N, SCRYPT_R, SCRYPT_P = 2**14, 8, 1


class CryptoError(Exception):
    """Raised on any failed decryption, signature or format check."""


def b64e(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def b64d(text: str) -> bytes:
    try:
        return base64.b64decode(text.encode("ascii"), validate=True)
    except (ValueError, UnicodeEncodeError) as exc:
        raise CryptoError("invalid base64") from exc


def canonical_json(obj: Any) -> bytes:
    """Deterministic JSON encoding used for hashing and signing."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# --------------------------------------------------------------- passwords
def hash_password(password: str, *, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${b64e(salt)}${b64e(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_b64, dk_b64 = stored.split("$")
        if scheme != "scrypt":
            return False
        dk = hashlib.scrypt(password.encode(), salt=b64d(salt_b64), n=int(n), r=int(r), p=int(p), dklen=32)
        return hmac.compare_digest(dk, b64d(dk_b64))
    except (ValueError, CryptoError):
        return False


# -------------------------------------------------------------------- AEAD
def aead_encrypt(key: bytes, plaintext: bytes, aad: bytes = b"") -> bytes:
    if len(key) != 32:
        raise CryptoError("key must be 32 bytes")
    nonce = os.urandom(12)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, aad)


def aead_decrypt(key: bytes, blob: bytes, aad: bytes = b"") -> bytes:
    if len(key) != 32 or len(blob) < 28:
        raise CryptoError("bad key or ciphertext length")
    try:
        return AESGCM(key).decrypt(blob[:12], blob[12:], aad)
    except InvalidTag as exc:
        raise CryptoError("authentication failed") from exc


# -------------------------------------------------------------- signatures
class SigningKey:
    def __init__(self, private: Ed25519PrivateKey):
        self._priv = private

    @classmethod
    def generate(cls) -> SigningKey:
        return cls(Ed25519PrivateKey.generate())

    @classmethod
    def from_bytes(cls, raw: bytes) -> SigningKey:
        return cls(Ed25519PrivateKey.from_private_bytes(raw))

    def private_bytes(self) -> bytes:
        return self._priv.private_bytes(_RAW, _RAW_PRIV, _NO_ENC)

    def public_b64(self) -> str:
        return b64e(self._priv.public_key().public_bytes(_RAW, _RAW_PUB))

    def sign_b64(self, data: bytes) -> str:
        return b64e(self._priv.sign(data))


def verify_signature(public_b64: str, signature_b64: str, data: bytes) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(b64d(public_b64)).verify(b64d(signature_b64), data)
        return True
    except (InvalidSignature, ValueError, CryptoError):
        return False


# ------------------------------------------------------- sealed (ECIES-like)
class KexKey:
    def __init__(self, private: X25519PrivateKey):
        self._priv = private

    @classmethod
    def generate(cls) -> KexKey:
        return cls(X25519PrivateKey.generate())

    @classmethod
    def from_bytes(cls, raw: bytes) -> KexKey:
        return cls(X25519PrivateKey.from_private_bytes(raw))

    def private_bytes(self) -> bytes:
        return self._priv.private_bytes(_RAW, _RAW_PRIV, _NO_ENC)

    def public_b64(self) -> str:
        return b64e(self._priv.public_key().public_bytes(_RAW, _RAW_PUB))

    def exchange(self, peer_public: bytes) -> bytes:
        return self._priv.exchange(X25519PublicKey.from_public_bytes(peer_public))


def _derive(shared: bytes) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=SEAL_INFO).derive(shared)


def seal_for(recipient_kex_pub_b64: str, plaintext: bytes, aad: bytes) -> dict[str, str]:
    """Encrypt to a recipient's X25519 public key using an ephemeral sender key."""
    eph = KexKey.generate()
    key = _derive(eph.exchange(b64d(recipient_kex_pub_b64)))
    return {"epk": eph.public_b64(), "blob": b64e(aead_encrypt(key, plaintext, aad))}


def open_sealed(recipient: KexKey, sealed: dict[str, str], aad: bytes) -> bytes:
    try:
        key = _derive(recipient.exchange(b64d(sealed["epk"])))
        return aead_decrypt(key, b64d(sealed["blob"]), aad)
    except (KeyError, ValueError) as exc:
        raise CryptoError("malformed sealed box") from exc


# ------------------------------------------------- passphrase key wrapping
def wrap_with_passphrase(passphrase: str, plaintext: bytes) -> bytes:
    salt = os.urandom(16)
    key = hashlib.scrypt(passphrase.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    return salt + aead_encrypt(key, plaintext, b"bioinvigil/keystore/v1")


def unwrap_with_passphrase(passphrase: str, blob: bytes) -> bytes:
    if len(blob) < 16 + 28:
        raise CryptoError("keystore too short")
    key = hashlib.scrypt(passphrase.encode(), salt=blob[:16], n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    return aead_decrypt(key, blob[16:], b"bioinvigil/keystore/v1")
