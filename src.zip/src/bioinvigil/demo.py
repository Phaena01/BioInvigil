"""Demo/seed helper: provisions a complete exam session through the hub's public API only."""

from __future__ import annotations

import json
import secrets
import time
from pathlib import Path
from typing import Any

from .biometric import SimulatedScanner
from .edge.keystore import DeviceKeys, create_keystore, save_device_id


def _ok(resp: Any, what: str) -> dict[str, Any]:
    if resp.status_code >= 300:
        raise RuntimeError(f"{what} failed: {resp.status_code} {resp.text}")
    return resp.json()


def seed(
    hub: Any,
    admin_user: str,
    admin_password: str,
    outdir: Path,
    *,
    students: int = 40,
    hall_id: str = "MAIN-BOWL",
    session_id: str = "COEN838-2026",
    prefix: str = "U20CS",
    clock: Any = time.time,
    passphrase: str | None = None,
) -> dict[str, Any]:
    """Create staff, students, hall, session, roster, device and a sealed bundle in `outdir`."""
    outdir.mkdir(parents=True, exist_ok=True)
    sc = SimulatedScanner(seed=1)

    def authed(user: str, pw: str) -> dict[str, str]:
        tok = _ok(hub.post("/auth/login", json={"username": user, "password": pw}), f"login {user}")
        return {"Authorization": f"Bearer {tok['access_token']}"}

    admin = authed(admin_user, admin_password)
    creds: dict[str, dict[str, str]] = {}
    for name, role in (
        ("registrar1", "registrar"),
        ("auditor1", "auditor"),
        ("invig1", "invigilator"),
        ("chief1", "chief_invigilator"),
    ):
        pw = secrets.token_urlsafe(14)
        _ok(hub.post("/users", json={"username": name, "password": pw, "role": role}, headers=admin), name)
        creds[name] = {"password": pw, "role": role}

    reg = authed("registrar1", creds["registrar1"]["password"])
    matrics = [f"{prefix}{1001 + i}" for i in range(students)]
    for i, m in enumerate(matrics):
        _ok(
            hub.post(
                "/students",
                headers=reg,
                json={
                    "matric_no": m,
                    "full_name": f"Student {i + 1:03d}",
                    "department": "Computer Engineering",
                    "level": 500,
                    "consent": True,
                    "captures": [[float(x) for x in sc.capture(m, "good")] for _ in range(3)],
                },
            ),
            f"enrol {m}",
        )

    now = clock()
    _ok(
        hub.post("/halls", json={"id": hall_id, "name": "Main Bowl", "capacity": max(students, 100)}, headers=admin),
        "hall",
    )
    _ok(
        hub.post(
            "/sessions",
            json={
                "id": session_id,
                "course_code": "COEN838",
                "title": "Advanced Software Engineering",
                "starts_at": now,
                "ends_at": now + 3 * 3600,
            },
            headers=admin,
        ),
        "session",
    )
    _ok(
        hub.post(
            f"/sessions/{session_id}/registrations",
            headers=admin,
            json={
                "entries": [
                    {"matric_no": m, "hall_id": hall_id, "seat_no": f"A{i + 1:03d}"} for i, m in enumerate(matrics)
                ]
            },
        ),
        "roster",
    )
    for u in ("invig1", "chief1"):
        _ok(hub.post(f"/sessions/{session_id}/assignments", json={"hall_id": hall_id, "username": u}, headers=admin), u)

    passphrase = passphrase or secrets.token_urlsafe(18)
    keys_path = outdir / "keys.enc"
    keys: DeviceKeys = create_keystore(keys_path, passphrase)
    dev = _ok(
        hub.post(
            "/devices",
            headers=admin,
            json={"name": "Terminal-01", "sign_pub": keys.sign.public_b64(), "kex_pub": keys.kex.public_b64()},
        ),
        "device",
    )
    save_device_id(keys_path, passphrase, dev["device_id"])
    bundle = _ok(
        hub.post(
            f"/sessions/{session_id}/bundles",
            headers=admin,
            json={"hall_id": hall_id, "device_id": dev["device_id"], "valid_hours": 24},
        ),
        "bundle",
    )
    hub_pub = _ok(hub.get("/hub/public-key"), "hub key")["sign_pub"]
    (outdir / "bundle.json").write_text(json.dumps(bundle))
    (outdir / "hub_pub.txt").write_text(hub_pub)
    return {
        "matrics": matrics,
        "creds": creds,
        "device_id": dev["device_id"],
        "passphrase": passphrase,
        "session_id": session_id,
        "hall_id": hall_id,
        "bundle_id": bundle["bundle_id"],
        "paths": {
            "keys": str(keys_path),
            "bundle": str(outdir / "bundle.json"),
            "hub_pub": str(outdir / "hub_pub.txt"),
        },
    }
