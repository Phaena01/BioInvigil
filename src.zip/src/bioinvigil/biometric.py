"""Template handling, matching and the simulated fingerprint scanner.

The matcher is deliberately isolated behind small pure functions so a certified
vendor SDK can replace it (see docs: assumption A-2). Templates are fixed-length
unit vectors; the similarity measure is cosine similarity.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

DIM = 128
_POLICY_FILE = Path(__file__).with_name("match_policy.json")


@dataclass(frozen=True)
class MatchPolicy:
    verify_threshold: float  # 1:1 verification (card + finger)
    identify_threshold: float  # 1:N identification inside one hall roster
    identify_margin: float  # required gap between best and second-best score
    dedup_threshold: float  # enrolment duplicate screening (manual adjudication)
    enrol_quality_min: float  # minimum pairwise similarity between enrolment captures
    max_attempts: int  # failed 1:1 attempts before referral

    @classmethod
    def load(cls, path: Path = _POLICY_FILE) -> MatchPolicy:
        data = json.loads(path.read_text())
        return cls(**{k: data[k] for k in cls.__dataclass_fields__})

    def as_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}


# ------------------------------------------------------------------ vectors
def normalize(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=np.float32)
    n = float(np.linalg.norm(v))
    if not np.isfinite(n) or n == 0.0:
        raise ValueError("cannot normalise zero/non-finite vector")
    return v / n


def validate_vector(values: list[float] | np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=np.float32)
    if arr.shape != (DIM,):
        raise ValueError(f"vector must have length {DIM}")
    if not np.all(np.isfinite(arr)):
        raise ValueError("vector contains non-finite values")
    return arr


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.dot(normalize(a), normalize(b)))


def make_template(captures: list[np.ndarray]) -> np.ndarray:
    """Average several enrolment captures and renormalise."""
    stack = np.stack([normalize(c) for c in captures])
    return normalize(stack.mean(axis=0))


def capture_consistency(captures: list[np.ndarray]) -> float:
    """Minimum pairwise cosine similarity between enrolment captures."""
    unit = np.stack([normalize(c) for c in captures])
    sims = unit @ unit.T
    iu = np.triu_indices(len(captures), k=1)
    return float(sims[iu].min())


def score_all(probe: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    """Cosine similarity of one probe against every row of a unit-norm matrix."""
    return matrix @ normalize(probe)


def encode_template(t: np.ndarray) -> bytes:
    return np.asarray(t, dtype="<f4").tobytes()


def decode_template(raw: bytes) -> np.ndarray:
    if len(raw) != DIM * 4:
        raise ValueError("bad template length")
    return np.frombuffer(raw, dtype="<f4").copy()


# --------------------------------------------------------------- simulator
QUALITY_SIGMA = {"good": 0.50, "fair": 0.80, "poor": 1.30}
POPULATION_CORRELATION = 0.35  # shared component between all fingers (ridge-pattern classes)


class SimulatedScanner:
    """Statistical stand-in for a fingerprint reader.

    A person's 'finger' is a deterministic vector derived from their matric number plus a
    population-wide shared component. Each capture adds isotropic Gaussian noise whose
    standard deviation depends on capture quality (dry/wet finger, pressure, placement).
    """

    def __init__(self, seed: int | None = None, rho: float = POPULATION_CORRELATION):
        self._rng = np.random.default_rng(seed)
        self._rho = rho
        self._common = np.random.default_rng(20260101).standard_normal(DIM)

    def finger(self, identity: str) -> np.ndarray:
        digest = hashlib.sha256(identity.encode()).digest()
        ident = np.random.default_rng(int.from_bytes(digest[:8], "little")).standard_normal(DIM)
        return np.sqrt(self._rho) * self._common + np.sqrt(1 - self._rho) * ident

    def capture(self, identity: str, quality: str | float = "good") -> np.ndarray:
        sigma = QUALITY_SIGMA[quality] if isinstance(quality, str) else float(quality)
        noisy = self.finger(identity) + sigma * self._rng.standard_normal(DIM)
        return noisy.astype(np.float32)
