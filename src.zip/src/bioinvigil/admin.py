"""Hub administration client:  python -m bioinvigil.admin --hub URL --user NAME COMMAND ...

The hub exposes a REST API only. This tool wraps the calls that staff need, so no one has to hand-write JSON.
Passwords: BIOINVIGIL_PASSWORD (yours) and BIOINVIGIL_NEW_PASSWORD (a new user's), otherwise prompted.
"""

from __future__ import annotations

import argparse
import csv
import getpass
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx

from .biometric import SimulatedScanner

ROLES = ("admin", "registrar", "auditor", "invigilator", "chief_invigilator")


class AdminError(Exception):
    """A hub call failed or an input file was unusable."""


def _call(client: Any, method: str, path: str, token: str | None = None, body: Any = None) -> Any:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    resp = client.request(method, path, headers=headers, json=body)
    if resp.status_code >= 300:
        raise AdminError(f"{method} {path} -> {resp.status_code}: {resp.text[:300]}")
    return resp.json()


def _login(client: Any, user: str) -> str:
    pw = os.environ.get("BIOINVIGIL_PASSWORD") or getpass.getpass(f"Password for {user}: ")
    return _call(client, "POST", "/auth/login", body={"username": user, "password": pw})["access_token"]


def _rows(path: str, required: tuple[str, ...]) -> list[dict[str, str]]:
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        raise AdminError(f"{path} has no rows")
    missing = [c for c in required if c not in rows[0]]
    if missing:
        raise AdminError(f"{path} lacks column(s): {', '.join(missing)}")
    return rows


def _epoch(text: str) -> float:
    try:
        dt = datetime.fromisoformat(text)
    except ValueError as exc:
        raise AdminError(f"not an ISO 8601 date-time: {text!r}") from exc
    if dt.tzinfo is None:
        raise AdminError(f"date-time needs a UTC offset, e.g. 2026-11-02T09:00:00+01:00: {text!r}")
    return dt.timestamp()


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="bioinvigil.admin", description=__doc__)
    ap.add_argument("--hub", default="http://127.0.0.1:8000")
    ap.add_argument("--user", required=True)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def add(name: str, *args: str, **kw: Any) -> argparse.ArgumentParser:
        p = sub.add_parser(name, **kw)
        for a in args:
            p.add_argument(a)
        return p

    add("user-add", "username").add_argument("role", choices=ROLES)
    p = add("hall-add", "hall_id", "name")
    p.add_argument("capacity", type=int)
    p = add("session-add", "session_id", "course_code", "title")
    p.add_argument("--start", required=True)
    p.add_argument("--end", required=True)
    add("roster-import", "session_id", "csv")
    add("assign", "session_id", "hall_id", "username")
    add("enrol-csv", "csv").add_argument("--seed", type=int, default=None)
    add("device-register", "name", "keys_json")
    add("device-revoke", "device_id")
    p = add("bundle-issue", "session_id", "hall_id", "device_id")
    p.add_argument("--hours", type=int, default=24)
    p.add_argument("--out", type=Path, default=Path("bundle.json"))
    p.add_argument("--hub-pub-out", type=Path, default=Path("hub_pub.txt"))
    for r in ("report", "attendance", "alerts", "integrity"):
        add(r, "session_id")
    return ap


def run(args: argparse.Namespace, client: Any) -> Any:
    token = _login(client, args.user)

    def call(method: str, path: str, body: Any = None) -> Any:
        return _call(client, method, path, token, body)

    c = args.cmd
    if c == "user-add":
        pw = os.environ.get("BIOINVIGIL_NEW_PASSWORD") or getpass.getpass(f"Password for new user {args.username}: ")
        return call("POST", "/users", {"username": args.username, "password": pw, "role": args.role})
    if c == "hall-add":
        return call("POST", "/halls", {"id": args.hall_id, "name": args.name, "capacity": args.capacity})
    if c == "session-add":
        body = {
            "id": args.session_id,
            "course_code": args.course_code,
            "title": args.title,
            "starts_at": _epoch(args.start),
            "ends_at": _epoch(args.end),
        }
        return call("POST", "/sessions", body)
    if c == "roster-import":
        rows = _rows(args.csv, ("matric_no", "hall_id", "seat_no"))
        entries = [{k: r[k].strip() for k in ("matric_no", "hall_id", "seat_no")} for r in rows]
        return call("POST", f"/sessions/{args.session_id}/registrations", {"entries": entries})
    if c == "assign":
        return call(
            "POST", f"/sessions/{args.session_id}/assignments", {"hall_id": args.hall_id, "username": args.username}
        )
    if c == "enrol-csv":
        # Captures come from the simulated scanner; swap in the real scanner driver at deployment (A-1).
        scanner = SimulatedScanner(seed=args.seed)
        done = []
        for r in _rows(args.csv, ("matric_no", "full_name", "department", "level", "consent")):
            m = r["matric_no"].strip().upper()
            body = {
                "matric_no": m,
                "full_name": r["full_name"].strip(),
                "department": r["department"].strip(),
                "level": int(r["level"]),
                "consent": r["consent"].strip().lower() in ("yes", "true", "1"),
                "captures": [[float(x) for x in scanner.capture(m, "good")] for _ in range(3)],
            }
            done.append(call("POST", "/students", body)["matric_no"])
        return {"enrolled": done}
    if c == "device-register":
        keys = json.loads(Path(args.keys_json).read_text())
        return call("POST", "/devices", {"name": args.name, "sign_pub": keys["sign_pub"], "kex_pub": keys["kex_pub"]})
    if c == "device-revoke":
        return call("POST", f"/devices/{args.device_id}/revoke")
    if c == "bundle-issue":
        bundle = call(
            "POST",
            f"/sessions/{args.session_id}/bundles",
            {"hall_id": args.hall_id, "device_id": args.device_id, "valid_hours": args.hours},
        )
        args.out.write_text(json.dumps(bundle))
        args.hub_pub_out.write_text(_call(client, "GET", "/hub/public-key")["sign_pub"])
        return {"bundle_id": bundle["bundle_id"], "bundle": str(args.out), "hub_pub": str(args.hub_pub_out)}
    return call("GET", f"/sessions/{args.session_id}/{c}")


def main(argv: list[str] | None = None, client: Any = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if client is None:
            with httpx.Client(base_url=args.hub, timeout=30) as http:
                result = run(args, http)
        else:
            result = run(args, client)
    except (AdminError, httpx.HTTPError, OSError, ValueError, KeyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
