"""Domain errors, each carrying the HTTP status the API layer should return."""


class BioInvigilError(Exception):
    status = 400
    code = "ERROR"

    def __init__(self, message: str, *, extra: dict | None = None):
        super().__init__(message)
        self.message = message
        self.extra = extra or {}


class InvalidInput(BioInvigilError):
    status, code = 422, "INVALID_INPUT"


class AuthError(BioInvigilError):
    status, code = 401, "AUTH_FAILED"


class Forbidden(BioInvigilError):
    status, code = 403, "FORBIDDEN"


class NotFound(BioInvigilError):
    status, code = 404, "NOT_FOUND"


class Conflict(BioInvigilError):
    status, code = 409, "CONFLICT"


class IntegrityViolation(Conflict):
    code = "INTEGRITY_VIOLATION"


class BundleError(BioInvigilError):
    """Bundle failed signature, binding, decryption or validity checks (fail closed)."""

    status, code = 400, "BUNDLE_REJECTED"
