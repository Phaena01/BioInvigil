"""BioInvigil - offline-first biometric exam invigilation system."""

__version__ = "1.0.0"
