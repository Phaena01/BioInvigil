"""Hub configuration. Secrets come from the environment; production refuses to guess."""

from __future__ import annotations

import json
import logging
import os
import secrets
from dataclasses import dataclass
from pathlib import Path

from .crypto import SigningKey, b64d, b64e

log = logging.getLogger("bioinvigil.config")


@dataclass
class Settings:
    env: str
    db_path: str
    jwt_secret: bytes
    master_key: bytes
    hub_key: SigningKey
    token_ttl_s: int = 1800
    lockout_threshold: int = 5
    lockout_seconds: int = 300
    min_password_len: int = 12

    @classmethod
    def from_env(cls) -> Settings:
        env = os.environ.get("BIOINVIGIL_ENV", "development")
        db_path = os.environ.get("BIOINVIGIL_DB", "hub.db")
        names = ("BIOINVIGIL_JWT_SECRET", "BIOINVIGIL_MASTER_KEY", "BIOINVIGIL_HUB_SIGNING_KEY")
        if all(os.environ.get(n) for n in names):
            return cls(
                env=env,
                db_path=db_path,
                jwt_secret=b64d(os.environ[names[0]]),
                master_key=b64d(os.environ[names[1]]),
                hub_key=SigningKey.from_bytes(b64d(os.environ[names[2]])),
            )
        if env == "production":
            raise RuntimeError(f"production requires {', '.join(names)}")
        return cls._dev_settings(db_path)

    @classmethod
    def _dev_settings(cls, db_path: str) -> Settings:
        """Development only: persist generated keys next to the DB so restarts keep working."""
        keyfile = Path(f"{db_path}.devkeys.json")
        if keyfile.exists():
            k = json.loads(keyfile.read_text())
        else:
            log.warning("generating DEVELOPMENT keys at %s - never use in production", keyfile)
            k = {
                "jwt": b64e(secrets.token_bytes(32)),
                "master": b64e(secrets.token_bytes(32)),
                "hub": b64e(SigningKey.generate().private_bytes()),
            }
            fd = os.open(keyfile, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as fh:
                json.dump(k, fh)
        return cls(
            env="development",
            db_path=db_path,
            jwt_secret=b64d(k["jwt"]),
            master_key=b64d(k["master"]),
            hub_key=SigningKey.from_bytes(b64d(k["hub"])),
        )

    @classmethod
    def ephemeral(cls, db_path: str = ":memory:") -> Settings:
        """Throw-away keys for tests."""
        return cls(
            env="test",
            db_path=db_path,
            jwt_secret=secrets.token_bytes(32),
            master_key=secrets.token_bytes(32),
            hub_key=SigningKey.generate(),
            lockout_seconds=300,
        )
