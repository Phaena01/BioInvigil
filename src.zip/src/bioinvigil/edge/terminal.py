"""Offline verification engine running on the hall terminal.

Everything here works with no network: the signed, device-sealed bundle supplies the roster,
templates, invigilator credential verifiers and matching policy.
"""

from __future__ import annotations

import json
import secrets
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from typing import Any

import jwt
import numpy as np

from .. import biometric
from ..biometric import MatchPolicy
from ..crypto import CryptoError, b64d, canonical_json, open_sealed, verify_password, verify_signature
from ..errors import AuthError, BundleError, Conflict, Forbidden, InvalidInput, NotFound
from .keystore import DeviceKeys
from .store import EventStore

OVERRIDE_REASONS = {"SCANNER_FAULT", "INJURED_FINGER", "POOR_PRINT", "NO_ENROLMENT_TEMPLATE", "OTHER"}
CLOCK_SLACK_S = 300
LOGIN_FAIL_LIMIT, LOGIN_LOCK_S = 5, 300
TOKEN_TTL_S = 4 * 3600


@dataclass
class Decision:
    outcome: str
    matric_no: str | None = None
    name: str | None = None
    seat_no: str | None = None
    score: float | None = None
    attempts_left: int | None = None
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class Terminal:
    def __init__(self, store: EventStore, clock: Callable[[], float] = time.time):
        self.store, self.clock = store, clock
        self._jwt_secret = secrets.token_bytes(32)
        self.bundle_id: str | None = None
        self.session: dict[str, Any] = {}
        self.hall_id = ""
        self.valid_until = 0.0
        self.policy: MatchPolicy | None = None
        self.roster: dict[str, dict[str, str]] = {}
        self.directory: dict[str, str] = {}
        self.users: dict[str, dict[str, str]] = {}
        self._ids: list[str] = []
        self._matrix = np.empty((0, biometric.DIM), dtype=np.float32)

    # ------------------------------------------------------------- bundle
    def load_bundle(self, envelope: dict[str, Any], keys: DeviceKeys, hub_pub_b64: str) -> None:
        """Verify, bind, decrypt and activate a bundle. Any failure leaves the terminal closed."""
        try:
            sig = envelope["sig"]
            unsigned = {k: v for k, v in envelope.items() if k != "sig"}
            if not verify_signature(hub_pub_b64, sig, canonical_json(unsigned)):
                raise BundleError("hub signature invalid")
            meta = {k: v for k, v in unsigned.items() if k != "sealed"}
            if keys.device_id is None or meta["device_id"] != keys.device_id:
                raise BundleError("bundle was issued to a different device")
            if (meta["device_id"], meta["session_id"]) != (self.store.device_id, self.store.session_id):
                raise BundleError("bundle does not match this terminal's database")
            now = self.clock()
            if not meta["valid_from"] - CLOCK_SLACK_S <= now <= meta["valid_until"]:
                raise BundleError("bundle outside its validity window")
            plain = open_sealed(keys.kex, unsigned["sealed"], canonical_json(meta))
            payload = json.loads(plain)
            policy = MatchPolicy(**payload["policy"])
            roster: dict[str, dict[str, str]] = {}
            vectors = []
            for r in payload["roster"]:
                vec = biometric.normalize(biometric.decode_template(b64d(r["template"])))
                roster[r["matric_no"]] = {"name": r["name"], "seat_no": r["seat_no"]}
                vectors.append(vec)
            if not roster:
                raise BundleError("empty roster")
            users = {u["username"]: u for u in payload["users"]}
        except (KeyError, TypeError, ValueError, CryptoError) as exc:
            if isinstance(exc, BundleError):
                raise
            raise BundleError(f"bundle malformed or undecryptable: {exc}") from exc

        self.bundle_id, self.session, self.hall_id = meta["bundle_id"], payload["session"], payload["hall_id"]
        self.valid_until, self.policy = meta["valid_until"], policy
        self.roster, self.users = roster, users
        self.directory = {d["matric_no"]: d["hall_id"] for d in payload["directory"]}
        self._ids = list(roster)
        self._matrix = np.stack(vectors).astype(np.float32)
        self.store.append("SESSION_OPEN", None, {"bundle_id": self.bundle_id, "roster": len(roster)})

    def _require_open(self) -> MatchPolicy:
        if self.policy is None:
            raise BundleError("no bundle loaded")
        if self.clock() > self.valid_until:
            raise BundleError("bundle expired; terminal closed until re-provisioned")
        return self.policy

    # --------------------------------------------------------------- auth
    def login(self, username: str, password: str) -> str:
        now = self.clock()
        fail_key = f"fail:{username}"
        state = json.loads(self.store.get_meta(fail_key) or '{"n":0,"until":0}')
        user = self.users.get(username)
        if state["until"] > now:
            raise AuthError("account temporarily locked")
        if user is None or not verify_password(password, user["pw_hash"]):
            state["n"] += 1
            if state["n"] >= LOGIN_FAIL_LIMIT:
                state = {"n": 0, "until": now + LOGIN_LOCK_S}
            self.store.set_meta(fail_key, json.dumps(state))
            raise AuthError("invalid credentials")
        self.store.set_meta(fail_key, '{"n":0,"until":0}')
        claims = {"sub": username, "role": user["role"], "iat": int(now), "exp": int(now) + TOKEN_TTL_S}
        return jwt.encode(claims, self._jwt_secret, algorithm="HS256")

    def user_from_token(self, token: str) -> dict[str, str]:
        try:
            c = jwt.decode(token, self._jwt_secret, algorithms=["HS256"], options={"require": ["exp", "sub", "role"]})
        except jwt.PyJWTError as exc:
            raise AuthError("invalid or expired token") from exc
        if c["sub"] not in self.users:
            raise AuthError("unknown user")
        return {"username": c["sub"], "role": c["role"]}

    # ------------------------------------------------------- verification
    @staticmethod
    def _probe(values: list[float]) -> np.ndarray:
        try:
            return biometric.validate_vector(values)
        except ValueError as exc:
            raise InvalidInput(str(exc)) from exc

    def _admit_checks(self, matric: str, score: float, mode: str, actor: str) -> Decision | None:
        """Shared pre-admission rules for 1:1 and 1:N. Returns a Decision if admission is blocked."""
        pol = self.policy
        entry = self.roster[matric]
        base = {"matric_no": matric, "name": entry["name"], "seat_no": entry["seat_no"], "score": round(score, 4)}
        if matric in self.store.admitted():
            self.store.append(
                "DUPLICATE",
                matric,
                {
                    "score": round(score, 4),
                    "biometric_match": bool(score >= pol.verify_threshold),
                    "mode": mode,
                    "actor": actor,
                },
            )
            return Decision(
                "ALREADY_ADMITTED",
                **base,
                message="Identity already admitted in this hall - refer to chief invigilator",
            )
        if self.store.is_locked(matric):
            self.store.append("REJECT", matric, {"reason": "LOCKED", "score": round(score, 4), "actor": actor})
            return Decision(
                "REVIEW_REQUIRED", **base, message="Locked after failed attempts - chief invigilator override required"
            )
        return None

    def verify(self, matric_no: str, probe: list[float], actor: str) -> Decision:
        pol = self._require_open()
        matric = matric_no.strip().upper()
        if not matric or len(matric) > 20 or not all(ch.isalnum() or ch in "/-" for ch in matric):
            raise InvalidInput("invalid matric number")
        vec = self._probe(probe)
        if matric not in self.roster:
            if matric in self.directory:
                self.store.append(
                    "REJECT",
                    matric,
                    {"reason": "WRONG_HALL", "registered_hall": self.directory[matric], "actor": actor},
                )
                return Decision("WRONG_HALL", matric_no=matric, message=f"Registered for hall {self.directory[matric]}")
            self.store.append("REJECT", matric, {"reason": "NOT_ON_ROSTER", "actor": actor})
            return Decision("NOT_ON_ROSTER", matric_no=matric, message="Not registered for this exam")
        template = self._matrix[self._ids.index(matric)]
        score = biometric.cosine(vec, template)
        blocked = self._admit_checks(matric, score, "1:1", actor)
        if blocked:
            return blocked
        entry = self.roster[matric]
        base = {"matric_no": matric, "name": entry["name"], "seat_no": entry["seat_no"], "score": round(score, 4)}
        if score >= pol.verify_threshold:
            self.store.append("ADMIT", matric, {"mode": "1:1", "score": round(score, 4), "actor": actor})
            return Decision("ADMIT", **base, message="Verified")
        attempts = self.store.mismatch_count(matric) + 1
        self.store.append(
            "REJECT", matric, {"reason": "MISMATCH", "score": round(score, 4), "attempt": attempts, "actor": actor}
        )
        if attempts >= pol.max_attempts:
            self.store.append("REVIEW", matric, {"attempts": attempts, "actor": actor})
            return Decision(
                "REVIEW_REQUIRED",
                **base,
                attempts_left=0,
                message="No match after maximum attempts - referred to chief invigilator",
            )
        return Decision(
            "REJECT_MISMATCH",
            **base,
            attempts_left=pol.max_attempts - attempts,
            message="Fingerprint does not match - retry",
        )

    def identify(self, probe: list[float], actor: str) -> Decision:
        pol = self._require_open()
        vec = self._probe(probe)
        scores = biometric.score_all(vec, self._matrix)
        order = np.argsort(-scores)
        best = float(scores[order[0]])
        second = float(scores[order[1]]) if len(order) > 1 else -1.0
        if best < pol.identify_threshold:
            self.store.append("NO_MATCH", None, {"best_score": round(best, 4), "actor": actor})
            return Decision("NO_MATCH", score=round(best, 4), message="No enrolled student in this hall matches")
        if best - second < pol.identify_margin:
            self.store.append(
                "NO_MATCH",
                None,
                {"best_score": round(best, 4), "second_score": round(second, 4), "reason": "AMBIGUOUS", "actor": actor},
            )
            return Decision("AMBIGUOUS", score=round(best, 4), message="Ambiguous match - use card + 1:1 verification")
        matric = self._ids[int(order[0])]
        blocked = self._admit_checks(matric, best, "1:N", actor)
        if blocked:
            return blocked
        entry = self.roster[matric]
        self.store.append(
            "ADMIT", matric, {"mode": "1:N", "score": round(best, 4), "margin": round(best - second, 4), "actor": actor}
        )
        return Decision(
            "ADMIT",
            matric_no=matric,
            name=entry["name"],
            seat_no=entry["seat_no"],
            score=round(best, 4),
            message="Identified",
        )

    def override(
        self, matric_no: str, reason_code: str, note: str, approver_username: str, approver_password: str, actor: str
    ) -> Decision:
        self._require_open()
        matric = matric_no.strip().upper()
        if reason_code not in OVERRIDE_REASONS:
            raise InvalidInput("invalid reason code")
        if len(note) > 200:
            raise InvalidInput("note too long")
        if matric not in self.roster:
            raise NotFound("student not on this hall's roster")
        approver = self.users.get(approver_username)
        denied = (
            approver is None
            or approver["role"] != "chief_invigilator"
            or approver_username == actor
            or not verify_password(approver_password, approver["pw_hash"])
        )
        if denied:
            self.store.append(
                "REJECT", matric, {"reason": "OVERRIDE_DENIED", "actor": actor, "approver": approver_username}
            )
            raise Forbidden("override requires approval by a different chief invigilator")
        if matric in self.store.admitted():
            raise Conflict("student already admitted")
        self.store.append(
            "OVERRIDE",
            matric,
            {"reason_code": reason_code, "note": note, "approver": approver_username, "actor": actor},
        )
        entry = self.roster[matric]
        return Decision(
            "OVERRIDE_ADMIT",
            matric_no=matric,
            name=entry["name"],
            seat_no=entry["seat_no"],
            message="Admitted by override - flagged for review",
        )

    # ------------------------------------------------------------- status
    def status(self) -> dict[str, Any]:
        admitted = self.store.admitted()
        counts = self.store.counts()
        seq, _ = self.store.last()
        return {
            "session": self.session,
            "hall_id": self.hall_id,
            "bundle_id": self.bundle_id,
            "valid_until": self.valid_until,
            "expected": len(self.roster),
            "admitted": len(admitted),
            "overrides": sum(1 for v in admitted.values() if v == "OVERRIDE"),
            "rejects": counts.get("REJECT", 0),
            "reviews": counts.get("REVIEW", 0),
            "duplicates": counts.get("DUPLICATE", 0),
            "no_match": counts.get("NO_MATCH", 0),
            "events": seq,
            "unsynced": seq - self.store.acked_seq,
        }
