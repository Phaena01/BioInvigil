"""Terminal key storage: private keys never touch disk unencrypted (scrypt + AES-GCM)."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

from ..crypto import (
    CryptoError,
    KexKey,
    SigningKey,
    b64d,
    b64e,
    unwrap_with_passphrase,
    wrap_with_passphrase,
)


@dataclass
class DeviceKeys:
    sign: SigningKey
    kex: KexKey
    device_id: str | None = None


def _write_private(path: Path, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)


def _dump(keys: DeviceKeys, passphrase: str) -> bytes:
    raw = json.dumps(
        {"sign": b64e(keys.sign.private_bytes()), "kex": b64e(keys.kex.private_bytes()), "device_id": keys.device_id}
    ).encode()
    return wrap_with_passphrase(passphrase, raw)


def create_keystore(path: str | Path, passphrase: str) -> DeviceKeys:
    if len(passphrase) < 12:
        raise ValueError("passphrase must be at least 12 characters")
    keys = DeviceKeys(SigningKey.generate(), KexKey.generate())
    _write_private(Path(path), _dump(keys, passphrase))
    return keys


def load_keystore(path: str | Path, passphrase: str) -> DeviceKeys:
    try:
        raw = json.loads(unwrap_with_passphrase(passphrase, Path(path).read_bytes()))
        return DeviceKeys(
            SigningKey.from_bytes(b64d(raw["sign"])),
            KexKey.from_bytes(b64d(raw["kex"])),
            raw.get("device_id"),
        )
    except (CryptoError, ValueError, KeyError) as exc:
        raise CryptoError("cannot open keystore (wrong passphrase or corrupted file)") from exc


def save_device_id(path: str | Path, passphrase: str, device_id: str) -> DeviceKeys:
    keys = load_keystore(path, passphrase)
    keys.device_id = device_id
    _write_private(Path(path), _dump(keys, passphrase))
    return keys
