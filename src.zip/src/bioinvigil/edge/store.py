"""Terminal-local persistence: crash-safe, hash-chained event log (SQLite WAL, synchronous=FULL)."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from collections.abc import Callable
from typing import Any

from .. import audit
from ..audit import GENESIS
from ..errors import Conflict

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(
  seq INTEGER PRIMARY KEY,
  event_id TEXT NOT NULL UNIQUE,
  ts REAL NOT NULL,
  type TEXT NOT NULL,
  matric_no TEXT,
  payload TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


class EventStore:
    def __init__(self, path: str, device_id: str, session_id: str, clock: Callable[[], float] = time.time):
        self.device_id, self.session_id, self.clock = device_id, session_id, clock
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.conn.row_factory = sqlite3.Row
        if path != ":memory:":
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA synchronous=FULL")
        self.conn.executescript(SCHEMA)
        bound = f"{device_id}|{session_id}"
        existing = self.get_meta("binding")
        if existing is None:
            self.set_meta("binding", bound)
        elif existing != bound:
            self.conn.close()  # do not leave the file locked (Windows) when refusing it
            raise Conflict("this database belongs to a different device/session; use a new file")

    def close(self) -> None:
        self.conn.close()

    # --- meta
    def get_meta(self, key: str) -> str | None:
        with self._lock:
            row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None

    def set_meta(self, key: str, value: str) -> None:
        with self._lock:
            self.conn.execute(
                "INSERT INTO meta(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )

    # --- events
    def last(self) -> tuple[int, str]:
        with self._lock:
            row = self.conn.execute("SELECT seq, hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        return (row["seq"], row["hash"]) if row else (0, GENESIS)

    def append(self, etype: str, matric_no: str | None, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            self.conn.execute("BEGIN IMMEDIATE")
            try:
                seq, prev = self.last()
                ev = audit.make_event(
                    prev_hash=prev,
                    seq=seq + 1,
                    device_id=self.device_id,
                    session_id=self.session_id,
                    etype=etype,
                    matric_no=matric_no,
                    payload=payload,
                    ts=self.clock(),
                )
                self.conn.execute(
                    "INSERT INTO events VALUES (?,?,?,?,?,?,?,?)",
                    (
                        ev["seq"],
                        ev["event_id"],
                        ev["ts"],
                        ev["type"],
                        ev["matric_no"],
                        json.dumps(payload, sort_keys=True),
                        ev["prev_hash"],
                        ev["hash"],
                    ),
                )
                self.conn.execute("COMMIT")
            except BaseException:
                self.conn.execute("ROLLBACK")
                raise
        return ev

    @staticmethod
    def _row(r: sqlite3.Row) -> dict[str, Any]:
        return {
            "event_id": r["event_id"],
            "device_id": None,
            "session_id": None,
            "seq": r["seq"],
            "ts": r["ts"],
            "type": r["type"],
            "matric_no": r["matric_no"],
            "payload": json.loads(r["payload"]),
            "prev_hash": r["prev_hash"],
            "hash": r["hash"],
        }

    def _full(self, r: sqlite3.Row) -> dict[str, Any]:
        ev = self._row(r)
        ev["device_id"], ev["session_id"] = self.device_id, self.session_id
        return ev

    def after(self, seq: int, limit: int = 200) -> list[dict[str, Any]]:
        with self._lock:
            rows = self.conn.execute("SELECT * FROM events WHERE seq>? ORDER BY seq LIMIT ?", (seq, limit)).fetchall()
        return [self._full(r) for r in rows]

    def all(self) -> list[dict[str, Any]]:
        return self.after(0, limit=10**9)

    def verify(self) -> tuple[bool, int | None, str]:
        return audit.verify_chain(self.all())

    # --- derived state
    def admitted(self) -> dict[str, str]:
        """matric -> 'ADMIT' | 'OVERRIDE' for every admitted student."""
        with self._lock:
            rows = self.conn.execute("SELECT matric_no, type FROM events WHERE type IN ('ADMIT','OVERRIDE')").fetchall()
        return {r["matric_no"]: r["type"] for r in rows}

    def mismatch_count(self, matric_no: str) -> int:
        with self._lock:
            rows = self.conn.execute(
                "SELECT payload FROM events WHERE type='REJECT' AND matric_no=?", (matric_no,)
            ).fetchall()
        return sum(1 for r in rows if json.loads(r["payload"]).get("reason") == "MISMATCH")

    def is_locked(self, matric_no: str) -> bool:
        with self._lock:
            row = self.conn.execute(
                "SELECT MAX(seq) s FROM events WHERE type='REVIEW' AND matric_no=?", (matric_no,)
            ).fetchone()
        return row["s"] is not None

    def counts(self) -> dict[str, int]:
        with self._lock:
            rows = self.conn.execute("SELECT type, COUNT(*) n FROM events GROUP BY type").fetchall()
        return {r["type"]: r["n"] for r in rows}

    @property
    def acked_seq(self) -> int:
        return int(self.get_meta("acked_seq") or 0)

    def set_acked(self, seq: int) -> None:
        self.set_meta("acked_seq", str(seq))
