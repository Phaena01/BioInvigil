"""python -m bioinvigil.edge --bundle bundle.json --keys keys.enc --hub-pub hub_pub.txt [--hub-url URL]"""

from __future__ import annotations

import argparse
import getpass
import json
import os
from pathlib import Path

import httpx
import uvicorn

from .api import create_edge_app
from .keystore import load_keystore
from .store import EventStore
from .sync import SyncAgent
from .terminal import Terminal


def build_app(
    bundle: Path,
    keys: Path,
    hub_pub: Path,
    db: Path,
    hub_url: str | None,
    passphrase: str,
    simulator: bool,
    sync_interval: float | None = None,
):
    device_keys = load_keystore(keys, passphrase)
    envelope = json.loads(bundle.read_text())
    store = EventStore(str(db), device_keys.device_id, envelope["session_id"])
    terminal = Terminal(store)
    terminal.load_bundle(envelope, device_keys, hub_pub.read_text().strip())
    sync = None
    if hub_url:
        sync = SyncAgent(store, device_keys, envelope["bundle_id"], httpx.Client(base_url=hub_url, timeout=10))
    return create_edge_app(terminal, sync, simulator, sync_interval)


def main() -> None:
    ap = argparse.ArgumentParser(prog="bioinvigil.edge")
    ap.add_argument("--bundle", type=Path, required=True)
    ap.add_argument("--keys", type=Path, required=True)
    ap.add_argument("--hub-pub", type=Path, required=True)
    ap.add_argument("--db", type=Path, default=Path("terminal.db"))
    ap.add_argument("--hub-url", default=None)
    ap.add_argument(
        "--sync-interval", type=float, default=30.0, help="seconds between background syncs; 0 = manual only"
    )
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8001)
    args = ap.parse_args()
    passphrase = os.environ.get("BIOINVIGIL_KEY_PASSPHRASE") or getpass.getpass("Keystore passphrase: ")
    simulator = os.environ.get("BIOINVIGIL_SIMULATOR") == "1"
    uvicorn.run(
        build_app(
            args.bundle,
            args.keys,
            args.hub_pub,
            args.db,
            args.hub_url,
            passphrase,
            simulator,
            args.sync_interval or None,
        ),
        host=args.host,
        port=args.port,
    )


if __name__ == "__main__":
    main()
