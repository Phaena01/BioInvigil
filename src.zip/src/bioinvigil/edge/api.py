"""Terminal-local API (loopback by default). Serves the invigilator UI and JSON endpoints."""

import logging
import threading
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Annotated, Any

from fastapi import Depends, FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from .. import __version__
from ..biometric import DIM, SimulatedScanner
from ..errors import AuthError, BioInvigilError, NotFound
from .sync import SyncAgent
from .terminal import OVERRIDE_REASONS, Terminal

STATIC = Path(__file__).with_name("static")
Vector = Annotated[list[float], Field(min_length=DIM, max_length=DIM)]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class LoginIn(Strict):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)


class VerifyIn(Strict):
    matric_no: str = Field(min_length=1, max_length=20)
    probe: Vector


class IdentifyIn(Strict):
    probe: Vector


class OverrideIn(Strict):
    matric_no: str = Field(min_length=1, max_length=20)
    reason_code: str
    note: str = Field(default="", max_length=200)
    approver_username: str = Field(min_length=1, max_length=64)
    approver_password: str = Field(min_length=1, max_length=128)


class SimIn(Strict):
    finger_of: str = Field(min_length=1, max_length=20)
    quality: str = Field(default="good", pattern="^(good|fair|poor)$")


log = logging.getLogger("bioinvigil.edge")


def create_edge_app(
    terminal: Terminal, sync: SyncAgent | None = None, simulator: bool = False, sync_interval: float | None = None
) -> FastAPI:
    """`sync_interval` seconds between background upload attempts (None: manual 'Sync now' only)."""
    last_sync: dict[str, Any] = {"status": "never"}
    stop = threading.Event()

    def background_sync() -> None:
        while not stop.wait(sync_interval):  # type: ignore[arg-type]
            try:
                last_sync.update(sync.push(), at=terminal.clock())  # type: ignore[union-attr]
            except Exception:  # noqa: BLE001 - the loop must survive anything; verification never depends on it
                log.exception("background sync failed")

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        worker = None
        if sync is not None and sync_interval:
            worker = threading.Thread(target=background_sync, name="sync", daemon=True)
            worker.start()
        yield
        stop.set()
        if worker:
            worker.join(timeout=2)

    app = FastAPI(
        title="BioInvigil Terminal",
        version=__version__,
        docs_url=None,
        redoc_url=None,
        openapi_url=None,
        lifespan=lifespan,
    )
    scanner = SimulatedScanner() if simulator else None

    @app.exception_handler(BioInvigilError)
    async def _err(_: Request, exc: BioInvigilError) -> JSONResponse:
        return JSONResponse(status_code=exc.status, content={"code": exc.code, "detail": exc.message, **exc.extra})

    @app.exception_handler(RequestValidationError)
    async def _val(_: Request, exc: RequestValidationError) -> JSONResponse:
        detail = [{"loc": [str(x) for x in e["loc"]], "msg": e["msg"]} for e in exc.errors()]
        return JSONResponse(status_code=422, content={"code": "INVALID_INPUT", "detail": detail})

    @app.middleware("http")
    async def _headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'"
        return resp

    def user(authorization: Annotated[str | None, Header()] = None) -> dict[str, str]:
        if not authorization or not authorization.startswith("Bearer "):
            raise AuthError("missing bearer token")
        return terminal.user_from_token(authorization[7:])

    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(STATIC / "index.html", media_type="text/html")

    @app.get("/static/app.js")
    def script() -> FileResponse:
        return FileResponse(STATIC / "app.js", media_type="text/javascript")

    @app.get("/health")
    def health() -> dict[str, Any]:
        return {"status": "ok", "version": __version__, "bundle": terminal.bundle_id}

    @app.post("/api/login")
    def login(body: LoginIn) -> dict[str, str]:
        token_type = "bearer"  # noqa: S105  # nosec B105
        return {"access_token": terminal.login(body.username, body.password), "token_type": token_type}

    @app.get("/api/status")
    def status(_: Annotated[dict, Depends(user)]) -> dict[str, Any]:
        return {**terminal.status(), "last_sync": last_sync}

    @app.post("/api/verify")
    def verify(body: VerifyIn, u: Annotated[dict, Depends(user)]) -> dict[str, Any]:
        return terminal.verify(body.matric_no, body.probe, u["username"]).to_dict()

    @app.post("/api/identify")
    def identify(body: IdentifyIn, u: Annotated[dict, Depends(user)]) -> dict[str, Any]:
        return terminal.identify(body.probe, u["username"]).to_dict()

    @app.post("/api/override")
    def override(body: OverrideIn, u: Annotated[dict, Depends(user)]) -> dict[str, Any]:
        return terminal.override(
            body.matric_no, body.reason_code, body.note, body.approver_username, body.approver_password, u["username"]
        ).to_dict()

    @app.get("/api/override-reasons")
    def reasons(_: Annotated[dict, Depends(user)]) -> list[str]:
        return sorted(OVERRIDE_REASONS)

    @app.post("/api/sync")
    def do_sync(_: Annotated[dict, Depends(user)]) -> dict[str, Any]:
        if sync is None:
            return {"status": "not_configured"}
        last_sync.update(sync.push(), at=terminal.clock())
        return dict(last_sync)

    @app.post("/api/sim/capture")
    def sim_capture(body: SimIn, _: Annotated[dict, Depends(user)]) -> dict[str, Any]:
        if scanner is None:  # not registered as a route at all in production builds
            raise NotFound("simulator disabled")
        return {"probe": [float(x) for x in scanner.capture(body.finger_of.upper(), body.quality)]}

    return app
