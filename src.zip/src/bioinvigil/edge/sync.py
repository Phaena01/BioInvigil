"""Store-and-forward synchronisation: signed, idempotent, resumable batches."""

from __future__ import annotations

from typing import Any, Protocol

import httpx

from ..crypto import canonical_json
from .keystore import DeviceKeys
from .store import EventStore


class HttpClient(Protocol):
    def post(self, url: str, **kwargs: Any) -> httpx.Response: ...


class SyncAgent:
    def __init__(self, store: EventStore, keys: DeviceKeys, bundle_id: str, client: HttpClient, batch_size: int = 200):
        self.store, self.keys, self.bundle_id = store, keys, bundle_id
        self.client, self.batch_size = client, batch_size

    def _batch(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        body = {
            "device_id": self.store.device_id,
            "session_id": self.store.session_id,
            "bundle_id": self.bundle_id,
            "events": events,
        }
        return {**body, "sig": self.keys.sign.sign_b64(canonical_json(body))}

    def push(self) -> dict[str, Any]:
        """Send every unsent event. Returns a status dict; never raises on network failure."""
        sent, resynced = 0, False
        while True:
            events = self.store.after(self.store.acked_seq, self.batch_size)
            if not events:
                return {"status": "synced", "sent": sent, "pending": 0}
            try:
                resp = self.client.post("/sync/ingest", json=self._batch(events))
            except httpx.TransportError:
                return {"status": "offline", "sent": sent, "pending": self._pending()}
            if resp.status_code == 200:
                self.store.set_acked(resp.json()["last_seq"])
                sent += len(events)
                continue
            body = resp.json()
            if (
                resp.status_code == 409
                and not resynced
                and "last_seq" in body
                and not body.get("tamper")
                and int(body["last_seq"]) <= self.store.last()[0]
            ):
                # hub reports what it actually holds; re-align once (handles hub restore / lost ack).
                # A hub-side tamper verdict or a hub that is "ahead" of us is never papered over.
                self.store.set_acked(int(body["last_seq"]))
                resynced = True
                continue
            return {
                "status": "rejected",
                "http": resp.status_code,
                "detail": body.get("detail"),
                "sent": sent,
                "pending": self._pending(),
            }

    def _pending(self) -> int:
        return self.store.last()[0] - self.store.acked_seq
