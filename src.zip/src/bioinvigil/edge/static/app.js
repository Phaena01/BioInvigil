let token = null, last = {};
const $ = id => document.getElementById(id);
async function api(path, body, method) {
  const r = await fetch(path, { method: method || (body ? 'POST' : 'GET'),
    headers: Object.assign({'Content-Type':'application/json'}, token ? {Authorization:'Bearer '+token} : {}),
    body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.detail || r.status), {json:j}); return j;
}
function show(d, err) {
  const el = $('result'); el.className = 'card ' + (err ? 'error' : d.outcome);
  el.querySelector('h3').textContent = err ? 'Error' : d.outcome.replace(/_/g, ' ');
  const lines = err ? [String(d)] : [d.name && (d.name + ' - ' + d.matric_no), d.seat_no && ('Seat ' + d.seat_no),
    d.score != null && ('Score ' + d.score), d.attempts_left != null && ('Attempts left: ' + d.attempts_left), d.message];
  $('resBody').textContent = lines.filter(Boolean).join('  |  ');
  $('ovBox').classList.toggle('hidden', !(d && ['REVIEW_REQUIRED','REJECT_MISMATCH','NO_MATCH'].includes(d.outcome)));
}
async function refresh() {
  const s = await api('/api/status');
  $('sessTitle').textContent = s.session.course_code + ' - ' + s.session.title + ' (Hall ' + s.hall_id + ')';
  $('sExp').textContent = s.expected; $('sAdm').textContent = s.admitted; $('sRej').textContent = s.rejects;
  $('sRev').textContent = s.reviews; $('sUns').textContent = s.unsynced;
}
async function probeFor(owner, quality) { return (await api('/api/sim/capture', {finger_of: owner, quality})).probe; }
$('loginBtn').onclick = async () => {
  try {
    token = (await api('/api/login', {username:$('u').value, password:$('p').value})).access_token;
    ['loginCard'].forEach(i => $(i).classList.add('hidden'));
    ['statusCard','scanCard','resCard'].forEach(i => $(i).classList.remove('hidden'));
    $('reason').innerHTML = (await api('/api/override-reasons')).map(r => '<option>'+r+'</option>').join('');
    try { await api('/api/sim/capture', {finger_of:'X', quality:'good'}); $('sim').classList.remove('hidden'); } catch (e) {}
    await refresh();
  } catch (e) { $('loginMsg').textContent = e.message; }
};
$('verifyBtn').onclick = async () => {
  try {
    last.matric = $('matric').value;
    const probe = await probeFor($('fingerOf').value || last.matric, $('quality').value);
    const d = await api('/api/verify', {matric_no: last.matric, probe}); show(d); await refresh();
  } catch (e) { show(e.message, true); }
};
$('identBtn').onclick = async () => {
  try {
    const probe = await probeFor($('fingerOf').value, $('quality').value);
    const d = await api('/api/identify', {probe}); show(d); await refresh();
  } catch (e) { show(e.message, true); }
};
$('ovBtn').onclick = async () => {
  try {
    const d = await api('/api/override', {matric_no: last.matric || $('matric').value, reason_code: $('reason').value,
      note: $('note').value, approver_username: $('apU').value, approver_password: $('apP').value});
    show(d); $('apP').value = ''; await refresh();
  } catch (e) { show(e.message, true); }
};
$('syncBtn').onclick = async () => {
  try { const r = await api('/api/sync', {}); $('syncMsg').textContent = r.status + ' (pending ' + (r.pending ?? 0) + ')'; await refresh(); }
  catch (e) { $('syncMsg').textContent = e.message; }
};
function net() { $('net').textContent = navigator.onLine ? 'network: online' : 'network: OFFLINE (working locally)'; }
addEventListener('online', net); addEventListener('offline', net); net();
