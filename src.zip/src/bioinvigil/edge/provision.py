"""Terminal key provisioning:  python -m bioinvigil.edge.provision init|set-device-id --keys keys.enc

init           create the passphrase-wrapped keystore and print the public keys for the hub administrator
set-device-id  store the device ID the hub returned after registration
The passphrase comes from BIOINVIGIL_KEY_PASSPHRASE or a prompt (never a command-line argument).
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from ..crypto import CryptoError
from .keystore import create_keystore, load_keystore, save_device_id


def _passphrase(confirm: bool) -> str:
    pw = os.environ.get("BIOINVIGIL_KEY_PASSPHRASE")
    if pw:
        return pw
    pw = getpass.getpass("Keystore passphrase (12+ characters): ")
    if confirm and getpass.getpass("Repeat passphrase: ") != pw:
        raise ValueError("passphrases differ")
    return pw


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="bioinvigil.edge.provision", description=__doc__)
    ap.add_argument("--keys", type=Path, required=True)
    sub = ap.add_subparsers(dest="cmd", required=True)
    init = sub.add_parser("init")
    init.add_argument("--public-out", type=Path, default=Path("device_keys.json"))
    sub.add_parser("set-device-id").add_argument("device_id")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "init":
            if args.keys.exists():
                raise ValueError(f"{args.keys} already exists; refusing to overwrite a keystore")
            keys = create_keystore(args.keys, _passphrase(confirm=True))
            pub = {"sign_pub": keys.sign.public_b64(), "kex_pub": keys.kex.public_b64()}
            args.public_out.write_text(json.dumps(pub))
            print(json.dumps(pub, indent=2))
        else:
            save_device_id(args.keys, _passphrase(confirm=False), args.device_id)
            print(f"device id {load_keystore(args.keys, _passphrase(confirm=False)).device_id} stored")
    except (ValueError, CryptoError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
